/* Date-logic test — loads the full app in jsdom under a mocked clock
   (Tue 09 Jun 2026, local) and verifies the shared date utility produces
   correct UK working weeks, ISO week numbers and payroll periods.
   Run with: TZ=Europe/London node test.dates.js   (and TZ=UTC, TZ=America/New_York) */
const fs = require("fs"), path = require("path"), vm = require("vm");
const { JSDOM } = require("jsdom");
const DIR = __dirname;
const html = fs.readFileSync(path.join(DIR, "index (2).html"), "utf8");
const srcs = [...html.matchAll(/<script src="([^"]+)"><\/script>/g)].map((m) => m[1]).filter((s) => !/^https?:/.test(s));

const dom = new JSDOM(html, { runScripts: "outside-only", url: "http://localhost/" });
const { window } = dom;
window.crypto = window.crypto || {}; if (!window.crypto.randomUUID) window.crypto.randomUUID = () => "id-" + Math.random().toString(36).slice(2);
window.matchMedia = window.matchMedia || (() => ({ matches: false, addEventListener() {}, removeEventListener() {} }));
window.print = () => {}; window.scrollTo = () => {};
const ctx = dom.getInternalVMContext();

// --- mock the clock to Tue 09 Jun 2026 09:00 LOCAL, before scripts run ---
const RealDate = Date;
const FIXED = new RealDate(2026, 5, 9, 9, 0, 0); // month 5 = June
function FakeDate(...a) { return a.length ? new RealDate(...a) : new RealDate(FIXED.getTime()); }
FakeDate.prototype = RealDate.prototype;
FakeDate.now = () => FIXED.getTime();
FakeDate.UTC = RealDate.UTC; FakeDate.parse = RealDate.parse;
ctx.Date = FakeDate; window.Date = FakeDate;

for (const src of srcs) vm.runInContext(fs.readFileSync(path.join(DIR, src), "utf8"), ctx, { filename: src });
window.document.dispatchEvent(new window.Event("DOMContentLoaded"));

const evalIn = (e) => vm.runInContext(e, ctx);
const Period = evalIn("Period"), Fmt = evalIn("Fmt");
let fails = 0;
const eq = (got, want, msg) => { const p = got === want; console.log((p ? "PASS" : "FAIL") + ` — ${msg}` + (p ? "" : `  (got ${JSON.stringify(got)}, want ${JSON.stringify(want)})`)); if (!p) fails++; };

console.log("TZ =", process.env.TZ || "(host default)");

// --- building blocks against the known Monday 08 Jun 2026 ---
const mon = Period.startOfWeek(new RealDate(2026, 5, 9)); // Monday of week containing Tue 9 Jun
eq(Period.isoOf(mon), "2026-06-08", "startOfWeek → Monday 2026-06-08 (no UTC day-shift)");
eq(Period.isoWeek(mon), 24, "ISO week number = 24");
eq(Period.isoOf(Period.addDays(mon, 4)), "2026-06-12", "Friday = 2026-06-12");
eq(Fmt.date("2026-06-08"), "08 Jun 2026", "Fmt.date parses date-only as local → 08 Jun 2026");

// --- the headline requirement: working week label ---
const ww = Period.workWeekRange(0);
eq(ww.from, "2026-06-08", "workWeekRange.from = Monday 2026-06-08");
eq(ww.to, "2026-06-12", "workWeekRange.to = Friday 2026-06-12");
eq(ww.week, 24, "workWeekRange.week = 24");
eq(ww.label, "Week 24 · 08 Jun 2026 – 12 Jun 2026", "label matches required format");

// --- previous working week = Week 23, 01–05 Jun ---
const pw = Period.workWeekRange(-1);
eq(pw.label, "Week 23 · 01 Jun 2026 – 05 Jun 2026", "previous week = Week 23, 01–05 Jun");

// --- calendar weekRange (Mon–Sun) still correct dates ---
const wr = Period.weekRange(0);
eq(wr.from, "2026-06-08", "weekRange.from Monday 2026-06-08");
eq(wr.to, "2026-06-14", "weekRange.to Sunday 2026-06-14");

// --- payroll fortnight: Monday-anchored, correct calendar dates ---
const pp = Period.payPeriodRange(0);
eq(/^2026-0[56]-\d\d$/.test(pp.from) && pp.from <= "2026-06-08", true, "payPeriod.from is a Monday on/just before this week (" + pp.from + ")");
eq(Period.isoOf(Period.addDays(new RealDate(pp.from + "T00:00:00"), 13)), pp.to, "payPeriod spans exactly 14 days (from..to)");
// fortnight must contain the current week's Monday
eq(pp.from <= "2026-06-08" && "2026-06-08" <= pp.to, true, "current week's Monday falls inside the pay period");

// --- todayISO is local 2026-06-09 ---
eq(Fmt.todayISO(), "2026-06-09", "Fmt.todayISO = local 2026-06-09 (not UTC-shifted)");

console.log(fails === 0 ? "\nALL PASSED" : `\n${fails} CHECK(S) FAILED`);
process.exit(fails === 0 ? 0 : 1);
