# Construction ERP — Phase 6 Finalisation

A single-page construction management app: plain HTML + CSS + vanilla JS, no
build step, no framework. Data lives in the browser (`localStorage`, namespaced
`erp:`). Every feature is a self-registering module on a shared core in `app.js`.

---

## Final project structure

```
construction-erp/
├── index.html              # shell: login + sidebar/topbar + routed view
├── app.js                  # core: Store, Auth, Router, Modules, Dashboard,
│                           #       UI, Fmt, Period, Finance, Commercial
├── styles.css              # design system + responsive + print (themed)
├── styles.enhance.css      # Phase 6 additive polish (calendar, charts, code)
└── modules/
    ├── util.js             # Phase 6 — shared helpers + CSV/PDF/chart utils
    │
    ├── workers.js          # ── Operations
    ├── sites.js
    ├── timesheets.js
    ├── payroll.js
    │
    ├── clients.js          # ── Commercial
    ├── quotes.js
    ├── invoices.js
    ├── suppliers.js
    ├── purchaseOrders.js
    │
    ├── expenses.js         # ── Finance
    ├── payments.js
    │
    ├── materials.js        # ── Project Costing (Phase 4)
    ├── inventory.js
    ├── skipHire.js
    ├── profit.js
    │
    ├── vehicles.js         # ── Fleet & Assets (Phase 5)
    ├── equipment.js
    ├── calendar.js         # ── HR & Scheduling
    ├── leaveManagement.js
    ├── documents.js        # ── Compliance
    ├── healthSafety.js
    ├── cis.js              # ── Tax
    ├── vat.js
    ├── reports.js          # ── Insights
    ├── analytics.js        # ── Insights (Phase 6, Chart.js)
    └── settings.js         # ── System
```

26 feature modules + `util.js`, over one ~1,000-line core. Load order = nav
order; `util.js` must load first (right after `app.js`) so every module can use
it.

---

## What changed in Phase 6

**Refactor / remove duplicates.** The helpers that had been copy-pasted across
modules now live once in `util.js` (`window.Util`):

- `Util.compressImage` / `Util.readDataURL` — was duplicated in `expenses.js`
  and `documents.js`; both now call the shared version.
- `Util.downloadCSV` / `toCSV` / `download` — the CSV blob plumbing was repeated
  in `profit.js` and `reports.js`; both now call the shared version.
- `Util.printDocument` — new shared PDF/print helper (prints via a hidden
  iframe, so the browser's "Save as PDF" produces a clean document).
- `Util.themeColors` / `Util.onThemeChange` — resolve CSS theme tokens for
  Chart.js and re-render charts when the theme flips.
- `Util.options` / `Util.nameOf` / `Util.opts` / `Util.daysUntil` — available
  for the remaining modules to adopt incrementally (their local copies still
  work, so migration can be done file-by-file with no behaviour change).

**Charts (Chart.js).** New `analytics.js` under *Insights*: revenue-vs-cost by
project, a cost-breakdown doughnut, and a 6-month cash-flow bar — theme-aware,
with CSV and PDF export. Degrades to data tables with a one-line setup hint if
the Chart.js tag isn't present.

**PDF exports.** Invoices/quotes/POs already printed to PDF; Phase 6 adds PDF
export to *Profitability*, *Reports*, and *Analytics* via `Util.printDocument`.

**CSV exports.** Profitability, Reports (aged debtors) and Analytics all export
CSV through the shared helper.

**Backup / restore.** Already shipped in `settings.js` (Phase 5): JSON export,
import (file or paste), and erase-all — unchanged, re-verified.

**Mobile & dark/light polish.** `styles.css` already had the drawer, grid
collapses and print rules. `styles.enhance.css` (additive, token-based so both
themes work) fills the gaps: proper styling + responsive shrink for the Phase-5
calendar grid, responsive chart-canvas heights, legible inline `code`, and minor
dark-mode touch-ups.

### Files to add / replace

Add to `index.html`:

```html
<!-- in <head>, after styles.css -->
<link rel="stylesheet" href="styles.enhance.css">

<!-- before the module scripts (vendor lib for charts) -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>

<!-- immediately after app.js, BEFORE all module scripts -->
<script src="modules/util.js"></script>

<!-- after modules/reports.js (so it sits under "Insights") -->
<script src="modules/analytics.js"></script>
```

Replace (same filenames, no index.html change needed): `expenses.js`,
`documents.js`, `profit.js`, `reports.js`.

> Chart.js is loaded from a CDN. For fully offline use, download
> `chart.umd.min.js` next to the modules and point the tag at the local copy.

---

## Final QA review

Verified by loading the full app (all 26 modules + `util.js` + `analytics.js`)
on the real core in a jsdom harness:

- **Routing** — all 27 routes register, resolve and render; nav groups intact
  (Operations, Commercial, Finance, Project Costing, Fleet & Assets,
  HR & Scheduling, Compliance, Tax, Insights, System).
- **Refactor safety** — `expenses` and `documents` render after moving image
  compression to `Util`; `profit` and `reports` CSV exports produce correct
  output via `Util.downloadCSV`; no `csvCell`/`compressImage` duplicates remain.
- **Analytics** — builds 3 charts when Chart.js is present; falls back to data
  tables + setup hint when absent; CSV/PDF export run without error.
- **Calculations (carried from earlier phases, unchanged)** — CIS deduction
  `(gross − materials) × rate` = £160 on £1,000/£200/20%; VAT output − input
  nets correctly; project cost composes labour + PO materials + expenses +
  stock + skip with no double-count; aged-debtor buckets place by age correctly.
- **Roles** — Viewer is denied Analytics, VAT, Reports, Settings, Profitability;
  Manager-gated dashboard stats stay hidden from Viewers.
- **Theme & print** — theme tokens drive both UI and chart colours; print/PDF
  paths use the existing print stylesheet.

Known environment notes (not bugs): chart bitmap and `window.print()` can't run
under jsdom, so the PDF path is asserted to execute cleanly and is exercised for
real in the browser.

---

## Future improvements

**Architecture / data**
- Move off `localStorage` to a backend (or IndexedDB) — the ~5MB cap limits
  documents/receipts, and data is per-browser with no multi-user sync.
- Real auth: server-side accounts with hashed passwords and proper sessions,
  replacing the seeded client-side demo users.
- A typed data layer / schema validation, and migrations for stored records.

**Finish the dedup pass**
- Migrate the remaining modules to `Util.options` / `Util.nameOf` / `Util.opts`
  to delete the last per-module helper copies (mechanical, low-risk, do a few
  files at a time and re-test).

**Features**
- Editable user management (add/remove users, change roles) in Settings.
- Quote → Invoice → Payment lifecycle automation and reminders.
- Inventory: link PO receipts to stock-in automatically; valuation methods.
- Calendar: drag-to-create, week/agenda views, iCal export.
- Per-document versioning and a proper file store.
- Configurable CIS/VAT settings; export files in HMRC-friendly formats.

**Polish / engineering**
- Bundle + minify for production; add a service worker for offline use and to
  vendor Chart.js locally.
- Automated test suite (the jsdom harness used here is a good seed) run in CI.
- Accessibility audit (focus traps in modals, ARIA on the calendar grid).
- Empty-state onboarding and seed/demo-data loader.
