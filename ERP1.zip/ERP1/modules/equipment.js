/* ==========================================================================
   modules/equipment.js — Tool & equipment register (Phase 5)
   Store collection "equipment".
   Record: { id, name, category, serial, assignedTo, siteId, status,
             value, purchaseDate, inspectionDate, notes }
   PAT / LOLER / calibration tracked via inspectionDate.
   ========================================================================== */
(() => {
  "use strict";
  const COL = "equipment";
  const canEdit = () => Auth.can("Manager");
  const CATEGORIES = ["Power Tool", "Hand Tool", "Access (ladders/towers)", "Lifting", "Plant", "Survey / Test", "Generator / Power", "Welfare", "Other"];
  const STATUSES = ["Available", "In use", "Under repair", "Lost / stolen", "Written off"];
  const badgeKind = { "Available": "ok", "In use": "warn", "Under repair": "warn", "Lost / stolen": "muted", "Written off": "muted" };

  const opts = (list, sel) => list.map((o) => `<option value="${esc(o)}"${o === sel ? " selected" : ""}>${esc(o)}</option>`).join("");
  const workerName = (id) => id ? ((Store.find("workers", id) || {}).name || "Unknown") : "";
  const siteName = (id) => id ? ((Store.find("sites", id) || {}).name || "Unknown") : "";
  const holder = (e) => workerName(e.assignedTo) || siteName(e.siteId) || "Store / yard";
  const daysUntil = (iso) => { if (!iso) return null; const d = new Date(iso); if (isNaN(d)) return null; return Math.floor((d - new Date(Fmt.todayISO())) / 86400000); };
  function workerOptions(sel) { return `<option value="">— none —</option>` + Store.all("workers").map((w) => `<option value="${w.id}"${w.id === sel ? " selected" : ""}>${esc(w.name)}</option>`).join(""); }
  function siteOptions(sel) { return `<option value="">— none —</option>` + Store.all("sites").map((s) => `<option value="${s.id}"${s.id === sel ? " selected" : ""}>${esc(s.name)}</option>`).join(""); }

  function form(e) {
    e = e || {}; // null-safe: JS default params apply to undefined only, not null
    return `
      <div class="form-grid">
        <div class="field span-2"><label class="field__label">Item name *</label>
          <input class="input" id="e-name" value="${esc(e.name || "")}" placeholder="e.g. Hilti TE 60 SDS drill"></div>
        <div class="field"><label class="field__label">Category</label>
          <select class="input" id="e-cat">${opts(CATEGORIES, e.category || "Power Tool")}</select></div>
        <div class="field"><label class="field__label">Serial / asset no.</label>
          <input class="input" id="e-serial" value="${esc(e.serial || "")}"></div>
        <div class="field"><label class="field__label">Held by (worker)</label>
          <select class="input" id="e-worker">${workerOptions(e.assignedTo)}</select></div>
        <div class="field"><label class="field__label">On site</label>
          <select class="input" id="e-site">${siteOptions(e.siteId)}</select></div>
        <div class="field"><label class="field__label">Status</label>
          <select class="input" id="e-status">${opts(STATUSES, e.status || "Available")}</select></div>
        <div class="field"><label class="field__label">Value (£)</label>
          <input class="input" id="e-value" type="number" min="0" step="0.01" value="${e.value ?? ""}"></div>
        <div class="field"><label class="field__label">Purchased</label>
          <input class="input" id="e-purchase" type="date" value="${esc(e.purchaseDate || "")}"></div>
        <div class="field"><label class="field__label">Next inspection (PAT/LOLER)</label>
          <input class="input" id="e-insp" type="date" value="${esc(e.inspectionDate || "")}"></div>
        <div class="field span-2"><label class="field__label">Notes</label>
          <textarea class="input" id="e-notes" rows="2">${esc(e.notes || "")}</textarea></div>
      </div>`;
  }
  const read = (r) => ({
    name: r.querySelector("#e-name").value.trim(), category: r.querySelector("#e-cat").value,
    serial: r.querySelector("#e-serial").value.trim(), assignedTo: r.querySelector("#e-worker").value,
    siteId: r.querySelector("#e-site").value, status: r.querySelector("#e-status").value,
    value: parseFloat(r.querySelector("#e-value").value) || 0, purchaseDate: r.querySelector("#e-purchase").value,
    inspectionDate: r.querySelector("#e-insp").value, notes: r.querySelector("#e-notes").value.trim(),
  });
  function openForm(existing) {
    UI.modal({ title: existing ? "Edit item" : "Add item", size: "lg", bodyHTML: form(existing),
      saveLabel: existing ? "Save changes" : "Add item",
      onSave: (r) => {
        const d = read(r);
        if (!d.name) { UI.toast("Item name is required", "danger"); return false; }
        if (existing) { Store.update(COL, existing.id, d); UI.toast("Item updated", "ok"); }
        else { Store.insert(COL, d); UI.toast("Item added", "ok"); }
        render(document.getElementById("view-root"));
      } });
  }
  function remove(e) { UI.confirm(`Delete ${e.name}?`, () => { Store.destroy(COL, e.id); UI.toast("Item deleted", "info"); render(document.getElementById("view-root")); }); }

  let term = "", filt = "all";
  function render(root) {
    const all = Store.all(COL).sort((a, b) => (a.name || "").localeCompare(b.name || ""));
    let rows = all.filter((e) => !term || (e.name + " " + e.serial + " " + e.category + " " + holder(e)).toLowerCase().includes(term.toLowerCase()));
    if (filt === "inspect") rows = rows.filter((e) => { const n = daysUntil(e.inspectionDate); return n !== null && n <= 30; });
    const totalValue = all.reduce((s, e) => s + (Number(e.value) || 0), 0);
    const inspectDue = all.filter((e) => { const n = daysUntil(e.inspectionDate); return n !== null && n <= 30; }).length;

    const fOpts = [["all", "All items"], ["inspect", "Inspection due ≤30d"]].map(([v, l]) => `<option value="${v}"${filt === v ? " selected" : ""}>${l}</option>`).join("");

    root.innerHTML = `
      <div class="toolbar">
        <div class="toolbar__left filterbar">
          <input class="input input--search" id="e-search" placeholder="Search tools…" value="${esc(term)}">
          <select class="input" id="e-filter">${fOpts}</select>
          <span class="muted-count num">${Fmt.gbp(totalValue)} asset value</span>
          ${inspectDue ? `<span class="badge badge--warn">${inspectDue} inspection due</span>` : ""}
        </div>
        ${canEdit() ? `<button class="btn btn--primary" id="e-add">＋ Add item</button>` : ""}
      </div>
      ${rows.length ? `
        <div class="table-wrap"><table class="table">
          <thead><tr><th>Item</th><th>Category</th><th>Serial</th><th>Held by</th><th>Status</th><th class="ta-r">Value</th><th>Inspection</th>${canEdit() ? `<th class="ta-r">Actions</th>` : ""}</tr></thead>
          <tbody>${rows.map((e) => {
            const n = daysUntil(e.inspectionDate);
            const insp = e.inspectionDate ? `<span class="badge badge--${n < 0 ? "warn" : n <= 30 ? "warn" : "ok"}">${n < 0 ? "overdue" : Fmt.dayMon(e.inspectionDate)}</span>` : `<span class="muted-count">—</span>`;
            return `<tr>
              <td><strong>${esc(e.name)}</strong></td>
              <td><span class="badge badge--muted">${esc(e.category || "—")}</span></td>
              <td class="num">${esc(e.serial || "—")}</td>
              <td>${esc(holder(e))}</td>
              <td><span class="badge badge--${badgeKind[e.status] || "muted"}">${esc(e.status || "—")}</span></td>
              <td class="ta-r num">${e.value ? Fmt.gbp(e.value) : "—"}</td>
              <td>${insp}</td>
              ${canEdit() ? `<td class="ta-r nowrap"><button class="btn btn--sm" data-edit="${e.id}">Edit</button><button class="btn btn--sm btn--danger" data-del="${e.id}">Del</button></td>` : ""}
            </tr>`; }).join("")}</tbody>
          <tfoot><tr class="totals"><td colspan="5">${all.length} item${all.length === 1 ? "" : "s"}</td><td class="ta-r num">${Fmt.gbp(totalValue)}</td><td colspan="${canEdit() ? 2 : 1}"></td></tr></tfoot>
        </table></div>`
      : `<div class="panel"><div class="panel__body"><div class="empty">
          <svg class="empty__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14 6l4 4M3 21l3-1 11-11-3-3L3 18z"/><path d="M14 6l3-3 4 4-3 3"/></svg>
          <div class="empty__title">${all.length === 0 ? "No equipment yet" : "No matches"}</div>
          <div class="empty__text">${all.length === 0 ? (canEdit() ? "Start your tool register." : "Ask a manager to add equipment.") : "Try a different filter or search."}</div>
        </div></div></div>`}
    `;
    const search = root.querySelector("#e-search");
    search.addEventListener("input", () => { term = search.value; render(root); const s = document.getElementById("e-search"); if (s) { s.focus(); s.setSelectionRange(s.value.length, s.value.length); } });
    root.querySelector("#e-filter").addEventListener("change", (ev) => { filt = ev.target.value; render(root); });
    const add = root.querySelector("#e-add"); if (add) add.addEventListener("click", () => openForm(null));
    root.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => openForm(Store.find(COL, b.dataset.edit))));
    root.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => remove(Store.find(COL, b.dataset.del))));
  }

  Modules.register({
    id: "equipment", label: "Equipment", title: "Tool & Equipment Register", minRole: "Viewer",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 6l4 4M3 21l3-1 11-11-3-3L3 18z"/><path d="M14 6l3-3 4 4-3 3"/></svg>',
    render,
  });
})();
