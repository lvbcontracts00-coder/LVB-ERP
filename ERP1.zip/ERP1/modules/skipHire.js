/* ==========================================================================
   modules/skipHire.js — Skip hire / waste removal costs (Phase 4)
   Store collection "skipHire". Each record is a hired skip booked to a project.
   Record: { id, hireDate, siteId, supplierId, size, cost, status, ref, notes }
   Status: Ordered · Delivered · Collected · Cancelled.
   Skip cost counts toward project cost for every status except Cancelled
   (read by the profit module). This is a NEW cost category not represented in
   the Finance layer, so adding it introduces no double-count.
   ========================================================================== */
(() => {
  "use strict";
  const COL = "skipHire";
  const canEdit = () => Auth.can("Manager");
  const SIZES = ["2 yd (mini)", "4 yd (midi)", "6 yd (builders)", "8 yd (large builders)", "12 yd (maxi)", "RoRo 20 yd", "RoRo 40 yd", "Grab lorry (6-wheel ~12t)", "Grab lorry (8-wheel ~16t)"];
  const STATUSES = ["Ordered", "Delivered", "Collected", "Cancelled"];
  const badgeKind = { "Ordered": "warn", "Delivered": "ok", "Collected": "muted", "Cancelled": "muted" };
  const NEXT = { "Ordered": "Delivered", "Delivered": "Collected" };
  const counts = (s) => s.status !== "Cancelled"; // billable to the project

  const opts = (list, sel) => list.map((o) => `<option value="${esc(o)}"${o === sel ? " selected" : ""}>${esc(o)}</option>`).join("");
  const siteName = (id) => id ? ((Store.find("sites", id) || {}).name || "Unknown") : "—";
  const supplierName = (id) => id ? ((Store.find("suppliers", id) || {}).name || "—") : "—";
  function siteOptions(sel) {
    return `<option value="">— none —</option>` +
      Store.all("sites").map((s) => `<option value="${s.id}"${s.id === sel ? " selected" : ""}>${esc(s.name)}</option>`).join("");
  }
  function supplierOptions(sel) {
    return `<option value="">— none —</option>` +
      Store.all("suppliers").map((s) => `<option value="${s.id}"${s.id === sel ? " selected" : ""}>${esc(s.name)}</option>`).join("");
  }

  function openForm(existing) {
    UI.modal({
      title: existing ? "Edit skip" : "Book a skip", size: "lg",
      saveLabel: existing ? "Save changes" : "Book skip",
      bodyHTML: `
        <div class="form-grid">
          <div class="field"><label class="field__label">Hire date *</label>
            <input class="input" id="k-date" type="date" value="${esc((existing && existing.hireDate) || Fmt.todayISO())}"></div>
          <div class="field"><label class="field__label">Size</label>
            <select class="input" id="k-size">${opts(SIZES, (existing && existing.size) || "6 yd (builders)")}</select></div>
          <div class="field"><label class="field__label">Project *</label>
            <select class="input" id="k-site">${siteOptions(existing && existing.siteId)}</select></div>
          <div class="field"><label class="field__label">Supplier</label>
            <select class="input" id="k-supplier">${supplierOptions(existing && existing.supplierId)}</select></div>
          <div class="field"><label class="field__label">Cost (£) *</label>
            <input class="input" id="k-cost" type="number" min="0" step="0.01" value="${(existing && existing.cost) ?? ""}" placeholder="0.00"></div>
          <div class="field"><label class="field__label">Status</label>
            <select class="input" id="k-status">${opts(STATUSES, (existing && existing.status) || "Ordered")}</select></div>
          <div class="field span-2"><label class="field__label">Reference / notes</label>
            <input class="input" id="k-ref" value="${esc((existing && existing.ref) || "")}" placeholder="Order ref, permit number…"></div>
        </div>`,
      onSave: (r) => {
        const cost = parseFloat(r.querySelector("#k-cost").value);
        if (isNaN(cost) || cost < 0) { UI.toast("Enter a valid cost", "danger"); return false; }
        const siteId = r.querySelector("#k-site").value;
        if (!siteId) { UI.toast("Pick a project to book the skip to", "danger"); return false; }
        const d = {
          hireDate: r.querySelector("#k-date").value || Fmt.todayISO(),
          size: r.querySelector("#k-size").value,
          siteId, supplierId: r.querySelector("#k-supplier").value,
          cost, status: r.querySelector("#k-status").value,
          ref: r.querySelector("#k-ref").value.trim(),
        };
        if (existing) { Store.update(COL, existing.id, d); UI.toast("Skip updated", "ok"); }
        else { Store.insert(COL, d); UI.toast("Skip booked", "ok"); }
        render(document.getElementById("view-root"));
      },
    });
  }
  function advance(s) {
    const next = NEXT[s.status]; if (!next) return;
    Store.update(COL, s.id, { status: next }); UI.toast(`Marked ${next.toLowerCase()}`, "ok");
    render(document.getElementById("view-root"));
  }
  function remove(s) {
    UI.confirm("Delete this skip record?", () => {
      Store.destroy(COL, s.id); UI.toast("Skip deleted", "info");
      render(document.getElementById("view-root"));
    });
  }

  let filt = "all"; // all | active | <status>
  function render(root) {
    const all = Store.all(COL).sort((a, b) => (b.hireDate || "").localeCompare(a.hireDate || ""));
    const rows = all.filter((s) => filt === "all" ? true : filt === "active" ? counts(s) : s.status === filt);
    const billable = all.filter(counts).reduce((s, k) => s + (Number(k.cost) || 0), 0);
    const shown = rows.reduce((s, k) => s + (Number(k.cost) || 0), 0);

    const fOpts = [["all", "All"], ["active", "Billable"], ...STATUSES.map((s) => [s, s])]
      .map(([v, l]) => `<option value="${v}"${filt === v ? " selected" : ""}>${l}</option>`).join("");

    root.innerHTML = `
      <div class="toolbar">
        <div class="toolbar__left filterbar">
          <select class="input" id="k-filter">${fOpts}</select>
          <span class="muted-count num">${Fmt.gbp(billable)} billable to projects</span>
        </div>
        ${canEdit() ? `<button class="btn btn--primary" id="k-add">＋ Book a skip</button>` : ""}
      </div>
      ${rows.length ? `
        <div class="table-wrap"><table class="table">
          <thead><tr><th>Date</th><th>Project</th><th>Size</th><th>Supplier</th><th>Status</th><th class="ta-r">Cost</th>${canEdit() ? `<th class="ta-r">Actions</th>` : ""}</tr></thead>
          <tbody>${rows.map((s) => `
            <tr>
              <td class="num">${Fmt.date(s.hireDate)}</td>
              <td><strong>${esc(siteName(s.siteId))}</strong>${s.ref ? `<div class="muted-count">${esc(s.ref)}</div>` : ""}</td>
              <td>${esc(s.size || "—")}</td>
              <td>${esc(supplierName(s.supplierId))}</td>
              <td><span class="badge badge--${badgeKind[s.status] || "muted"}">${esc(s.status)}</span></td>
              <td class="ta-r num">${counts(s) ? Fmt.gbp(s.cost) : `<span class="muted-count">${Fmt.gbp(s.cost)}</span>`}</td>
              ${canEdit() ? `<td class="ta-r nowrap">
                ${NEXT[s.status] ? `<button class="btn btn--sm" data-adv="${s.id}">${NEXT[s.status]}</button>` : ""}
                <button class="btn btn--sm" data-edit="${s.id}">Edit</button>
                <button class="btn btn--sm btn--danger" data-del="${s.id}">Del</button></td>` : ""}
            </tr>`).join("")}</tbody>
          <tfoot><tr class="totals"><td colspan="5">${rows.length} skip${rows.length === 1 ? "" : "s"}</td><td class="ta-r num">${Fmt.gbp(shown)}</td>${canEdit() ? "<td></td>" : ""}</tr></tfoot>
        </table></div>`
      : `<div class="panel"><div class="panel__body"><div class="empty">
          <svg class="empty__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 7h18l-2 12H5L3 7z"/><path d="M3 7l1-3h16l1 3M9 11v5M15 11v5"/></svg>
          <div class="empty__title">No skips ${filt === "all" ? "booked yet" : "in this view"}</div>
          <div class="empty__text">${canEdit() ? "Book a skip and assign it to a project to track waste-removal cost." : "Ask a manager to log skip hire."}</div>
        </div></div></div>`}
    `;
    root.querySelector("#k-filter").addEventListener("change", (e) => { filt = e.target.value; render(root); });
    const add = root.querySelector("#k-add"); if (add) add.addEventListener("click", () => openForm(null));
    root.querySelectorAll("[data-adv]").forEach((b) => b.addEventListener("click", () => advance(Store.find(COL, b.dataset.adv))));
    root.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => openForm(Store.find(COL, b.dataset.edit))));
    root.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => remove(Store.find(COL, b.dataset.del))));
  }

  Modules.register({
    id: "skipHire", label: "Skip Hire", title: "Skip Hire", minRole: "Viewer",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 7h18l-2 11H5L3 7z"/><path d="M3 7l1-3h16l1 3"/></svg>',
    render,
  });
})();
