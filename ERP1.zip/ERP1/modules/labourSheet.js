/* ==========================================================================
   modules/labourSheet.js — Weekly Labour Sheet (Phase 6 / primary payroll entry)

   The company's real payroll process: one accountant enters a whole week of
   labour for ~25 workers from a single spreadsheet-like screen, then the
   existing Payroll / Fortnight Payroll machinery does the maths.

   This module is the FAST DATA-ENTRY FRONT-END. It does NOT replace payroll —
   instead every worked cell it produces is mirrored into the `timesheets`
   collection (tagged source:"labourSheet"), which Payroll, Finance, Reports and
   the Fortnight Payroll already read. So entering a week here automatically
   feeds:
       · Payroll (Fortnight)      — gross pay by worker, labour by project
       · Weekly Reports / Profit  — labour cost per site
       · Finance.labourCost(...)  — project costing everywhere
   Nothing downstream changes; existing manual timesheets are left untouched.

   GRID PER WORKER ROW:
     Worker · Daily Rate · Mon Tue Wed Thu Fri Sat · Days · Hours · Week Pay · Fortnight
   EACH DAY CELL:
     Status (Full / Half / Custom / Absent / —) · Site · Custom hours
   QUICK ACTIONS:
     Copy Previous Week · Copy Previous Day · Auto-Fill Site · Bulk Assign

   CONSISTENCY MODEL (so the sheet and payroll never disagree):
     Daily Rate = worker.rate (hourly) × Standard day hours.
       Full   → hours = dayHours,    pay = dayRate
       Half   → hours = dayHours/2,  pay = dayRate/2
       Custom → hours = h,           pay = h × hourly rate
       Absent → hours = 0,           pay = 0
     Editing a Daily Rate writes back worker.rate = dayRate / dayHours, so the
     figure here equals the figure Payroll computes from the mirrored hours.

   Manager+ only (contains pay data, matching the Payroll module).
   Data: collection "labourWeeks" (one record per Monday) + prefs "labourPrefs".
   ========================================================================== */
(() => {
  "use strict";

  const COL    = "labourWeeks";
  const PREFS  = "labourPrefs";
  const SOURCE = "labourSheet";          // marker on mirrored timesheet rows
  const DAYS   = [
    { k: "mon", label: "Mon" }, { k: "tue", label: "Tue" }, { k: "wed", label: "Wed" },
    { k: "thu", label: "Thu" }, { k: "fri", label: "Fri" }, { k: "sat", label: "Sat" },
  ];
  const TYPES = [
    { v: "",       label: "—" },
    { v: "full",   label: "Full" },
    { v: "half",   label: "Half" },
    { v: "custom", label: "Custom" },
    { v: "absent", label: "Absent" },
  ];
  const WORKED = (t) => t === "full" || t === "half" || t === "custom";

  const canEdit = () => Auth.can("Manager");

  const defaults = { offset: 0, dayHours: 8 };
  const state = Object.assign({}, defaults, Store.read(PREFS, {}));
  const savePrefs = () => Store.write(PREFS, { offset: state.offset, dayHours: state.dayHours });

  /* ---- date helpers — delegate to the shared Period utility -------------- */
  const iso     = Period.isoOf;          // LOCAL calendar serialisation (shared)
  const addDays = Period.addDays;
  const weekStartDate = (offset = state.offset) => addDays(Period.startOfWeek(new Date()), offset * 7);
  const dayDates = (mondayISO) => {
    const m = new Date(mondayISO + "T00:00:00");
    return DAYS.map((_, i) => iso(addDays(m, i)));
  };

  /* ---- worker / site helpers --------------------------------------------- */
  const activeWorkers = () =>
    Store.all("workers").filter((w) => w.status === "Active")
      .sort((a, b) => (a.name || "").localeCompare(b.name || ""));
  const activeSites = () =>
    Store.all("sites").filter((s) => s.status !== "Completed")
      .sort((a, b) => (a.name || "").localeCompare(b.name || ""));
  const siteName  = (id) => id ? ((Store.find("sites", id) || {}).name || "Unknown site") : "Unallocated";
  const hourly    = (w) => Number(w && w.rate) || 0;
  const dailyRate = (w) => Util.r2(hourly(w) * state.dayHours);

  /* ---- per-cell maths (single source of truth) --------------------------- */
  function cellHours(cell) {
    if (!cell) return 0;
    if (cell.t === "full")   return state.dayHours;
    if (cell.t === "half")   return state.dayHours / 2;
    if (cell.t === "custom") return Math.max(0, Number(cell.h) || 0);
    return 0; // absent / blank
  }
  const cellPay = (cell, w) => Util.r2(cellHours(cell) * hourly(w));

  /* ---- week record load / blank ------------------------------------------ */
  function blankGrid() { return {}; }
  function loadWeek(mondayISO) {
    const rec = Store.all(COL).find((r) => r.weekStart === mondayISO);
    return rec ? JSON.parse(JSON.stringify(rec)) : { weekStart: mondayISO, grid: blankGrid() };
  }
  function rowOf(grid, wid) {
    if (!grid[wid]) grid[wid] = {};
    return grid[wid];
  }
  function cellOf(grid, wid, day) {
    const row = rowOf(grid, wid);
    if (!row[day]) row[day] = { t: "", site: "", h: "" };
    return row[day];
  }

  /* live working copy for the screen */
  let work = null; // { weekStart, grid }

  /* ---- persistence + timesheet mirroring --------------------------------- */
  function persistWeek() {
    const existing = Store.all(COL).find((r) => r.weekStart === work.weekStart);
    if (existing) Store.update(COL, existing.id, { grid: work.grid });
    else          Store.insert(COL, { weekStart: work.weekStart, grid: work.grid });
  }

  /** Rewrite the timesheet rows this week owns — idempotent, no double count. */
  function syncTimesheets() {
    const ws = work.weekStart;
    Store.all("timesheets")
      .filter((t) => t.source === SOURCE && t.lsWeek === ws)
      .forEach((t) => Store.destroy("timesheets", t.id));

    const dates = dayDates(ws);
    Object.entries(work.grid).forEach(([wid, row]) => {
      if (!Store.find("workers", wid)) return;            // worker deleted
      DAYS.forEach((d, i) => {
        const cell = row[d.k];
        if (!cell || !WORKED(cell.t)) return;
        const hrs = cellHours(cell);
        if (hrs <= 0) return;
        Store.insert("timesheets", {
          workerId: wid, siteId: cell.site || "", date: dates[i],
          hours: hrs, overtime: 0, notes: "Weekly labour sheet",
          source: SOURCE, lsWeek: ws,
        });
      });
    });
  }

  let flushTimer = null;
  function scheduleFlush() {
    persistWeek();                       // grid save is cheap — do it now
    clearTimeout(flushTimer);
    flushTimer = setTimeout(flushNow, 600);
    markDirty(true);
  }
  function flushNow() {
    clearTimeout(flushTimer); flushTimer = null;
    persistWeek();
    syncTimesheets();
    markDirty(false);
  }
  function markDirty(dirty) {
    const el = document.getElementById("ls-saved");
    if (!el) return;
    el.textContent = dirty ? "Saving…" : "All changes saved & synced";
    el.classList.toggle("ls-saved--dirty", dirty);
  }

  /* ---- fortnight pay (matches Payroll's fortnight grid) ------------------ */
  function fortnightRange(mondayISO) {
    const from = Period.payPeriodStart(new Date(mondayISO + "T00:00:00"));
    const to = addDays(from, 13);
    return { from: iso(from), to: iso(to) };
  }
  /** Committed fortnight pay for a worker, EXCLUDING this week's stale mirror,
      so we can add the live in-memory figure on top without double counting. */
  function committedFortnightPay(wid, rate) {
    const { from, to } = fortnightRange(work.weekStart);
    return Util.r2(Store.all("timesheets")
      .filter((t) => t.workerId === wid
        && Period.inRange(t.date, from, to)
        && !(t.source === SOURCE && t.lsWeek === work.weekStart))
      .reduce((s, t) => s + ((Number(t.hours) || 0) + (Number(t.overtime) || 0)) * rate, 0));
  }

  /* ---- row / totals computation ------------------------------------------ */
  function rowTotals(wid, w) {
    const row = work.grid[wid] || {};
    let days = 0, hours = 0, pay = 0;
    DAYS.forEach((d) => {
      const cell = row[d.k];
      if (!cell || !WORKED(cell.t)) return;
      const h = cellHours(cell);
      if (h <= 0) return;
      days += cell.t === "half" ? 0.5 : (cell.t === "custom" ? h / state.dayHours : 1);
      hours += h;
      pay += h * hourly(w);
    });
    pay = Util.r2(pay);
    const fortnight = Util.r2(committedFortnightPay(wid, hourly(w)) + pay);
    return { days, hours, pay, fortnight };
  }

  /* ==========================================================================
     RENDER
     ========================================================================== */
  function render(root) {
    if (!canEdit()) { Views.forbidden(root, "Manager"); return; }

    const workers = activeWorkers();
    const sites   = activeSites();

    if (!workers.length || !sites.length) {
      root.innerHTML = `<div class="panel"><div class="panel__body"><div class="empty">
        <svg class="empty__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M3 9h18M8 2v4M16 2v4"/></svg>
        <div class="empty__title">Set up workers and sites first</div>
        <div class="empty__text">The labour sheet needs active workers to list and sites to assign their days to.</div>
        <div class="empty__actions">
          ${!workers.length ? `<button class="btn btn--sm" data-route="workers">Go to Workers</button>` : ""}
          ${!sites.length ? `<button class="btn btn--sm" data-route="sites">Go to Sites</button>` : ""}
        </div>
      </div></div></div>`;
      root.querySelectorAll("[data-route]").forEach((b) => b.addEventListener("click", () => Router.navigate(b.dataset.route)));
      return;
    }

    work = loadWeek(iso(weekStartDate()));
    const dates = dayDates(work.weekStart);
    const wkLabel = Period.workWeekRange(state.offset).label;
    const fr = fortnightRange(work.weekStart);

    /* reusable option strings */
    const siteOpts = (sel) => `<option value="">Site…</option>` +
      sites.map((s) => `<option value="${s.id}"${s.id === sel ? " selected" : ""}>${esc(s.name)}</option>`).join("");
    const typeOpts = (sel) => TYPES.map((t) => `<option value="${t.v}"${t.v === sel ? " selected" : ""}>${t.label}</option>`).join("");

    const dayHead = DAYS.map((d, i) =>
      `<th class="ls-dayhead">${d.label}<span class="ls-daydate num">${Fmt.dayMon(dates[i])}</span></th>`).join("");

    const bodyRows = workers.map((w) => {
      const row = work.grid[w.id] || {};
      const cells = DAYS.map((d) => {
        const c = row[d.k] || { t: "", site: "", h: "" };
        const worked = WORKED(c.t);
        return `
          <td class="ls-cell${worked ? " is-worked" : ""}" data-cell="${w.id}|${d.k}">
            <div class="ls-day">
              <label class="ls-sitepick${c.site ? " is-set" : ""}" title="${c.site ? esc(siteName(c.site)) : "Pick site"}">
                <span class="ls-sitepick__tag">S</span>
                <select class="ls-site" data-w="${w.id}" data-d="${d.k}" aria-label="${esc(w.name)} ${d.label} site">${siteOpts(c.site)}</select>
              </label>
              <select class="input input--cell ls-type" data-w="${w.id}" data-d="${d.k}" aria-label="${esc(w.name)} ${d.label} status">${typeOpts(c.t)}</select>
              <input class="input input--cell num ls-hrs" type="number" min="0" step="0.5" data-w="${w.id}" data-d="${d.k}" value="${c.t === "custom" ? (c.h ?? "") : ""}" placeholder="hrs" ${c.t === "custom" ? "" : "hidden"} aria-label="${esc(w.name)} ${d.label} custom hours">
            </div>
          </td>`;
      }).join("");

      const t = rowTotals(w.id, w);
      return `
        <tr data-row="${w.id}">
          <td class="ls-name">
            <strong>${esc(w.name)}</strong>
            <span class="ls-trade">${esc(w.trade || "—")}</span>
            <button class="ls-fillrow" data-fillrow="${w.id}" title="Fill whole week as Full day">▸ fill week</button>
          </td>
          <td class="ls-rate">
            <div class="ls-rate-wrap">£<input class="input input--cell num ls-rateinp" type="number" min="0" step="1" data-w="${w.id}" value="${dailyRate(w)}" aria-label="${esc(w.name)} daily rate"></div>
            <span class="ls-rate-sub num">${Fmt.gbp(hourly(w))}/hr</span>
          </td>
          ${cells}
          <td class="ta-r num" data-tot="days">${t.days % 1 ? t.days.toFixed(1) : t.days}</td>
          <td class="ta-r num" data-tot="hours">${Fmt.hours(t.hours)}</td>
          <td class="ta-r num" data-tot="pay"><strong>${Fmt.gbp(t.pay)}</strong></td>
          <td class="ta-r num ls-fort" data-tot="fort">${Fmt.gbp(t.fortnight)}</td>
        </tr>`;
    }).join("");

    root.innerHTML = `
      <div class="toolbar">
        <div class="toolbar__left filterbar">
          <button class="btn btn--sm" id="ls-prev">‹ Prev</button>
          <button class="btn btn--sm" id="ls-this">This week</button>
          <button class="btn btn--sm" id="ls-next">Next ›</button>
          <span class="muted-count num" id="ls-weeklabel">${esc(wkLabel)}</span>
          <label class="inline-field">Day&nbsp;hrs
            <input class="input input--mini" id="ls-dayhours" type="number" min="1" step="0.5" value="${state.dayHours}">
          </label>
        </div>
        <div class="filterbar">
          <span class="ls-saved" id="ls-saved">All changes saved &amp; synced</span>
          <button class="btn btn--primary btn--sm" id="ls-flush">Sync to payroll</button>
        </div>
      </div>

      <div class="ls-actions">
        <button class="btn btn--sm" id="qa-copyweek">⧉ Copy previous week</button>
        <button class="btn btn--sm" id="qa-copyday">→ Copy a day across</button>
        <button class="btn btn--sm" id="qa-autosite">📍 Auto-fill site</button>
        <button class="btn btn--sm" id="qa-bulk">👥 Bulk assign to site</button>
        <button class="btn btn--sm btn--danger" id="qa-clear">Clear week</button>
      </div>

      <div class="table-wrap ls-wrap">
        <table class="table ls-table">
          <thead><tr>
            <th class="ls-name">Worker</th>
            <th class="ls-rate">Daily rate</th>
            ${dayHead}
            <th class="ta-r">Days</th><th class="ta-r">Hours</th>
            <th class="ta-r">Week pay</th><th class="ta-r">Fortnight</th>
          </tr></thead>
          <tbody id="ls-body">${bodyRows}</tbody>
          <tfoot><tr class="totals" id="ls-foot"></tr></tfoot>
        </table>
      </div>

      <div class="panel" style="margin-top:18px">
        <div class="panel__head"><span class="panel__title">Labour cost per project · this week</span><span class="muted-count num" id="ls-projtot"></span></div>
        <div class="panel__body"><div id="ls-projects"></div></div>
      </div>

      <p class="hint hint--block">Entries here are written into Timesheets (tagged “labour sheet”) and flow straight into
        <strong>Payroll / Fortnight Payroll</strong>, project costing and reports. Gross only — excludes PAYE, NI and pension.
        Fortnight column = this week’s pay plus committed pay across the pay period (${Fmt.dayMon(fr.from)}–${Fmt.dayMon(fr.to)}).</p>
    `;

    injectStyles();
    wireGrid(root);
    recalcFooter();
    renderProjects();
    markDirty(false);
  }

  /* ==========================================================================
     EVENT WIRING (delegated — fast for ~25×6 cells)
     ========================================================================== */
  function wireGrid(root) {
    root.querySelector("#ls-prev").addEventListener("click", () => { flushNow(); state.offset -= 1; savePrefs(); render(root); });
    root.querySelector("#ls-next").addEventListener("click", () => { flushNow(); state.offset += 1; savePrefs(); render(root); });
    root.querySelector("#ls-this").addEventListener("click", () => { flushNow(); state.offset = 0; savePrefs(); render(root); });
    root.querySelector("#ls-flush").addEventListener("click", () => { flushNow(); UI.toast("Synced to payroll", "ok"); });
    root.querySelector("#ls-dayhours").addEventListener("change", (e) => {
      const v = parseFloat(e.target.value); state.dayHours = (isNaN(v) || v <= 0) ? 8 : v; savePrefs(); flushNow(); render(root);
    });

    /* quick actions */
    root.querySelector("#qa-copyweek").addEventListener("click", copyPreviousWeek);
    root.querySelector("#qa-copyday").addEventListener("click", copyDayAcross);
    root.querySelector("#qa-autosite").addEventListener("click", autoFillSite);
    root.querySelector("#qa-bulk").addEventListener("click", bulkAssign);
    root.querySelector("#qa-clear").addEventListener("click", clearWeek);

    const body = root.querySelector("#ls-body");

    // status change → toggle site/custom, default-inherit site, recalc
    body.addEventListener("change", (e) => {
      const el = e.target;
      const wid = el.dataset.w, day = el.dataset.d;

      if (el.classList.contains("ls-type")) {
        const cell = cellOf(work.grid, wid, day);
        cell.t = el.value;
        if (cell.t !== "custom") cell.h = "";
        if (WORKED(cell.t) && !cell.site) cell.site = inheritSite(wid, day); // speed: reuse nearby site
        refreshCell(wid, day);
        if (cell.t === "custom") {
          const hrs = document.querySelector(`[data-cell="${wid}|${day}"] .ls-hrs`);
          if (hrs) hrs.focus();
        }
        afterCellChange(wid);
      } else if (el.classList.contains("ls-site")) {
        cellOf(work.grid, wid, day).site = el.value;
        syncSitePick(el);
        afterCellChange(wid);
      } else if (el.classList.contains("ls-rateinp")) {
        const w = Store.find("workers", wid); if (!w) return;
        const dr = Math.max(0, parseFloat(el.value) || 0);
        const newHourly = Util.r2(dr / state.dayHours);
        Store.update("workers", wid, { rate: newHourly });
        const sub = body.querySelector(`tr[data-row="${wid}"] .ls-rate-sub`);
        if (sub) sub.textContent = Fmt.gbp(newHourly) + "/hr";
        recalcRow(wid); recalcFooter(); renderProjects();
        flushNow(); // rate is a real pay fact — persist immediately
      }
    });

    // custom hours live recalc (input, not change, for responsiveness)
    body.addEventListener("input", (e) => {
      const el = e.target;
      if (!el.classList.contains("ls-hrs")) return;
      const cell = cellOf(work.grid, el.dataset.w, el.dataset.d);
      cell.h = parseFloat(el.value);
      if (isNaN(cell.h)) cell.h = "";
      recalcRow(el.dataset.w); recalcFooter(); renderProjects();
      scheduleFlush();
    });

    // per-row "fill week"
    body.querySelectorAll("[data-fillrow]").forEach((b) =>
      b.addEventListener("click", () => fillRow(b.dataset.fillrow)));
  }

  /** Inherit the site from the nearest already-worked day in the same row. */
  function inheritSite(wid, day) {
    const row = work.grid[wid] || {};
    const order = DAYS.map((d) => d.k);
    const idx = order.indexOf(day);
    for (let dist = 1; dist < order.length; dist++) {
      for (const j of [idx - dist, idx + dist]) {
        if (j < 0 || j >= order.length) continue;
        const c = row[order[j]];
        if (c && WORKED(c.t) && c.site) return c.site;
      }
    }
    return "";
  }

  /** Keep the compact "S" picker's look (set / off / tooltip) in step with its select. */
  function syncSitePick(siteEl) {
    const wrap = siteEl.closest(".ls-sitepick");
    if (!wrap) return;
    wrap.classList.toggle("is-set", !!siteEl.value);
    wrap.title = siteEl.value ? siteName(siteEl.value) : "Pick site";
  }

  function afterCellChange(wid) { recalcRow(wid); recalcFooter(); renderProjects(); scheduleFlush(); }

  /* ---- targeted DOM refresh (no full re-render) -------------------------- */
  function refreshCell(wid, day) {
    const td = document.querySelector(`[data-cell="${wid}|${day}"]`);
    if (!td) return;
    const cell = cellOf(work.grid, wid, day);
    const worked = WORKED(cell.t);
    const site = td.querySelector(".ls-site");
    const hrs  = td.querySelector(".ls-hrs");
    const type = td.querySelector(".ls-type");
    td.classList.toggle("is-worked", worked);
    site.value = cell.site || "";
    syncSitePick(site);
    if (cell.t === "custom") { hrs.hidden = false; hrs.value = cell.h ?? ""; }
    else { hrs.hidden = true; hrs.value = ""; }
    if (type.value !== (cell.t || "")) type.value = cell.t || "";
  }

  function recalcRow(wid) {
    const w = Store.find("workers", wid); if (!w) return;
    const t = rowTotals(wid, w);
    const tr = document.querySelector(`tr[data-row="${wid}"]`); if (!tr) return;
    const set = (k, v) => { const el = tr.querySelector(`[data-tot="${k}"]`); if (el) el.innerHTML = v; };
    set("days", t.days % 1 ? t.days.toFixed(1) : t.days);
    set("hours", Fmt.hours(t.hours));
    set("pay", `<strong>${Fmt.gbp(t.pay)}</strong>`);
    set("fort", Fmt.gbp(t.fortnight));
  }

  function recalcFooter() {
    const workers = activeWorkers();
    let days = 0, hours = 0, pay = 0, fort = 0;
    workers.forEach((w) => { const t = rowTotals(w.id, w); days += t.days; hours += t.hours; pay += t.pay; fort += t.fortnight; });
    const foot = document.getElementById("ls-foot");
    if (!foot) return;
    foot.innerHTML = `
      <td class="ls-name">Total · week</td>
      <td></td>
      ${DAYS.map((d) => `<td class="ta-r num ls-coltot">${Fmt.gbp(colTotal(d.k))}</td>`).join("")}
      <td class="ta-r num">${days % 1 ? days.toFixed(1) : days}</td>
      <td class="ta-r num">${Fmt.hours(hours)}</td>
      <td class="ta-r num">${Fmt.gbp(Util.r2(pay))}</td>
      <td class="ta-r num">${Fmt.gbp(Util.r2(fort))}</td>`;
  }

  function colTotal(dayKey) {
    let pay = 0;
    activeWorkers().forEach((w) => {
      const c = (work.grid[w.id] || {})[dayKey];
      if (c && WORKED(c.t)) pay += cellHours(c) * hourly(w);
    });
    return Util.r2(pay);
  }

  /* ---- per-project totals panel ------------------------------------------ */
  function renderProjects() {
    const bySite = new Map();
    activeWorkers().forEach((w) => {
      const row = work.grid[w.id] || {};
      DAYS.forEach((d) => {
        const c = row[d.k];
        if (!c || !WORKED(c.t)) return;
        const h = cellHours(c); if (h <= 0) return;
        const key = c.site || "";
        const cur = bySite.get(key) || { name: siteName(c.site), hours: 0, cost: 0 };
        cur.hours += h; cur.cost += h * hourly(w);
        bySite.set(key, cur);
      });
    });
    const rows = [...bySite.values()].sort((a, b) => b.cost - a.cost);
    const total = Util.r2(rows.reduce((s, r) => s + r.cost, 0));
    const box = document.getElementById("ls-projects");
    const tot = document.getElementById("ls-projtot");
    if (tot) tot.textContent = Fmt.gbp(total);
    if (!box) return;
    box.innerHTML = rows.length ? `
      <table class="table table--tight">
        <thead><tr><th>Project</th><th class="ta-r">Hours</th><th class="ta-r">Labour cost</th></tr></thead>
        <tbody>${rows.map((r) => `<tr><td><strong>${esc(r.name)}</strong></td><td class="ta-r num">${Fmt.hours(r.hours)}</td><td class="ta-r num">${Fmt.gbp(Util.r2(r.cost))}</td></tr>`).join("")}</tbody>
        <tfoot><tr class="totals"><td>${rows.length} project${rows.length === 1 ? "" : "s"}</td><td class="ta-r num">${Fmt.hours(rows.reduce((s, r) => s + r.hours, 0))}</td><td class="ta-r num">${Fmt.gbp(total)}</td></tr></tfoot>
      </table>`
      : `<div class="empty"><div class="empty__title">No labour entered yet</div><div class="empty__text">Set workers’ days above to see project costs build up.</div></div>`;
  }

  /* ==========================================================================
     QUICK ACTIONS
     ========================================================================== */
  function fillRow(wid) {
    const sites = activeSites();
    const def = inheritSiteAnywhere(wid) || sites[0].id;
    DAYS.forEach((d) => { const c = cellOf(work.grid, wid, d.k); c.t = "full"; if (!c.site) c.site = def; });
    DAYS.forEach((d) => refreshCell(wid, d.k));
    afterCellChange(wid);
    UI.toast("Filled week as full days", "ok");
  }
  function inheritSiteAnywhere(wid) {
    const row = work.grid[wid] || {};
    for (const d of DAYS) { const c = row[d.k]; if (c && c.site) return c.site; }
    return "";
  }

  function copyPreviousWeek() {
    const prevISO = iso(addDays(weekStartDate(), -7));
    const prev = Store.all(COL).find((r) => r.weekStart === prevISO);
    if (!prev || !prev.grid || !Object.keys(prev.grid).length) { UI.toast("No data in the previous week", "danger"); return; }
    UI.confirm("Copy the previous week's entries over the current week? This replaces what's here now.", () => {
      const ids = new Set(activeWorkers().map((w) => w.id));
      const grid = {};
      Object.entries(prev.grid).forEach(([wid, row]) => { if (ids.has(wid)) grid[wid] = JSON.parse(JSON.stringify(row)); });
      work.grid = grid;
      flushNow();
      render(document.getElementById("view-root"));
      UI.toast("Previous week copied", "ok");
    });
  }

  function copyDayAcross() {
    const dayOpt = DAYS.map((d) => `<option value="${d.k}">${d.label}</option>`).join("");
    UI.modal({
      title: "Copy a day across the week",
      bodyHTML: `
        <div class="form-grid">
          <div class="field"><label class="field__label">Copy from</label><select class="input" id="cd-from">${dayOpt}</select></div>
          <div class="field"><label class="field__label">Apply to</label>
            <select class="input" id="cd-to">
              <option value="empty">Only empty days</option>
              <option value="all">All other days (overwrite)</option>
            </select></div>
        </div>
        <p class="hint">Copies the status and site of every worker from the chosen day.</p>`,
      saveLabel: "Copy day",
      onSave: (r) => {
        const from = r.querySelector("#cd-from").value;
        const mode = r.querySelector("#cd-to").value;
        activeWorkers().forEach((w) => {
          const row = work.grid[w.id]; if (!row) return;
          const src = row[from]; if (!src) return;
          DAYS.forEach((d) => {
            if (d.k === from) return;
            const dst = cellOf(work.grid, w.id, d.k);
            const isEmpty = !dst.t;
            if (mode === "empty" && !isEmpty) return;
            dst.t = src.t; dst.site = src.site; dst.h = src.h;
          });
        });
        flushNow();
        render(document.getElementById("view-root"));
        UI.toast("Day copied across", "ok");
      },
    });
  }

  function autoFillSite() {
    const sites = activeSites();
    const sOpts = sites.map((s) => `<option value="${s.id}">${esc(s.name)}</option>`).join("");
    UI.modal({
      title: "Auto-fill site",
      bodyHTML: `
        <div class="field"><label class="field__label">Site</label><select class="input" id="af-site">${sOpts}</select></div>
        <div class="field" style="margin-top:12px"><label class="field__label">Apply to</label>
          <select class="input" id="af-mode">
            <option value="blank">Worked days with no site yet</option>
            <option value="all">All worked days (overwrite)</option>
          </select></div>
        <p class="hint">Only days marked Full / Half / Custom are touched.</p>`,
      saveLabel: "Fill site",
      onSave: (r) => {
        const site = r.querySelector("#af-site").value;
        const mode = r.querySelector("#af-mode").value;
        let n = 0;
        activeWorkers().forEach((w) => {
          const row = work.grid[w.id]; if (!row) return;
          DAYS.forEach((d) => {
            const c = row[d.k];
            if (!c || !WORKED(c.t)) return;
            if (mode === "blank" && c.site) return;
            c.site = site; n++;
          });
        });
        flushNow();
        render(document.getElementById("view-root"));
        UI.toast(`Site set on ${n} day${n === 1 ? "" : "s"}`, "ok");
      },
    });
  }

  function bulkAssign() {
    const workers = activeWorkers();
    const sites = activeSites();
    const sOpts = sites.map((s) => `<option value="${s.id}">${esc(s.name)}</option>`).join("");
    const wList = workers.map((w) => `
      <label class="ls-check"><input type="checkbox" class="ba-w" value="${w.id}"><span>${esc(w.name)} <em>${esc(w.trade || "")}</em></span></label>`).join("");
    const dList = DAYS.map((d) => `<label class="ls-check ls-check--day"><input type="checkbox" class="ba-d" value="${d.k}" checked><span>${d.label}</span></label>`).join("");
    UI.modal({
      title: "Bulk assign workers to a site",
      size: "lg",
      bodyHTML: `
        <div class="form-grid">
          <div class="field"><label class="field__label">Site</label><select class="input" id="ba-site">${sOpts}</select></div>
          <div class="field"><label class="field__label">Day type</label>
            <select class="input" id="ba-type"><option value="full">Full day</option><option value="half">Half day</option></select></div>
        </div>
        <div class="field" style="margin-top:6px"><label class="field__label">Days</label><div class="ls-checks ls-checks--days">${dList}</div></div>
        <div class="field" style="margin-top:12px">
          <label class="field__label">Workers <button type="button" class="ls-selall" id="ba-all">select all</button></label>
          <div class="ls-checks">${wList}</div>
        </div>`,
      saveLabel: "Assign",
      onSave: (r) => {
        const site = r.querySelector("#ba-site").value;
        const type = r.querySelector("#ba-type").value;
        const wids = [...r.querySelectorAll(".ba-w:checked")].map((c) => c.value);
        const days = [...r.querySelectorAll(".ba-d:checked")].map((c) => c.value);
        if (!wids.length) { UI.toast("Pick at least one worker", "danger"); return false; }
        if (!days.length) { UI.toast("Pick at least one day", "danger"); return false; }
        wids.forEach((wid) => days.forEach((dk) => { const c = cellOf(work.grid, wid, dk); c.t = type; c.site = site; c.h = ""; }));
        flushNow();
        render(document.getElementById("view-root"));
        UI.toast(`Assigned ${wids.length} worker${wids.length === 1 ? "" : "s"} to ${siteName(site)}`, "ok");
      },
    });
    const all = document.getElementById("ba-all");
    if (all) all.addEventListener("click", (e) => {
      e.preventDefault();
      const boxes = document.querySelectorAll(".ba-w");
      const anyOff = [...boxes].some((b) => !b.checked);
      boxes.forEach((b) => (b.checked = anyOff));
    });
  }

  function clearWeek() {
    if (!Object.keys(work.grid).length) { UI.toast("Week is already empty", "info"); return; }
    UI.confirm("Clear all entries for this week? Linked payroll timesheets for the week are removed too.", () => {
      work.grid = blankGrid();
      flushNow();
      render(document.getElementById("view-root"));
      UI.toast("Week cleared", "info");
    });
  }

  /* ==========================================================================
     STYLES (scoped, injected once — keeps this a single self-contained file)
     ========================================================================== */
  function injectStyles() {
    if (document.getElementById("labour-sheet-styles")) return;
    const css = `
      .ls-actions { display:flex; flex-wrap:wrap; gap:8px; margin:14px 0; }
      .ls-wrap { overflow:auto; max-height:none; }
      .ls-table { font-size:0.84rem; }
      .ls-table th, .ls-table td { padding:8px 10px; vertical-align:top; }
      .ls-table thead th { position:sticky; top:0; z-index:2; background:var(--surface); }
      .ls-table th.ls-name, .ls-table td.ls-name { position:sticky; left:0; z-index:3; background:var(--surface); min-width:172px; }
      .ls-table thead th.ls-name { z-index:4; }
      .ls-table tbody tr:hover td.ls-name { background:var(--surface-2); }
      .ls-dayhead { text-align:center !important; min-width:132px; }
      .ls-daydate { display:block; font-size:0.62rem; color:var(--text-faint); margin-top:2px; }
      .ls-name strong { display:block; line-height:1.2; }
      .ls-trade { font-size:0.72rem; color:var(--text-faint); }
      .ls-fillrow { display:block; margin-top:4px; background:none; border:0; padding:0; cursor:pointer;
        font-family:var(--font-mono); font-size:0.66rem; color:var(--text-faint); letter-spacing:.03em; }
      .ls-fillrow:hover { color:var(--accent); }
      .ls-rate { min-width:104px; }
      .ls-rate-wrap { display:flex; align-items:center; gap:3px; color:var(--text-muted); font-size:0.8rem; }
      .ls-rate-sub { display:block; font-size:0.66rem; color:var(--text-faint); margin-top:3px; }
      .input--cell { padding:6px 8px; font-size:0.8rem; border-radius:6px; width:100%; }
      .ls-rateinp { width:64px; }
      .ls-cell { background:var(--surface); }
      .ls-cell.is-worked { background:var(--accent-soft); }
      /* day cell: dropdown sits on top, the "S" site tab is tucked behind its
         left edge so only the left half peeks out. Pinned inside the cell, so
         every day (incl. Mon) shows one and nothing spills past Saturday. */
      .ls-day { position:relative; padding-left:12px; }
      .ls-day .ls-type { position:relative; z-index:1; margin-bottom:4px; }
      /* "S" site tab: tucked behind the dropdown's left edge (only the left half
         peeks out), always clickable, same solid look on every row. */
      .ls-sitepick { position:absolute; left:0; top:3px; z-index:0; box-sizing:border-box;
        width:24px; height:26px; display:flex; align-items:center; padding-left:3px;
        border:1px solid var(--border); border-radius:5px; background:var(--surface);
        font-family:var(--font-mono); font-size:0.7rem; color:var(--text-muted);
        cursor:pointer; user-select:none; }
      .ls-sitepick:hover { border-color:var(--text-faint); }
      .ls-sitepick.is-set { border-color:var(--text-faint); color:var(--text); }
      .ls-sitepick__tag { pointer-events:none; }
      .ls-sitepick .ls-site { position:absolute; inset:0; width:100%; height:100%; margin:0; padding:0; border:0; opacity:0; cursor:pointer; }
      /* Custom hours: type straight over the dropdown in the same spot (no new
         box below). The select's chevron stays exposed on the right so you can
         switch back to Full / Half. */
      .ls-cell .ls-hrs { position:absolute; top:0; left:12px; right:28px; z-index:3;
        width:auto; margin:0; text-align:center; }
      .ls-fort { color:var(--text-muted); }
      .ls-saved { font-family:var(--font-mono); font-size:0.72rem; color:var(--ok, #4ba36b); white-space:nowrap; align-self:center; }
      .ls-saved--dirty { color:var(--accent-strong); }
      .ls-coltot { color:var(--text-muted); }
      .ls-checks { display:grid; grid-template-columns:repeat(auto-fill,minmax(150px,1fr)); gap:6px 14px; max-height:240px; overflow:auto;
        border:1px solid var(--border); border-radius:var(--r-sm); padding:10px 12px; background:var(--surface-2); }
      .ls-checks--days { grid-template-columns:repeat(6,auto); max-height:none; }
      .ls-check { display:flex; align-items:center; gap:7px; font-size:0.82rem; cursor:pointer; }
      .ls-check em { color:var(--text-faint); font-style:normal; font-size:0.72rem; }
      .ls-check input { accent-color:var(--accent); }
      .ls-selall { background:none; border:0; color:var(--accent); cursor:pointer; font-size:0.7rem; font-weight:600; margin-left:8px; }
    `;
    const tag = document.createElement("style");
    tag.id = "labour-sheet-styles"; tag.textContent = css;
    document.head.appendChild(tag);
  }

  /* ==========================================================================
     DASHBOARD STAT + REGISTRATION
     ========================================================================== */
  Dashboard.addStat(() => {
    const wsISO = Period.workWeekRange().from;
    const rec = Store.all(COL).find((r) => r.weekStart === wsISO);
    let cost = 0, workers = 0;
    if (rec && rec.grid) {
      Object.entries(rec.grid).forEach(([wid, row]) => {
        const w = Store.find("workers", wid); if (!w) return;
        let any = 0;
        DAYS.forEach((d) => {
          const c = row[d.k];
          if (c && WORKED(c.t)) { const h = cellHours(c); cost += h * (Number(w.rate) || 0); any += h; }
        });
        if (any > 0) workers++;
      });
    }
    return { label: "Labour this week", value: Fmt.gbp(Util.r2(cost)), note: `${workers} worker${workers === 1 ? "" : "s"} entered`, route: "labour-sheet" };
  }, "Manager");

  Modules.register({
    id: "labour-sheet", label: "Labour Sheet", title: "Weekly Labour Sheet", minRole: "Manager",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M3 15h18M9 3v18"/></svg>',
    render,
  });
})();
