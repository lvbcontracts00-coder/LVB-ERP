/* ==========================================================================
   modules/documents.js — Document storage (Phase 5)
   Metadata in Store collection "documents"; the file itself under a dedicated
   "docfile:<id>" key (kept out of the collection to isolate large blobs, like
   expense receipts). Record: { id, title, category, siteId, date, fileName,
   mimeType, size, hasFile, notes }.
   NOTE: localStorage is ~5MB total — this prototype suits a few small files,
   not a document archive. A real deployment needs server/object storage.
   ========================================================================== */
(() => {
  "use strict";
  const COL = "documents";
  const MAX_BYTES = 2 * 1024 * 1024; // ~2MB per file (base64 inflates ~33%)
  const canEdit = () => Auth.can("Manager");
  const CATEGORIES = ["Contract", "Drawing", "Certificate", "Insurance", "Warranty", "Photo", "Specification", "Permit", "Other"];

  const opts = (list, sel) => list.map((o) => `<option value="${esc(o)}"${o === sel ? " selected" : ""}>${esc(o)}</option>`).join("");
  const siteName = (id) => id ? ((Store.find("sites", id) || {}).name || "Unknown") : "—";
  function siteOptions(sel) { return `<option value="">— none —</option>` + Store.all("sites").map((s) => `<option value="${s.id}"${s.id === sel ? " selected" : ""}>${esc(s.name)}</option>`).join(""); }
  const kb = (n) => n ? Math.round(n / 1024) + " KB" : "—";

  /* image compression + data-URL reading now live in Util (Phase 6 dedup) */

  function openForm(existing) {
    let pending = null, pendingMeta = null, removeFile = false;
    const hasExisting = existing && existing.hasFile;
    UI.modal({
      title: existing ? "Edit document" : "Add document", size: "lg",
      saveLabel: existing ? "Save changes" : "Add document",
      bodyHTML: `
        <div class="form-grid">
          <div class="field span-2"><label class="field__label">Title *</label>
            <input class="input" id="d-title" value="${esc((existing && existing.title) || "")}" placeholder="e.g. Party wall agreement"></div>
          <div class="field"><label class="field__label">Category</label>
            <select class="input" id="d-cat">${opts(CATEGORIES, (existing && existing.category) || "Other")}</select></div>
          <div class="field"><label class="field__label">Date</label>
            <input class="input" id="d-date" type="date" value="${esc((existing && existing.date) || Fmt.todayISO())}"></div>
          <div class="field span-2"><label class="field__label">Project</label>
            <select class="input" id="d-site">${siteOptions(existing && existing.siteId)}</select></div>
          <div class="field span-2"><label class="field__label">File</label>
            <div class="receipt-input">
              <input type="file" id="d-file" accept="image/*,application/pdf">
              <div id="d-state" class="hint">${hasExisting ? `Attached: ${esc(existing.fileName || "file")} (${kb(existing.size)})` : "No file. Images are compressed; PDFs up to ~2MB."}</div>
              <button type="button" class="btn btn--sm btn--danger" id="d-clear"${hasExisting ? "" : " hidden"}>Remove file</button>
            </div></div>
          <div class="field span-2"><label class="field__label">Notes</label>
            <textarea class="input" id="d-notes" rows="2">${esc((existing && existing.notes) || "")}</textarea></div>
        </div>`,
      onSave: (r) => {
        const title = r.querySelector("#d-title").value.trim();
        if (!title) { UI.toast("Title is required", "danger"); return false; }
        const data = { title, category: r.querySelector("#d-cat").value, date: r.querySelector("#d-date").value,
          siteId: r.querySelector("#d-site").value, notes: r.querySelector("#d-notes").value.trim() };
        let rec = existing ? Store.update(COL, existing.id, data) : Store.insert(COL, { ...data, hasFile: false });
        const key = "docfile:" + rec.id;
        if (pending) {
          const ok = Store.write(key, pending);
          if (!ok) { UI.toast("Saved, but the file was too large for local storage", "danger"); Store.update(COL, rec.id, { hasFile: false }); }
          else Store.update(COL, rec.id, { hasFile: true, fileName: pendingMeta.name, mimeType: pendingMeta.type, size: pendingMeta.size });
        } else if (removeFile && hasExisting) { Store.remove(key); Store.update(COL, rec.id, { hasFile: false, fileName: "", mimeType: "", size: 0 }); }
        UI.toast(existing ? "Document updated" : "Document added", "ok");
        render(document.getElementById("view-root"));
      },
    });
    const mr = document.getElementById("modal-root");
    mr.querySelector("#d-file").addEventListener("change", async (e) => {
      const f = e.target.files[0]; if (!f) return;
      try {
        let dataURL = f.type.startsWith("image/") ? await Util.compressImage(f, { max: 1600, quality: 0.7 }) : await Util.readDataURL(f);
        if (dataURL.length > MAX_BYTES * 1.37) { UI.toast("File too large for local storage (~2MB max)", "danger"); mr.querySelector("#d-file").value = ""; return; }
        pending = dataURL; removeFile = false; pendingMeta = { name: f.name, type: f.type || "application/octet-stream", size: Math.round(dataURL.length * 0.73) };
        mr.querySelector("#d-state").textContent = `Ready: ${f.name} (${kb(pendingMeta.size)})`;
        mr.querySelector("#d-clear").hidden = false;
      } catch { UI.toast("Could not read that file", "danger"); }
    });
    mr.querySelector("#d-clear").addEventListener("click", () => {
      pending = null; removeFile = true; mr.querySelector("#d-file").value = "";
      mr.querySelector("#d-state").textContent = "File will be removed on save."; mr.querySelector("#d-clear").hidden = true;
    });
  }

  function viewFile(rec) {
    const data = Store.read("docfile:" + rec.id);
    if (!data) { UI.toast("File not found", "danger"); return; }
    const body = (rec.mimeType || "").startsWith("image/")
      ? `<img src="${data}" class="receipt-full" alt="${esc(rec.title)}">`
      : `<p class="hint" style="margin-bottom:12px">${esc(rec.fileName || "file")} · ${kb(rec.size)}</p><a class="btn btn--primary" href="${data}" download="${esc(rec.fileName || rec.title)}">Download file</a>`;
    UI.modal({ title: rec.title, size: "lg", bodyHTML: body });
  }
  function remove(rec) {
    UI.confirm(`Delete "${rec.title}"? The stored file is removed too.`, () => {
      Store.remove("docfile:" + rec.id); Store.destroy(COL, rec.id); UI.toast("Document deleted", "info");
      render(document.getElementById("view-root"));
    });
  }

  let term = "";
  function render(root) {
    const all = Store.all(COL).sort((a, b) => (b.date || "").localeCompare(a.date || ""));
    const rows = all.filter((d) => !term || (d.title + " " + d.category + " " + siteName(d.siteId)).toLowerCase().includes(term.toLowerCase()));

    root.innerHTML = `
      <div class="toolbar">
        <div class="toolbar__left">
          <input class="input input--search" id="d-search" placeholder="Search documents…" value="${esc(term)}">
          <span class="muted-count num">${all.length} document${all.length === 1 ? "" : "s"}</span>
        </div>
        ${canEdit() ? `<button class="btn btn--primary" id="d-add">＋ Add document</button>` : ""}
      </div>
      ${rows.length ? `
        <div class="table-wrap"><table class="table">
          <thead><tr><th>Title</th><th>Category</th><th>Project</th><th>Date</th><th>File</th>${canEdit() ? `<th class="ta-r">Actions</th>` : ""}</tr></thead>
          <tbody>${rows.map((d) => `
            <tr>
              <td><strong>${esc(d.title)}</strong>${d.notes ? `<div class="muted-count">${esc(d.notes)}</div>` : ""}</td>
              <td><span class="badge badge--muted">${esc(d.category || "—")}</span></td>
              <td>${esc(siteName(d.siteId))}</td>
              <td class="num">${Fmt.date(d.date)}</td>
              <td>${d.hasFile ? `<button class="btn btn--sm" data-view="${d.id}">📎 ${esc((d.mimeType || "").startsWith("image/") ? "View" : "Open")}</button>` : `<span class="muted-count">—</span>`}</td>
              ${canEdit() ? `<td class="ta-r nowrap"><button class="btn btn--sm" data-edit="${d.id}">Edit</button><button class="btn btn--sm btn--danger" data-del="${d.id}">Del</button></td>` : ""}
            </tr>`).join("")}</tbody>
        </table></div>`
      : `<div class="panel"><div class="panel__body"><div class="empty">
          <svg class="empty__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M6 2h9l5 5v15H6z"/><path d="M14 2v6h6M9 13h6M9 17h6"/></svg>
          <div class="empty__title">${all.length === 0 ? "No documents yet" : "No matches"}</div>
          <div class="empty__text">${all.length === 0 ? (canEdit() ? "Upload contracts, certificates, drawings or photos." : "Ask a manager to add documents.") : "Try a different search."}</div>
        </div></div></div>`}
    `;
    const search = root.querySelector("#d-search");
    search.addEventListener("input", () => { term = search.value; render(root); const s = document.getElementById("d-search"); if (s) { s.focus(); s.setSelectionRange(s.value.length, s.value.length); } });
    const add = root.querySelector("#d-add"); if (add) add.addEventListener("click", () => openForm(null));
    root.querySelectorAll("[data-view]").forEach((b) => b.addEventListener("click", () => viewFile(Store.find(COL, b.dataset.view))));
    root.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => openForm(Store.find(COL, b.dataset.edit))));
    root.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => remove(Store.find(COL, b.dataset.del))));
  }

  Modules.section("Compliance");
  Modules.register({
    id: "documents", label: "Documents", title: "Document Storage", minRole: "Viewer",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2h9l5 5v15H6z"/><path d="M14 2v6h6"/></svg>',
    render,
  });
})();
