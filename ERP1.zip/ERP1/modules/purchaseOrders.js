/* ==========================================================================
   modules/purchaseOrders.js — Purchase orders (Phase 3)
   Thin config over Commercial.docModule. Store collection "purchaseOrders".
   POs are addressed to suppliers; line items + VAT; PDF-ready preview.
   ========================================================================== */
(() => {
  "use strict";

  Commercial.docModule({
    id: "purchaseOrders", label: "Purchase Orders", title: "Purchase Orders", noun: "purchase order",
    collection: "purchaseOrders", prefix: "PO", docTitle: "PURCHASE ORDER",
    minRole: "Viewer", editRole: "Manager",
    party: { coll: "suppliers", label: "Supplier", route: "suppliers" },
    dateLabel: "Date", date2: { label: "Required by" },
    statuses: [
      { value: "Draft", badge: "muted" },
      { value: "Ordered", badge: "warn" },
      { value: "Received", badge: "ok" },
      { value: "Cancelled", badge: "danger" },
    ],
    defaultStatus: "Draft",
    quickStatus: { to: "Received", label: "Mark received", when: (d) => d.status === "Ordered" },
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 4h2l2.5 12h10L20 7H6.5"/><circle cx="9" cy="20" r="1.5"/><circle cx="17" cy="20" r="1.5"/></svg>',
    // dashboard: committed spend on open POs (Draft + Ordered)
    stat: () => {
      const open = Store.all("purchaseOrders").filter((p) => p.status === "Draft" || p.status === "Ordered");
      const val = open.reduce((s, p) => s + Commercial.Money.totals(p.items, p.vatRate).total, 0);
      return { label: "Open POs", value: String(open.length), note: `${Fmt.gbp(val)} committed`, route: "purchaseOrders" };
    },
  });
})();
