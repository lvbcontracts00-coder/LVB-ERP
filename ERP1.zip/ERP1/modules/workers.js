/* ==========================================================================
   modules/workers.js — Worker management (Phase 2)
   Self-registers a route + nav item + dashboard stat on load.
   Data lives in Store collection "workers".
   Record: { id, name, trade, phone, rate, status, startDate, cscs, notes }
   ========================================================================== */
(() => {
  "use strict";
  const COL = "workers";

  const TRADES = [
    "Labourer", "Groundworker", "Bricklayer", "Carpenter", "Joiner", "Electrician",
    "Plumber", "Plasterer", "Painter & Decorator", "Roofer", "Tiler", "Scaffolder",
    "Steel Fixer", "Plant Operator", "Site Manager", "Other",
  ];
  const STATUSES = ["Active", "Inactive"];
  const CSCS = ["None", "Green (Labourer)", "Blue (Skilled)", "Gold (Supervisor)", "Black (Manager)", "White (Professional)"];

  const canEdit = () => Auth.can("Manager");
  const opts = (list, sel) => list.map((o) => `<option value="${esc(o)}"${o === sel ? " selected" : ""}>${esc(o)}</option>`).join("");

  /* ---- form + save ------------------------------------------------------- */
  function form(w) {
    w = w || {}; // null-safe: JS default params apply to undefined only, not null
    return `
      <div class="form-grid">
        <div class="field span-2"><label class="field__label">Full name *</label>
          <input class="input" id="w-name" value="${esc(w.name || "")}" placeholder="e.g. John Smith"></div>
        <div class="field"><label class="field__label">Trade</label>
          <select class="input" id="w-trade">${opts(TRADES, w.trade || "Labourer")}</select></div>
        <div class="field"><label class="field__label">Hourly rate (£) *</label>
          <input class="input" id="w-rate" type="number" min="0" step="0.50" value="${w.rate ?? ""}" placeholder="18.50"></div>
        <div class="field"><label class="field__label">Phone</label>
          <input class="input" id="w-phone" value="${esc(w.phone || "")}" placeholder="07…"></div>
        <div class="field"><label class="field__label">Status</label>
          <select class="input" id="w-status">${opts(STATUSES, w.status || "Active")}</select></div>
        <div class="field"><label class="field__label">CSCS card</label>
          <select class="input" id="w-cscs">${opts(CSCS, w.cscs || "None")}</select></div>
        <div class="field"><label class="field__label">Start date</label>
          <input class="input" id="w-start" type="date" value="${esc(w.startDate || "")}"></div>
        <div class="field span-2"><label class="field__label">Notes</label>
          <textarea class="input" id="w-notes" rows="2" placeholder="Optional">${esc(w.notes || "")}</textarea></div>
      </div>`;
  }

  function read(rootEl) {
    return {
      name: rootEl.querySelector("#w-name").value.trim(),
      trade: rootEl.querySelector("#w-trade").value,
      rate: parseFloat(rootEl.querySelector("#w-rate").value),
      phone: rootEl.querySelector("#w-phone").value.trim(),
      status: rootEl.querySelector("#w-status").value,
      cscs: rootEl.querySelector("#w-cscs").value,
      startDate: rootEl.querySelector("#w-start").value,
      notes: rootEl.querySelector("#w-notes").value.trim(),
    };
  }

  function openForm(existing) {
    UI.modal({
      title: existing ? "Edit worker" : "Add worker",
      size: "lg",
      bodyHTML: form(existing),
      saveLabel: existing ? "Save changes" : "Add worker",
      onSave: (rootEl) => {
        const data = read(rootEl);
        if (!data.name) { UI.toast("Name is required", "danger"); return false; }
        if (isNaN(data.rate) || data.rate < 0) { UI.toast("Enter a valid hourly rate", "danger"); return false; }
        if (existing) { Store.update(COL, existing.id, data); UI.toast("Worker updated", "ok"); }
        else { Store.insert(COL, data); UI.toast("Worker added", "ok"); }
        render(document.getElementById("view-root"));
      },
    });
  }

  function remove(w) {
    UI.confirm(`Delete ${w.name}? This cannot be undone.`, () => {
      Store.destroy(COL, w.id);
      UI.toast("Worker deleted", "info");
      render(document.getElementById("view-root"));
    });
  }

  /* ---- render ------------------------------------------------------------ */
  let term = "";

  function render(root) {
    const all = Store.all(COL);
    const rows = all.filter((w) =>
      !term || (w.name + " " + w.trade).toLowerCase().includes(term.toLowerCase())
    );

    root.innerHTML = `
      <div class="toolbar">
        <div class="toolbar__left">
          <input class="input input--search" id="w-search" placeholder="Search workers…" value="${esc(term)}">
          <span class="muted-count num">${all.length} total</span>
        </div>
        ${canEdit() ? `<button class="btn btn--primary" id="w-add">＋ Add worker</button>` : ""}
      </div>

      ${rows.length ? `
        <div class="table-wrap"><table class="table">
          <thead><tr>
            <th>Name</th><th>Trade</th><th>Phone</th><th class="ta-r">Rate</th><th>CSCS</th><th>Status</th>
            ${canEdit() ? `<th class="ta-r">Actions</th>` : ""}
          </tr></thead>
          <tbody>
            ${rows.map((w) => `
              <tr>
                <td><strong>${esc(w.name)}</strong></td>
                <td>${esc(w.trade || "—")}</td>
                <td class="num">${esc(w.phone || "—")}</td>
                <td class="ta-r num">${Fmt.gbp(w.rate)}/hr</td>
                <td>${esc((w.cscs || "None").split(" ")[0])}</td>
                <td><span class="badge badge--${w.status === "Active" ? "ok" : "muted"}">${esc(w.status)}</span></td>
                ${canEdit() ? `<td class="ta-r nowrap">
                  <button class="btn btn--sm" data-edit="${w.id}">Edit</button>
                  <button class="btn btn--sm btn--danger" data-del="${w.id}">Delete</button></td>` : ""}
              </tr>`).join("")}
          </tbody>
        </table></div>`
      : emptyState(all.length === 0)}
    `;

    // wiring
    const search = root.querySelector("#w-search");
    search.addEventListener("input", () => { term = search.value; render(root);
      const s = document.getElementById("w-search"); if (s) { s.focus(); s.setSelectionRange(s.value.length, s.value.length); } });
    const add = root.querySelector("#w-add");
    if (add) add.addEventListener("click", () => openForm(null));
    root.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => openForm(Store.find(COL, b.dataset.edit))));
    root.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => remove(Store.find(COL, b.dataset.del))));
  }

  function emptyState(reallyEmpty) {
    return `<div class="panel"><div class="panel__body"><div class="empty">
      <svg class="empty__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>
      <div class="empty__title">${reallyEmpty ? "No workers yet" : "No matches"}</div>
      <div class="empty__text">${reallyEmpty ? (canEdit() ? "Add your first worker to get started." : "Ask a manager to add workers.") : "Try a different search."}</div>
    </div></div></div>`;
  }

  /* ---- dashboard stat ---------------------------------------------------- */
  Dashboard.addStat(() => {
    const active = Store.all(COL).filter((w) => w.status === "Active").length;
    return { label: "Active workers", value: String(active), note: `${Store.all(COL).length} on the books`, route: "workers" };
  });

  /* ---- register ---------------------------------------------------------- */
  Modules.register({
    id: "workers", label: "Workers", title: "Workers", minRole: "Viewer",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 5.5a3 3 0 0 1 0 5.8M18 20a6 6 0 0 0-3.2-5.3"/></svg>',
    render,
  });
})();
