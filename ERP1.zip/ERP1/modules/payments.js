/* ==========================================================================
   modules/payments.js — Client payments (Phase 3.5)
   Store collection "payments".
   Record: { id, invoiceId, clientId, siteId (project), amount, date, reference }
   Outstanding balance is DERIVED: invoice total − payments against it.

   Integrations:
   - Finance.collected() → revenue (cash) / profitability / cash flow
   - syncs the linked invoice status to "Paid" when fully settled
   - dashboard: cash collected this month
   ========================================================================== */
(() => {
  "use strict";
  const COL = "payments";
  const canEdit = () => Auth.can("Manager");

  const invTotal = (inv) => Commercial.Money.totals(inv.items, inv.vatRate).total;
  const paidFor = (invId) => Commercial.Money.r2(Store.all(COL).filter((p) => p.invoiceId === invId).reduce((s, p) => s + (Number(p.amount) || 0), 0));
  const outstandingFor = (inv) => Commercial.Money.r2(invTotal(inv) - paidFor(inv.id));
  const clientName = (id) => (Store.find("clients", id) || {}).name || "—";
  const siteName = (id) => id ? ((Store.find("sites", id) || {}).name || "Unknown") : "—";
  const invNumber = (id) => (Store.find("invoices", id) || {}).number || "(deleted)";

  /** Keep the invoice status consistent with how much has been paid. */
  function syncInvoice(invId) {
    const inv = Store.find("invoices", invId); if (!inv) return;
    const total = invTotal(inv), paid = paidFor(invId);
    if (total > 0 && paid + 0.005 >= total) { if (inv.status !== "Paid") Store.update("invoices", invId, { status: "Paid" }); }
    else if (inv.status === "Paid") { Store.update("invoices", invId, { status: "Sent" }); }
  }

  /* ---- form -------------------------------------------------------------- */
  function invoiceOptions(sel) {
    // payable = any non-draft invoice (show outstanding inline)
    const list = Store.all("invoices").filter((i) => i.status !== "Draft").sort((a, b) => (b.seq || 0) - (a.seq || 0));
    return list.map((i) => {
      const out = outstandingFor(i);
      return `<option value="${i.id}"${i.id === sel ? " selected" : ""}>${esc(i.number)} · ${esc(clientName(i.partyId))} · ${out > 0 ? Fmt.gbp(out) + " due" : "settled"}</option>`;
    }).join("");
  }

  function openForm(existing) {
    const payable = Store.all("invoices").filter((i) => i.status !== "Draft");
    if (!payable.length) {
      UI.toast("No issued invoices to record a payment against", "danger");
      Router.navigate("invoices"); return;
    }

    const startInv = existing ? Store.find("invoices", existing.invoiceId) : Store.find("invoices", payable.sort((a, b) => (b.seq || 0) - (a.seq || 0))[0].id);

    UI.modal({
      title: existing ? "Edit payment" : "Record payment", size: "lg",
      saveLabel: existing ? "Save changes" : "Record payment",
      bodyHTML: `
        <div class="form-grid">
          <div class="field span-2"><label class="field__label">Invoice *</label>
            <select class="input" id="y-inv">${invoiceOptions(existing ? existing.invoiceId : startInv.id)}</select></div>
          <div class="field"><label class="field__label">Amount paid (£) *</label>
            <input class="input" id="y-amount" type="number" min="0" step="0.01" value="${(existing && existing.amount) ?? ""}"></div>
          <div class="field"><label class="field__label">Payment date *</label>
            <input class="input" id="y-date" type="date" value="${esc((existing && existing.date) || Fmt.todayISO())}"></div>
          <div class="field span-2"><label class="field__label">Reference / method</label>
            <input class="input" id="y-ref" value="${esc((existing && existing.reference) || "")}" placeholder="e.g. Bank transfer, ref 1234"></div>
        </div>
        <div class="pay-summary" id="y-summary"></div>`,
      onSave: (r) => {
        const invId = r.querySelector("#y-inv").value;
        const inv = Store.find("invoices", invId);
        const amount = parseFloat(r.querySelector("#y-amount").value);
        if (!inv) { UI.toast("Pick an invoice", "danger"); return false; }
        if (isNaN(amount) || amount <= 0) { UI.toast("Enter a valid amount", "danger"); return false; }
        const data = {
          invoiceId: invId, clientId: inv.partyId, siteId: inv.siteId || "",
          amount, date: r.querySelector("#y-date").value, reference: r.querySelector("#y-ref").value.trim(),
        };
        const prevInv = existing ? existing.invoiceId : null;
        if (existing) Store.update(COL, existing.id, data);
        else Store.insert(COL, data);
        if (prevInv && prevInv !== invId) syncInvoice(prevInv);
        syncInvoice(invId);
        UI.toast("Payment recorded", "ok");
        render(document.getElementById("view-root"));
      },
    });

    // live outstanding summary + autofill amount with outstanding
    const mr = document.getElementById("modal-root");
    const sel = mr.querySelector("#y-inv"), amt = mr.querySelector("#y-amount"), sum = mr.querySelector("#y-summary");
    function refresh(autofill) {
      const inv = Store.find("invoices", sel.value); if (!inv) return;
      const total = invTotal(inv), already = paidFor(inv.id) - (existing && existing.invoiceId === inv.id ? (Number(existing.amount) || 0) : 0);
      const out = Commercial.Money.r2(total - already);
      if (autofill && !existing) amt.value = out > 0 ? out : "";
      const paying = parseFloat(amt.value) || 0;
      const after = Commercial.Money.r2(out - paying);
      sum.innerHTML = `
        <div class="pay-summary__row"><span>Invoice total</span><span class="num">${Fmt.gbp(total)}</span></div>
        <div class="pay-summary__row"><span>Already paid</span><span class="num">${Fmt.gbp(already)}</span></div>
        <div class="pay-summary__row"><span>Outstanding now</span><span class="num">${Fmt.gbp(out)}</span></div>
        <div class="pay-summary__row pay-summary__after"><span>Outstanding after this payment</span><span class="num">${Fmt.gbp(after < 0 ? 0 : after)}</span></div>
        ${after < -0.005 ? `<div class="hint" style="color:var(--warn)">This exceeds the outstanding balance — invoice will be marked Paid.</div>` : ""}`;
    }
    sel.addEventListener("change", () => refresh(true));
    amt.addEventListener("input", () => refresh(false));
    refresh(!existing);
  }

  function remove(p) {
    UI.confirm("Delete this payment?", () => {
      const invId = p.invoiceId;
      Store.destroy(COL, p.id);
      syncInvoice(invId);
      UI.toast("Payment deleted", "info");
      render(document.getElementById("view-root"));
    });
  }

  /* ---- render ------------------------------------------------------------ */
  let period = "all"; // all | this-month

  function render(root) {
    const { from, to } = Period.range(period === "this-month" ? "this-month" : "all");
    const all = Store.all(COL).sort((a, b) => (b.date || "").localeCompare(a.date || ""));
    const rows = all.filter((p) => Period.inRange(p.date, from, to));
    const collected = rows.reduce((s, p) => s + (Number(p.amount) || 0), 0);

    // total outstanding across all issued invoices (AR)
    const ar = Store.all("invoices").filter((i) => i.status !== "Draft").reduce((s, i) => s + outstandingFor(i), 0);

    const pOpts = [["all", "All time"], ["this-month", "This month"]].map(([v, l]) => `<option value="${v}"${period === v ? " selected" : ""}>${l}</option>`).join("");

    root.innerHTML = `
      <div class="toolbar">
        <div class="toolbar__left filterbar">
          <select class="input" id="y-period">${pOpts}</select>
          <span class="muted-count num">${Fmt.gbp(collected)} collected · ${Fmt.gbp(Commercial.Money.r2(ar))} outstanding</span>
        </div>
        ${canEdit() ? `<button class="btn btn--primary" id="y-add">＋ Record payment</button>` : ""}
      </div>
      ${rows.length ? `
        <div class="table-wrap"><table class="table">
          <thead><tr><th>Date</th><th>Invoice</th><th>Client</th><th>Project</th><th>Reference</th><th class="ta-r">Amount</th><th class="ta-r">Invoice balance</th>${canEdit() ? `<th class="ta-r">Actions</th>` : ""}</tr></thead>
          <tbody>${rows.map((p) => {
            const inv = Store.find("invoices", p.invoiceId);
            const bal = inv ? outstandingFor(inv) : 0;
            return `<tr>
              <td class="num">${Fmt.date(p.date)}</td>
              <td><strong>${esc(invNumber(p.invoiceId))}</strong></td>
              <td>${esc(clientName(p.clientId))}</td>
              <td>${esc(siteName(p.siteId))}</td>
              <td>${esc(p.reference || "—")}</td>
              <td class="ta-r num">${Fmt.gbp(p.amount)}</td>
              <td class="ta-r num">${inv ? (bal > 0.005 ? Fmt.gbp(bal) : `<span class="badge badge--ok">Settled</span>`) : "—"}</td>
              ${canEdit() ? `<td class="ta-r nowrap"><button class="btn btn--sm" data-edit="${p.id}">Edit</button><button class="btn btn--sm btn--danger" data-del="${p.id}">Del</button></td>` : ""}
            </tr>`; }).join("")}</tbody>
          <tfoot><tr class="totals"><td colspan="5">${rows.length} payment${rows.length === 1 ? "" : "s"}</td><td class="ta-r num">${Fmt.gbp(collected)}</td><td colspan="${canEdit() ? 2 : 1}"></td></tr></tfoot>
        </table></div>`
      : `<div class="panel"><div class="panel__body"><div class="empty">
          <svg class="empty__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="6" width="20" height="12" rx="2"/><path d="M2 10h20"/></svg>
          <div class="empty__title">No payments recorded ${period === "all" ? "yet" : "this month"}</div>
          <div class="empty__text">${canEdit() ? "Record a client payment against an issued invoice." : "Ask a manager to record payments."}</div>
        </div></div></div>`}
    `;

    root.querySelector("#y-period").addEventListener("change", (e) => { period = e.target.value; render(root); });
    const add = root.querySelector("#y-add"); if (add) add.addEventListener("click", () => openForm(null));
    root.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => openForm(Store.find(COL, b.dataset.edit))));
    root.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => remove(Store.find(COL, b.dataset.del))));
  }

  /* ---- dashboard stat ---------------------------------------------------- */
  Dashboard.addStat(() => {
    const { from, to } = Period.range("this-month");
    const mtd = Store.all(COL).filter((p) => Period.inRange(p.date, from, to)).reduce((s, p) => s + (Number(p.amount) || 0), 0);
    const total = Store.all(COL).reduce((s, p) => s + (Number(p.amount) || 0), 0);
    return { label: "Collected (MTD)", value: Fmt.gbp(mtd), note: `${Fmt.gbp(total)} all time`, route: "payments" };
  });

  Modules.register({
    id: "payments", label: "Payments", title: "Client Payments", minRole: "Viewer",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="6" width="20" height="12" rx="2"/><path d="M2 10h20"/><circle cx="7" cy="14" r="1.3"/></svg>',
    render,
  });
})();
