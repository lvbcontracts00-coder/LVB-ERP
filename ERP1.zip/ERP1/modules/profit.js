/* ==========================================================================
   modules/profit.js — Project costing & profitability (Phase 4)
   The profitability dashboard. Read-only: composes cost from existing data and
   the Phase-4 cost streams; writes nothing.

   Full project cost  = Finance.projectCost(site).total      ── labour + PO
                                                                materials + expenses
                      + stock issued to the site             ── owned stock
                                                                (stockMovements "out")
                      + skip hire booked to the site         ── non-cancelled skips
   Revenue            = Finance.invoiced(site)               ── non-draft invoices
   Profit = revenue − cost ;  Margin = profit / revenue.

   PO materials (bought-for-job) and stock issues (drawn from owned stock) are
   distinct workflows, so summing them does not double-count. Manager+ only.
   Supersedes the earlier reports.js prototype — wire in this file, not that one.
   ========================================================================== */
(() => {
  "use strict";
  const r2 = Commercial.Money.r2;
  const docTotal = (d) => Commercial.Money.totals(d.items, d.vatRate).total;
  const OT = (Finance && Finance.OT) || 1.5;
  const inR = (date, from, to) => Period.inRange((date || "").slice(0, 10), from, to);
  const matchSite = (rowSiteId, siteId) => siteId == null || rowSiteId === siteId;

  // Project costing can be scoped to a window. "All time" reproduces the
  // cumulative profitability view; week / pay-period / month / year let the
  // accountant cost a project over their reporting cadence.
  const state = { period: "all" };
  const PERIODS = [["all", "All time"], ["this-week", "This week"], ["this-fortnight", "Pay period (2 weeks)"], ["this-month", "This month"], ["this-year", "This year"]];
  function periodRange() {
    if (state.period === "this-week") return Period.weekRange(0);
    if (state.period === "this-fortnight") return Period.payPeriodRange(0);
    if (state.period === "this-month") return Period.monthRange(0);
    if (state.period === "this-year") return Period.yearRange(0);
    return { from: null, to: null, label: "All time" };
  }

  /* date-range-aware cost streams (null range = all-time) ------------------ */
  const labourCostR = (siteId, f, t) => r2(Store.all("timesheets").filter((x) => matchSite(x.siteId, siteId) && inR(x.date, f, t)).reduce((s, x) => {
    const rate = Number((Store.find("workers", x.workerId) || {}).rate) || 0;
    return s + (Number(x.hours) || 0) * rate + (Number(x.overtime) || 0) * rate * OT;
  }, 0));
  const materialsCostR = (siteId, f, t) => r2(Store.all("purchaseOrders").filter((p) => matchSite(p.siteId, siteId) && (p.status === "Ordered" || p.status === "Received") && inR(p.date, f, t)).reduce((s, p) => s + docTotal(p), 0));
  const supInvCostR = (siteId, f, t) => r2(Store.all("supplierInvoices").filter((s) => matchSite(s.siteId, siteId) && (s.status === "Unpaid" || s.status === "Paid") && inR(s.date, f, t)).reduce((sum, s) => sum + (Number(s.gross) || 0), 0));
  const expensesCostR = (siteId, f, t) => r2(Store.all("expenses").filter((e) => matchSite(e.siteId, siteId) && inR(e.date, f, t)).reduce((s, e) => s + (Number(e.amount) || 0), 0));
  const invoicedR = (siteId, f, t) => r2(Store.all("invoices").filter((i) => matchSite(i.siteId, siteId) && i.status !== "Draft" && inR(i.date, f, t)).reduce((s, i) => s + docTotal(i), 0));

  const stockIssued = (siteId, f, t) => r2(Store.all("stockMovements")
    .filter((m) => m.type === "out" && matchSite(m.siteId, siteId) && inR(m.date, f, t))
    .reduce((s, m) => s + (Number(m.value) || 0), 0));
  const skipCost = (siteId, f, t) => r2(Store.all("skipHire")
    .filter((k) => k.status !== "Cancelled" && matchSite(k.siteId, siteId) && inR(k.hireDate, f, t))
    .reduce((s, k) => s + (Number(k.cost) || 0), 0));

  function row(name, status, labour, poMat, supInv, exp, stock, skip, revenue) {
    // POs (poMat) are commitments, not costed. Actual supplier cost = supplier
    // invoices (supInv). poMat is retained on the row for reference/balancing only.
    const cost = r2(labour + supInv + exp + stock + skip);
    const profit = r2(revenue - cost);
    return { name, status, labour, poMat, supInv, exp, stock, skip, cost, revenue, profit,
      margin: revenue ? r2((profit / revenue) * 100) : 0 };
  }
  function siteRow(s, f, t) {
    return row(s.name, s.status || "",
      labourCostR(s.id, f, t), materialsCostR(s.id, f, t), supInvCostR(s.id, f, t), expensesCostR(s.id, f, t),
      stockIssued(s.id, f, t), skipCost(s.id, f, t), invoicedR(s.id, f, t));
  }

  function compute() {
    const { from: f, to: t, label } = periodRange();
    const sites = Store.all("sites");
    const rows = sites.map((s) => siteRow(s, f, t)).sort((a, b) => b.profit - a.profit);

    const totals = row("Total", "",
      labourCostR(null, f, t), materialsCostR(null, f, t), supInvCostR(null, f, t), expensesCostR(null, f, t),
      stockIssued(null, f, t), skipCost(null, f, t), invoicedR(null, f, t));

    // remainder booked to deleted/blank sites, so the table foots to the totals
    const sum = (k) => rows.reduce((a, x) => a + x[k], 0);
    const o = row("Unassigned / no project", "",
      r2(totals.labour - sum("labour")), r2(totals.poMat - sum("poMat")), r2(totals.supInv - sum("supInv")), r2(totals.exp - sum("exp")),
      r2(totals.stock - sum("stock")), r2(totals.skip - sum("skip")), r2(totals.revenue - sum("revenue")));
    if (o.revenue || o.cost) rows.push(o);

    return { rows, totals, siteCount: sites.length, periodLabel: label };
  }

  /* ---- exports (CSV/PDF via shared Util — Phase 6) ---------------------- */
  function exportCsv(data) {
    const T = data.totals;
    const rows = [
      ["Project", "Status", "Revenue", "Labour", "Supplier invoices", "Stock issued", "Skip hire", "Expenses", "Total cost", "Profit", "Margin %"],
      ...data.rows.map((r) => [r.name, r.status, r.revenue, r.labour, r.supInv, r.stock, r.skip, r.exp, r.cost, r.profit, r.margin]),
      ["TOTAL", "", T.revenue, T.labour, T.supInv, T.stock, T.skip, T.exp, T.cost, T.profit, T.margin],
    ];
    Util.downloadCSV("project-profitability.csv", rows);
  }
  function exportPdf(data) {
    const T = data.totals;
    const body = data.rows.map((r) => `<tr><td>${esc(r.name)}</td><td>${esc(r.status || "")}</td><td class="r">${Fmt.gbp(r.revenue)}</td><td class="r">${Fmt.gbp(r.cost)}</td><td class="r">${Fmt.gbp(r.profit)}</td><td class="r">${r.revenue ? r.margin.toFixed(1) + "%" : "—"}</td></tr>`).join("");
    const html = `<h1>Project profitability</h1><div class="muted">${esc(Commercial.Company.get().name || "Company")} · ${esc(data.periodLabel)} · ${Fmt.date(Fmt.todayISO())}</div>
      <table><thead><tr><th>Project</th><th>Status</th><th class="r">Revenue</th><th class="r">Cost</th><th class="r">Profit</th><th class="r">Margin</th></tr></thead>
      <tbody>${body}</tbody>
      <tfoot><tr><td colspan="2">Total</td><td class="r">${Fmt.gbp(T.revenue)}</td><td class="r">${Fmt.gbp(T.cost)}</td><td class="r">${Fmt.gbp(T.profit)}</td><td class="r">${T.revenue ? T.margin.toFixed(1) + "%" : "—"}</td></tr></tfoot></table>`;
    Util.printDocument("Project profitability", html);
  }

  /* ---- render ----------------------------------------------------------- */
  const colour = (n) => (n > 0 ? "color:var(--ok,#16a34a)" : n < 0 ? "color:var(--danger,#dc2626)" : "");
  const badgeKind = { "Active": "ok", "On hold": "warn", "Completed": "muted" };
  const statCard = (label, value, note) =>
    `<div class="stat"><div class="stat__label">${esc(label)}</div><div class="stat__value num">${esc(value)}</div><div class="stat__note">${esc(note)}</div></div>`;

  function render(root) {
    const data = compute();
    const T = data.totals;
    if (!data.siteCount && !T.revenue && !T.cost) {
      root.innerHTML = `<div class="panel"><div class="panel__body"><div class="empty">
        <svg class="empty__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/></svg>
        <div class="empty__title">Nothing to cost yet</div>
        <div class="empty__text">Add projects, then log timesheets, materials/stock, skips, POs, expenses and invoices — profitability builds from the Finance layer plus the Phase-4 cost streams.</div>
        <div class="empty__actions"><button class="btn btn--sm" data-route="sites">Go to Sites</button></div>
      </div></div></div>`;
      const b = root.querySelector("[data-route]"); if (b) b.addEventListener("click", () => Router.navigate("sites"));
      return;
    }

    const costParts = [["Labour", T.labour], ["Supplier invoices", T.supInv], ["Stock issued", T.stock], ["Skip hire", T.skip], ["Expenses", T.exp]];

    const periodOpts = PERIODS.map(([v, l]) => `<option value="${v}"${state.period === v ? " selected" : ""}>${l}</option>`).join("");
    root.innerHTML = `
      <div class="toolbar">
        <div class="toolbar__left filterbar">
          <select class="input" id="pf-period">${periodOpts}</select>
          <span class="muted-count num">${data.siteCount} project${data.siteCount === 1 ? "" : "s"} · ${esc(data.periodLabel)}</span>
        </div>
        <div class="filterbar"><button class="btn btn--sm" id="pf-exp">CSV</button><button class="btn btn--sm" id="pf-pdf">PDF</button></div>
      </div>

      <div class="stat-grid">
        ${statCard("Revenue", Fmt.gbp(T.revenue), "invoiced (incl VAT)")}
        ${statCard("Project cost", Fmt.gbp(T.cost), "labour + supplier inv. + expenses")}
        ${statCard("Net profit", Fmt.gbp(T.profit), "revenue − cost")}
        ${statCard("Margin", T.revenue ? T.margin.toFixed(1) + "%" : "—", "across all projects")}
      </div>

      <div class="panel">
        <div class="panel__head"><span class="panel__title">Profit by project</span></div>
        <div class="panel__body">
          <div class="table-wrap"><table class="table">
            <thead><tr><th>Project</th><th>Status</th><th class="ta-r">Revenue</th><th class="ta-r">Cost</th><th class="ta-r">Profit</th><th class="ta-r">Margin</th></tr></thead>
            <tbody>${data.rows.map((r) => `
              <tr>
                <td><strong>${esc(r.name)}</strong></td>
                <td>${r.status ? `<span class="badge badge--${badgeKind[r.status] || "muted"}">${esc(r.status)}</span>` : "—"}</td>
                <td class="ta-r num">${Fmt.gbp(r.revenue)}</td>
                <td class="ta-r num">${Fmt.gbp(r.cost)}</td>
                <td class="ta-r num" style="${colour(r.profit)}"><strong>${Fmt.gbp(r.profit)}</strong></td>
                <td class="ta-r num" style="${colour(r.profit)}">${r.revenue ? r.margin.toFixed(1) + "%" : "—"}</td>
              </tr>`).join("")}</tbody>
            <tfoot><tr class="totals">
              <td colspan="2">Total</td>
              <td class="ta-r num">${Fmt.gbp(T.revenue)}</td>
              <td class="ta-r num">${Fmt.gbp(T.cost)}</td>
              <td class="ta-r num" style="${colour(T.profit)}"><strong>${Fmt.gbp(T.profit)}</strong></td>
              <td class="ta-r num" style="${colour(T.profit)}">${T.revenue ? T.margin.toFixed(1) + "%" : "—"}</td>
            </tr></tfoot>
          </table></div>
        </div>
      </div>

      <div class="panel">
        <div class="panel__head"><span class="panel__title">Cost breakdown</span><span class="muted-count num">${Fmt.gbp(T.cost)}</span></div>
        <div class="panel__body">
          <div class="table-wrap"><table class="table table--tight">
            <thead><tr><th>Component</th><th class="ta-r">Cost</th><th class="ta-r">Share</th></tr></thead>
            <tbody>${costParts.map(([k, v]) => `
              <tr><td>${k}</td><td class="ta-r num">${Fmt.gbp(v)}</td><td class="ta-r num">${T.cost ? r2(v / T.cost * 100).toFixed(1) + "%" : "—"}</td></tr>`).join("")}</tbody>
            <tfoot><tr class="totals"><td>Total cost</td><td class="ta-r num">${Fmt.gbp(T.cost)}</td><td class="ta-r num">100%</td></tr></tfoot>
          </table></div>
          <p class="hint hint--block">Supplier invoices = actual supplier bills from the Supplier Invoice Register (Unpaid/Paid, gross) — the supplier cost of the job. Purchase orders are commitments only and are <strong>not</strong> counted here (track open POs separately). Stock issued = owned materials drawn from inventory onto a project.</p>
        </div>
      </div>`;

    root.querySelector("#pf-exp").addEventListener("click", () => exportCsv(data));
    root.querySelector("#pf-pdf").addEventListener("click", () => exportPdf(data));
    const pp = root.querySelector("#pf-period");
    if (pp) pp.addEventListener("change", (e) => { state.period = e.target.value; render(root); });
  }

  Dashboard.addStat(() => {
    const T = compute().totals;
    return { label: "Net profit", value: Fmt.gbp(T.profit), note: T.revenue ? `${T.margin.toFixed(1)}% margin` : "all projects", route: "profit" };
  }, "Manager");

  Modules.register({
    id: "profit", label: "Profitability", title: "Project Profitability", minRole: "Manager",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3v18h18"/><path d="M7 14l3-3 3 2 5-6"/><path d="M18 7h-3M18 7v3"/></svg>',
    render,
  });
})();
