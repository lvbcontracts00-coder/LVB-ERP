/* ==========================================================================
   modules/analytics.js — Visual analytics with Chart.js (Phase 6)
   Theme-aware charts (revenue vs cost by project, cost breakdown, 6-month cash
   flow) with CSV + PDF export. Requires the Chart.js <script> tag in index.html;
   degrades gracefully to data tables if it is not present. Lives under the
   "Insights" nav group created by reports.js. Manager+.
   ========================================================================== */
(() => {
  "use strict";
  const r2 = Util.r2;
  const stockIssued = (id) => r2(Store.all("stockMovements").filter((m) => m.type === "out" && (id == null || m.siteId === id)).reduce((s, m) => s + (Number(m.value) || 0), 0));
  const skipCost = (id) => r2(Store.all("skipHire").filter((k) => k.status !== "Cancelled" && (id == null || k.siteId === id)).reduce((s, k) => s + (Number(k.cost) || 0), 0));
  const costOf = (id) => r2(Finance.projectCost(id).total + stockIssued(id) + skipCost(id));

  function projectData() {
    return Store.all("sites").map((s) => ({ name: s.name, revenue: Finance.invoiced(s.id), cost: costOf(s.id) }))
      .filter((d) => d.revenue || d.cost).sort((a, b) => (b.revenue - b.cost) - (a.revenue - a.cost));
  }
  function breakdown() {
    const c = Finance.projectCost(null);
    return [["Labour", c.labour], ["Supplier invoices", c.supplierInvoices], ["Stock issued", stockIssued(null)], ["Skip hire", skipCost(null)], ["Expenses", c.expenses]].filter(([, v]) => v > 0);
  }
  function months(n) {
    const out = []; const d = new Date(); d.setDate(1);
    for (let i = n - 1; i >= 0; i--) { const m = new Date(d.getFullYear(), d.getMonth() - i, 1); out.push({ key: `${m.getFullYear()}-${String(m.getMonth() + 1).padStart(2, "0")}`, label: m.toLocaleDateString("en-GB", { month: "short" }) }); }
    return out;
  }
  function cashSeries() {
    const ms = months(6);
    const inByM = {}, outByM = {};
    Store.all("payments").forEach((p) => { const k = (p.date || "").slice(0, 7); inByM[k] = (inByM[k] || 0) + (Number(p.amount) || 0); });
    Store.all("expenses").filter((e) => e.reimbursed).forEach((e) => { const k = ((e.reimbursementDate || e.date) || "").slice(0, 7); outByM[k] = (outByM[k] || 0) + (Number(e.amount) || 0); });
    return { labels: ms.map((m) => m.label), inv: ms.map((m) => r2(inByM[m.key] || 0)), out: ms.map((m) => r2(outByM[m.key] || 0)) };
  }

  let charts = [];
  let disposer = null;
  function destroyCharts() { charts.forEach((c) => { try { c.destroy(); } catch (e) {} }); charts = []; }

  function drawCharts(root) {
    const C = Util.themeColors();
    const grid = C.border, tick = C.muted;
    const base = { responsive: true, maintainAspectRatio: false, plugins: { legend: { labels: { color: C.text, boxWidth: 12 } } } };
    const proj = projectData();

    const c1 = root.querySelector("#an-proj");
    if (c1) charts.push(new Chart(c1, {
      type: "bar",
      data: { labels: proj.map((d) => d.name), datasets: [
        { label: "Revenue", data: proj.map((d) => d.revenue), backgroundColor: C.ok },
        { label: "Cost", data: proj.map((d) => d.cost), backgroundColor: C.accent }] },
      options: { ...base, scales: { x: { ticks: { color: tick }, grid: { color: grid } }, y: { ticks: { color: tick }, grid: { color: grid } } } },
    }));

    const bd = breakdown();
    const c2 = root.querySelector("#an-cost");
    if (c2) charts.push(new Chart(c2, {
      type: "doughnut",
      data: { labels: bd.map((b) => b[0]), datasets: [{ data: bd.map((b) => b[1]), backgroundColor: [C.accent, C.ok, C.warn, C.danger, C.muted], borderColor: C.surface, borderWidth: 2 }] },
      options: { ...base },
    }));

    const cf = cashSeries();
    const c3 = root.querySelector("#an-cash");
    if (c3) charts.push(new Chart(c3, {
      type: "bar",
      data: { labels: cf.labels, datasets: [
        { label: "Cash in", data: cf.inv, backgroundColor: C.ok },
        { label: "Cash out", data: cf.out, backgroundColor: C.danger }] },
      options: { ...base, scales: { x: { ticks: { color: tick }, grid: { color: grid } }, y: { ticks: { color: tick }, grid: { color: grid } } } },
    }));
  }

  function exportPDF() {
    const proj = projectData();
    const imgs = ["#an-proj", "#an-cost", "#an-cash"].map((id) => { const c = document.querySelector(id); try { return c ? `<img src="${c.toDataURL("image/png")}">` : ""; } catch (e) { return ""; } });
    const rows = proj.map((d) => `<tr><td>${esc(d.name)}</td><td class="r">${Fmt.gbp(d.revenue)}</td><td class="r">${Fmt.gbp(d.cost)}</td><td class="r">${Fmt.gbp(r2(d.revenue - d.cost))}</td></tr>`).join("");
    const html = `
      <h1>Analytics — ${esc(Commercial.Company.get().name || "Company")}</h1>
      <div class="muted">Generated ${Fmt.date(Fmt.todayISO())}</div>
      <h2>Revenue vs cost by project</h2>${imgs[0]}
      <div class="grid"><div><h2>Cost breakdown</h2>${imgs[1]}</div><div><h2>Cash flow (6 months)</h2>${imgs[2]}</div></div>
      <h2>Project summary</h2>
      <table><thead><tr><th>Project</th><th class="r">Revenue</th><th class="r">Cost</th><th class="r">Profit</th></tr></thead><tbody>${rows}</tbody></table>`;
    Util.printDocument("Analytics", html);
  }
  function exportCSV() {
    const proj = projectData();
    Util.downloadCSV("analytics-projects.csv", [["Project", "Revenue", "Cost", "Profit"], ...proj.map((d) => [d.name, d.revenue, d.cost, r2(d.revenue - d.cost)])]);
  }

  function render(root) {
    if (disposer) { disposer(); disposer = null; }
    destroyCharts();
    const proj = projectData();
    const hasData = proj.length || breakdown().length;
    const hasChart = typeof window.Chart !== "undefined";

    if (!hasData) {
      root.innerHTML = `<div class="panel"><div class="panel__body"><div class="empty">
        <svg class="empty__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 3v18h18"/><path d="M7 14l3-3 3 2 5-6"/></svg>
        <div class="empty__title">No data to chart yet</div>
        <div class="empty__text">Add projects with invoices and costs, then come back for the visuals.</div></div></div></div>`;
      return;
    }

    root.innerHTML = `
      <div class="toolbar">
        <div class="toolbar__left"><span class="muted-count">Visual analytics${hasChart ? "" : " · charts library not loaded"}</span></div>
        <div class="filterbar"><button class="btn btn--sm" id="an-csv">CSV</button><button class="btn btn--sm" id="an-pdf">PDF</button></div>
      </div>
      ${!hasChart ? `<p class="hint hint--block">Add <code>&lt;script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"&gt;&lt;/script&gt;</code> before the module scripts in <code>index.html</code> to enable charts. Showing data tables below.</p>` : ""}
      ${hasChart ? `
        <div class="panel"><div class="panel__head"><span class="panel__title">Revenue vs cost by project</span></div>
          <div class="panel__body"><div style="position:relative;height:320px"><canvas id="an-proj"></canvas></div></div></div>
        <div class="panel-grid">
          <section class="panel"><div class="panel__head"><span class="panel__title">Cost breakdown</span></div>
            <div class="panel__body"><div style="position:relative;height:280px"><canvas id="an-cost"></canvas></div></div></section>
          <section class="panel"><div class="panel__head"><span class="panel__title">Cash flow · 6 months</span></div>
            <div class="panel__body"><div style="position:relative;height:280px"><canvas id="an-cash"></canvas></div></div></section>
        </div>`
      : `<div class="panel"><div class="panel__body"><div class="table-wrap"><table class="table">
          <thead><tr><th>Project</th><th class="ta-r">Revenue</th><th class="ta-r">Cost</th><th class="ta-r">Profit</th></tr></thead>
          <tbody>${proj.map((d) => `<tr><td><strong>${esc(d.name)}</strong></td><td class="ta-r num">${Fmt.gbp(d.revenue)}</td><td class="ta-r num">${Fmt.gbp(d.cost)}</td><td class="ta-r num">${Fmt.gbp(r2(d.revenue - d.cost))}</td></tr>`).join("")}</tbody>
        </table></div></div></div>`}
    `;
    root.querySelector("#an-csv").addEventListener("click", exportCSV);
    root.querySelector("#an-pdf").addEventListener("click", exportPDF);

    if (hasChart) {
      drawCharts(root);
      // redraw on theme switch while this view is on screen
      disposer = Util.onThemeChange(() => { if (document.body.contains(root) && root.querySelector("#an-proj")) { destroyCharts(); drawCharts(root); } });
    }
  }

  Modules.register({
    id: "analytics", label: "Analytics", title: "Analytics", minRole: "Manager",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/></svg>',
    render,
  });
})();
