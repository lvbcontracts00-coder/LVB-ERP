/* ==========================================================================
   modules/vehicles.js — Vehicle / fleet management (Phase 5)
   Store collection "vehicles".
   Record: { id, reg, make, model, type, assignedTo, status,
             motDate, taxDate, insuranceDate, serviceDate, notes }
   Surfaces MOT / tax / insurance / service that are due soon or overdue.
   ========================================================================== */
(() => {
  "use strict";
  const COL = "vehicles";
  const canEdit = () => Auth.can("Manager");
  const TYPES = ["Van", "Tipper", "Pickup", "Flatbed", "Car", "HGV", "Plant / Machine", "Trailer", "Other"];
  const STATUSES = ["Active", "SORN", "Off road", "Sold"];
  const badgeKind = { "Active": "ok", "SORN": "warn", "Off road": "warn", "Sold": "muted" };

  const opts = (list, sel) => list.map((o) => `<option value="${esc(o)}"${o === sel ? " selected" : ""}>${esc(o)}</option>`).join("");
  const workerName = (id) => id ? ((Store.find("workers", id) || {}).name || "Unknown") : "Unassigned";
  function workerOptions(sel) {
    return `<option value="">— unassigned —</option>` +
      Store.all("workers").map((w) => `<option value="${w.id}"${w.id === sel ? " selected" : ""}>${esc(w.name)}</option>`).join("");
  }
  const daysUntil = (iso) => { if (!iso) return null; const d = new Date(iso); if (isNaN(d)) return null; return Math.floor((d - new Date(Fmt.todayISO())) / 86400000); };
  // soonest expiry across the three compliance dates
  function nextExpiry(v) {
    const items = [["MOT", v.motDate], ["Tax", v.taxDate], ["Insurance", v.insuranceDate]]
      .map(([k, d]) => ({ k, d, n: daysUntil(d) })).filter((x) => x.n !== null);
    if (!items.length) return null;
    return items.sort((a, b) => a.n - b.n)[0];
  }
  const expiryBadge = (e) => {
    if (!e) return `<span class="muted-count">—</span>`;
    const kind = e.n < 0 ? "warn" : e.n <= 30 ? "warn" : "ok";
    const txt = e.n < 0 ? `${e.k} overdue` : `${e.k} ${e.n}d`;
    return `<span class="badge badge--${kind}">${esc(txt)}</span>`;
  };

  function form(v) {
    v = v || {}; // null-safe: JS default params apply to undefined only, not null
    return `
      <div class="form-grid">
        <div class="field"><label class="field__label">Registration *</label>
          <input class="input" id="v-reg" value="${esc(v.reg || "")}" placeholder="e.g. AB12 CDE" style="text-transform:uppercase"></div>
        <div class="field"><label class="field__label">Type</label>
          <select class="input" id="v-type">${opts(TYPES, v.type || "Van")}</select></div>
        <div class="field"><label class="field__label">Make</label>
          <input class="input" id="v-make" value="${esc(v.make || "")}" placeholder="Ford"></div>
        <div class="field"><label class="field__label">Model</label>
          <input class="input" id="v-model" value="${esc(v.model || "")}" placeholder="Transit"></div>
        <div class="field"><label class="field__label">Assigned to</label>
          <select class="input" id="v-driver">${workerOptions(v.assignedTo)}</select></div>
        <div class="field"><label class="field__label">Status</label>
          <select class="input" id="v-status">${opts(STATUSES, v.status || "Active")}</select></div>
        <div class="field"><label class="field__label">MOT due</label>
          <input class="input" id="v-mot" type="date" value="${esc(v.motDate || "")}"></div>
        <div class="field"><label class="field__label">Road tax due</label>
          <input class="input" id="v-tax" type="date" value="${esc(v.taxDate || "")}"></div>
        <div class="field"><label class="field__label">Insurance due</label>
          <input class="input" id="v-ins" type="date" value="${esc(v.insuranceDate || "")}"></div>
        <div class="field"><label class="field__label">Next service</label>
          <input class="input" id="v-svc" type="date" value="${esc(v.serviceDate || "")}"></div>
        <div class="field span-2"><label class="field__label">Notes</label>
          <textarea class="input" id="v-notes" rows="2">${esc(v.notes || "")}</textarea></div>
      </div>`;
  }
  const read = (r) => ({
    reg: r.querySelector("#v-reg").value.trim().toUpperCase(),
    type: r.querySelector("#v-type").value, make: r.querySelector("#v-make").value.trim(),
    model: r.querySelector("#v-model").value.trim(), assignedTo: r.querySelector("#v-driver").value,
    status: r.querySelector("#v-status").value,
    motDate: r.querySelector("#v-mot").value, taxDate: r.querySelector("#v-tax").value,
    insuranceDate: r.querySelector("#v-ins").value, serviceDate: r.querySelector("#v-svc").value,
    notes: r.querySelector("#v-notes").value.trim(),
  });
  function openForm(existing) {
    UI.modal({
      title: existing ? "Edit vehicle" : "Add vehicle", size: "lg",
      bodyHTML: form(existing), saveLabel: existing ? "Save changes" : "Add vehicle",
      onSave: (r) => {
        const d = read(r);
        if (!d.reg) { UI.toast("Registration is required", "danger"); return false; }
        if (existing) { Store.update(COL, existing.id, d); UI.toast("Vehicle updated", "ok"); }
        else { Store.insert(COL, d); UI.toast("Vehicle added", "ok"); }
        render(document.getElementById("view-root"));
      },
    });
  }
  function remove(v) {
    UI.confirm(`Delete ${v.reg}?`, () => { Store.destroy(COL, v.id); UI.toast("Vehicle deleted", "info"); render(document.getElementById("view-root")); });
  }

  let term = "";
  function render(root) {
    const all = Store.all(COL);
    const rows = all.filter((v) => !term || (v.reg + " " + v.make + " " + v.model + " " + workerName(v.assignedTo)).toLowerCase().includes(term.toLowerCase()));
    const dueCount = all.filter((v) => { const e = nextExpiry(v); return e && e.n <= 30; }).length;

    root.innerHTML = `
      <div class="toolbar">
        <div class="toolbar__left">
          <input class="input input--search" id="v-search" placeholder="Search fleet…" value="${esc(term)}">
          <span class="muted-count num">${all.length} vehicle${all.length === 1 ? "" : "s"}</span>
          ${dueCount ? `<span class="badge badge--warn">${dueCount} due ≤30d</span>` : ""}
        </div>
        ${canEdit() ? `<button class="btn btn--primary" id="v-add">＋ Add vehicle</button>` : ""}
      </div>
      ${rows.length ? `
        <div class="table-wrap"><table class="table">
          <thead><tr><th>Reg</th><th>Vehicle</th><th>Type</th><th>Assigned</th><th>Status</th><th>Next due</th>${canEdit() ? `<th class="ta-r">Actions</th>` : ""}</tr></thead>
          <tbody>${rows.map((v) => `
            <tr>
              <td><strong>${esc(v.reg)}</strong></td>
              <td>${esc([v.make, v.model].filter(Boolean).join(" ") || "—")}</td>
              <td>${esc(v.type || "—")}</td>
              <td>${esc(workerName(v.assignedTo))}</td>
              <td><span class="badge badge--${badgeKind[v.status] || "muted"}">${esc(v.status || "—")}</span></td>
              <td>${expiryBadge(nextExpiry(v))}</td>
              ${canEdit() ? `<td class="ta-r nowrap"><button class="btn btn--sm" data-edit="${v.id}">Edit</button><button class="btn btn--sm btn--danger" data-del="${v.id}">Del</button></td>` : ""}
            </tr>`).join("")}</tbody>
        </table></div>`
      : `<div class="panel"><div class="panel__body"><div class="empty">
          <svg class="empty__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 13l2-5h11l3 4h2v4h-2M5 17a2 2 0 1 0 4 0M15 17a2 2 0 1 0 4 0M3 13h13M3 13v4h2"/></svg>
          <div class="empty__title">${all.length === 0 ? "No vehicles yet" : "No matches"}</div>
          <div class="empty__text">${all.length === 0 ? (canEdit() ? "Add the first vehicle to your fleet." : "Ask a manager to add vehicles.") : "Try a different search."}</div>
        </div></div></div>`}
    `;
    const search = root.querySelector("#v-search");
    search.addEventListener("input", () => { term = search.value; render(root); const s = document.getElementById("v-search"); if (s) { s.focus(); s.setSelectionRange(s.value.length, s.value.length); } });
    const add = root.querySelector("#v-add"); if (add) add.addEventListener("click", () => openForm(null));
    root.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => openForm(Store.find(COL, b.dataset.edit))));
    root.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => remove(Store.find(COL, b.dataset.del))));
  }

  Dashboard.addStat(() => {
    const due = Store.all(COL).filter((v) => { const e = nextExpiry(v); return e && e.n <= 30; });
    return { label: "Vehicle renewals", value: String(due.length), note: due.length ? "MOT/tax/ins ≤30d" : "all current", route: "vehicles" };
  });

  Modules.section("Fleet & Assets");
  Modules.register({
    id: "vehicles", label: "Vehicles", title: "Fleet / Vehicles", minRole: "Viewer",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 13l2-5h11l3 4h2v4h-2M5 17a2 2 0 1 0 4 0M15 17a2 2 0 1 0 4 0M3 13h13"/></svg>',
    render,
  });
})();
