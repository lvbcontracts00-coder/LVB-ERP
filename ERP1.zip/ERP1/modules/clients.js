/* ==========================================================================
   modules/clients.js — Client CRM (Phase 3)
   Store collection "clients". First commercial module — adds the nav section.
   Record: { id, name, company, email, phone, address, status, notes }
   ========================================================================== */
(() => {
  "use strict";
  const COL = "clients";
  const STATUSES = ["Lead", "Active", "Past"];
  const badge = { "Lead": "warn", "Active": "ok", "Past": "muted" };

  const canEdit = () => Auth.can("Manager");
  const opts = (list, sel) => list.map((o) => `<option value="${esc(o)}"${o === sel ? " selected" : ""}>${esc(o)}</option>`).join("");

  function form(c) {
    c = c || {}; // null-safe: JS default params apply to undefined only, not null
    return `
      <div class="form-grid">
        <div class="field"><label class="field__label">Contact name *</label>
          <input class="input" id="c-name" value="${esc(c.name || "")}" placeholder="e.g. Sarah Jones"></div>
        <div class="field"><label class="field__label">Company</label>
          <input class="input" id="c-company" value="${esc(c.company || "")}" placeholder="Optional"></div>
        <div class="field"><label class="field__label">Email</label>
          <input class="input" id="c-email" type="email" value="${esc(c.email || "")}"></div>
        <div class="field"><label class="field__label">Phone</label>
          <input class="input" id="c-phone" value="${esc(c.phone || "")}"></div>
        <div class="field"><label class="field__label">Status</label>
          <select class="input" id="c-status">${opts(STATUSES, c.status || "Lead")}</select></div>
        <div class="field"></div>
        <div class="field span-2"><label class="field__label">Address</label>
          <textarea class="input" id="c-address" rows="2" placeholder="Billing / site address">${esc(c.address || "")}</textarea></div>
        <div class="field span-2"><label class="field__label">Notes</label>
          <textarea class="input" id="c-notes" rows="2">${esc(c.notes || "")}</textarea></div>
      </div>`;
  }

  const read = (r) => ({
    name: r.querySelector("#c-name").value.trim(),
    company: r.querySelector("#c-company").value.trim(),
    email: r.querySelector("#c-email").value.trim(),
    phone: r.querySelector("#c-phone").value.trim(),
    status: r.querySelector("#c-status").value,
    address: r.querySelector("#c-address").value.trim(),
    notes: r.querySelector("#c-notes").value.trim(),
  });

  function openForm(existing) {
    UI.modal({
      title: existing ? "Edit client" : "Add client", size: "lg",
      bodyHTML: form(existing), saveLabel: existing ? "Save changes" : "Add client",
      onSave: (r) => {
        const d = read(r);
        if (!d.name) { UI.toast("Contact name is required", "danger"); return false; }
        if (existing) { Store.update(COL, existing.id, d); UI.toast("Client updated", "ok"); }
        else { Store.insert(COL, d); UI.toast("Client added", "ok"); }
        render(document.getElementById("view-root"));
      },
    });
  }

  function remove(c) {
    UI.confirm(`Delete ${c.name}? Quotes/invoices linked to them will show "—".`, () => {
      Store.destroy(COL, c.id); UI.toast("Client deleted", "info");
      render(document.getElementById("view-root"));
    });
  }

  let term = "";
  function render(root) {
    const all = Store.all(COL);
    const rows = all.filter((c) => !term || (c.name + " " + c.company + " " + c.email).toLowerCase().includes(term.toLowerCase()));

    root.innerHTML = `
      <div class="toolbar">
        <div class="toolbar__left">
          <input class="input input--search" id="c-search" placeholder="Search clients…" value="${esc(term)}">
          <span class="muted-count num">${all.length} total</span>
        </div>
        ${canEdit() ? `<button class="btn btn--primary" id="c-add">＋ Add client</button>` : ""}
      </div>
      ${rows.length ? `
        <div class="table-wrap"><table class="table">
          <thead><tr><th>Name</th><th>Company</th><th>Email</th><th>Phone</th><th>Status</th>${canEdit() ? `<th class="ta-r">Actions</th>` : ""}</tr></thead>
          <tbody>${rows.map((c) => `
            <tr>
              <td><strong>${esc(c.name)}</strong></td>
              <td>${esc(c.company || "—")}</td>
              <td>${esc(c.email || "—")}</td>
              <td class="num">${esc(c.phone || "—")}</td>
              <td><span class="badge badge--${badge[c.status] || "muted"}">${esc(c.status)}</span></td>
              ${canEdit() ? `<td class="ta-r nowrap"><button class="btn btn--sm" data-edit="${c.id}">Edit</button><button class="btn btn--sm btn--danger" data-del="${c.id}">Delete</button></td>` : ""}
            </tr>`).join("")}</tbody>
        </table></div>`
      : `<div class="panel"><div class="panel__body"><div class="empty">
          <svg class="empty__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4a3.5 3.5 0 0 1 0 7"/></svg>
          <div class="empty__title">${all.length === 0 ? "No clients yet" : "No matches"}</div>
          <div class="empty__text">${all.length === 0 ? (canEdit() ? "Add your first client." : "Ask a manager to add clients.") : "Try a different search."}</div>
        </div></div></div>`}
    `;
    const search = root.querySelector("#c-search");
    search.addEventListener("input", () => { term = search.value; render(root); const s = document.getElementById("c-search"); if (s) { s.focus(); s.setSelectionRange(s.value.length, s.value.length); } });
    const add = root.querySelector("#c-add"); if (add) add.addEventListener("click", () => openForm(null));
    root.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => openForm(Store.find(COL, b.dataset.edit))));
    root.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => remove(Store.find(COL, b.dataset.del))));
  }

  Dashboard.addStat(() => {
    const active = Store.all(COL).filter((c) => c.status === "Active").length;
    return { label: "Active clients", value: String(active), note: `${Store.all(COL).length} total`, route: "clients" };
  });

  Modules.section("Commercial"); // group header for all Phase 3 modules
  Modules.register({
    id: "clients", label: "Clients", title: "Clients", minRole: "Viewer",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4a3.5 3.5 0 0 1 0 7M22 20a6 6 0 0 0-4-5.6"/></svg>',
    render,
  });
})();
