/* ==========================================================================
   modules/suppliers.js — Supplier database (Phase 3)
   Store collection "suppliers". Referenced by purchase orders.
   Record: { id, name, category, contact, email, phone, address, notes }
   ========================================================================== */
(() => {
  "use strict";
  const COL = "suppliers";
  const CATEGORIES = ["Builders Merchant", "Timber", "Plumbing & Heating", "Electrical", "Plant Hire", "Aggregates & Concrete", "Roofing", "Tools & Fixings", "Skip / Waste", "Other"];

  // The company's regular trade suppliers — one click to add any that are
  // missing (idempotent: matches on name, case-insensitive, never duplicates).
  const MAIN_SUPPLIERS = [
    { name: "MGN", category: "Builders Merchant" },
    { name: "Selco", category: "Builders Merchant" },
    { name: "Amazon", category: "Other" },
    { name: "Capital BMS Ltd", category: "Other" },
    { name: "Screwfix", category: "Tools & Fixings" },
    { name: "Toolstation", category: "Tools & Fixings" },
    { name: "CEF", category: "Electrical" },
    { name: "Jewson", category: "Builders Merchant" },
  ];
  function missingMain() {
    const have = new Set(Store.all(COL).map((s) => (s.name || "").trim().toLowerCase()));
    return MAIN_SUPPLIERS.filter((m) => !have.has(m.name.toLowerCase()));
  }
  function addMain() {
    const miss = missingMain();
    if (!miss.length) { UI.toast("All main suppliers are already added", "info"); return; }
    miss.forEach((m) => Store.insert(COL, { name: m.name, category: m.category, contact: "", phone: "", email: "", address: "", notes: "" }));
    UI.toast(`Added ${miss.length} supplier${miss.length === 1 ? "" : "s"}`, "ok");
    render(document.getElementById("view-root"));
  }

  const canEdit = () => Auth.can("Manager");
  const opts = (list, sel) => list.map((o) => `<option value="${esc(o)}"${o === sel ? " selected" : ""}>${esc(o)}</option>`).join("");

  function form(s) {
    s = s || {}; // null-safe: JS default params apply to undefined only, not null
    return `
      <div class="form-grid">
        <div class="field"><label class="field__label">Supplier name *</label>
          <input class="input" id="s-name" value="${esc(s.name || "")}" placeholder="e.g. Travis Perkins"></div>
        <div class="field"><label class="field__label">Category</label>
          <select class="input" id="s-cat">${opts(CATEGORIES, s.category || "Builders Merchant")}</select></div>
        <div class="field"><label class="field__label">Contact person</label>
          <input class="input" id="s-contact" value="${esc(s.contact || "")}"></div>
        <div class="field"><label class="field__label">Phone</label>
          <input class="input" id="s-phone" value="${esc(s.phone || "")}"></div>
        <div class="field span-2"><label class="field__label">Email</label>
          <input class="input" id="s-email" type="email" value="${esc(s.email || "")}"></div>
        <div class="field span-2"><label class="field__label">Address</label>
          <textarea class="input" id="s-address" rows="2">${esc(s.address || "")}</textarea></div>
        <div class="field span-2"><label class="field__label">Notes</label>
          <textarea class="input" id="s-notes" rows="2" placeholder="Account number, payment terms…">${esc(s.notes || "")}</textarea></div>
      </div>`;
  }

  const read = (r) => ({
    name: r.querySelector("#s-name").value.trim(),
    category: r.querySelector("#s-cat").value,
    contact: r.querySelector("#s-contact").value.trim(),
    phone: r.querySelector("#s-phone").value.trim(),
    email: r.querySelector("#s-email").value.trim(),
    address: r.querySelector("#s-address").value.trim(),
    notes: r.querySelector("#s-notes").value.trim(),
  });

  function openForm(existing) {
    UI.modal({
      title: existing ? "Edit supplier" : "Add supplier", size: "lg",
      bodyHTML: form(existing), saveLabel: existing ? "Save changes" : "Add supplier",
      onSave: (r) => {
        const d = read(r);
        if (!d.name) { UI.toast("Supplier name is required", "danger"); return false; }
        if (existing) { Store.update(COL, existing.id, d); UI.toast("Supplier updated", "ok"); }
        else { Store.insert(COL, d); UI.toast("Supplier added", "ok"); }
        render(document.getElementById("view-root"));
      },
    });
  }

  function remove(s) {
    UI.confirm(`Delete ${s.name}?`, () => {
      Store.destroy(COL, s.id); UI.toast("Supplier deleted", "info");
      render(document.getElementById("view-root"));
    });
  }

  let term = "";
  function render(root) {
    const all = Store.all(COL);
    const rows = all.filter((s) => !term || (s.name + " " + s.category + " " + s.contact).toLowerCase().includes(term.toLowerCase()));

    root.innerHTML = `
      <div class="toolbar">
        <div class="toolbar__left">
          <input class="input input--search" id="s-search" placeholder="Search suppliers…" value="${esc(term)}">
          <span class="muted-count num">${all.length} total</span>
        </div>
        ${canEdit() ? `<div class="filterbar">${missingMain().length ? `<button class="btn btn--sm" id="s-main">＋ Add main suppliers</button>` : ""}<button class="btn btn--primary" id="s-add">＋ Add supplier</button></div>` : ""}
      </div>
      ${rows.length ? `
        <div class="table-wrap"><table class="table">
          <thead><tr><th>Supplier</th><th>Category</th><th>Contact</th><th>Phone</th><th>Email</th>${canEdit() ? `<th class="ta-r">Actions</th>` : ""}</tr></thead>
          <tbody>${rows.map((s) => `
            <tr>
              <td><strong>${esc(s.name)}</strong></td>
              <td><span class="badge badge--muted">${esc(s.category || "—")}</span></td>
              <td>${esc(s.contact || "—")}</td>
              <td class="num">${esc(s.phone || "—")}</td>
              <td>${esc(s.email || "—")}</td>
              ${canEdit() ? `<td class="ta-r nowrap"><button class="btn btn--sm" data-edit="${s.id}">Edit</button><button class="btn btn--sm btn--danger" data-del="${s.id}">Delete</button></td>` : ""}
            </tr>`).join("")}</tbody>
        </table></div>`
      : `<div class="panel"><div class="panel__body"><div class="empty">
          <svg class="empty__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 9l1-4h16l1 4M4 9h16v11H4zM9 13h6"/></svg>
          <div class="empty__title">${all.length === 0 ? "No suppliers yet" : "No matches"}</div>
          <div class="empty__text">${all.length === 0 ? (canEdit() ? "Add your first supplier." : "Ask a manager to add suppliers.") : "Try a different search."}</div>
        </div></div></div>`}
    `;
    const search = root.querySelector("#s-search");
    search.addEventListener("input", () => { term = search.value; render(root); const s = document.getElementById("s-search"); if (s) { s.focus(); s.setSelectionRange(s.value.length, s.value.length); } });
    const add = root.querySelector("#s-add"); if (add) add.addEventListener("click", () => openForm(null));
    const main = root.querySelector("#s-main"); if (main) main.addEventListener("click", addMain);
    root.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => openForm(Store.find(COL, b.dataset.edit))));
    root.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => remove(Store.find(COL, b.dataset.del))));
  }

  Modules.register({
    id: "suppliers", label: "Suppliers", title: "Suppliers", minRole: "Viewer",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l1.5-4h15L21 9M4 9h16v11H4z"/><path d="M9 13h6"/></svg>',
    render,
  });
})();
