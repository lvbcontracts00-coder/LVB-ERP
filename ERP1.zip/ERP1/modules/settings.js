/* ==========================================================================
   modules/settings.js — Company settings & administration (Phase 5)
   Surfaces the company profile (used on every document), a data backup
   export/import, and a read-only user list. No own collection — it reads/writes
   existing singletons via Store and Commercial.Company.
   Route is Manager+; backup and user administration are Admin-only sections.
   ========================================================================== */
(() => {
  "use strict";
  const isAdmin = () => Auth.can("Admin");
  const nl2br = (s) => esc(s || "").replace(/\n/g, "<br>");

  function exportBackup() {
    const json = Store.exportAll();
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob), a = document.createElement("a");
    a.href = url; a.download = `erp-backup-${Fmt.todayISO()}.json`;
    document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 0);
    UI.toast("Backup downloaded", "ok");
  }
  function importBackup() {
    UI.modal({
      title: "Import backup", size: "lg", saveLabel: "Restore data",
      bodyHTML: `
        <p class="hint" style="margin-bottom:12px">Paste a previously exported backup, or choose a .json file. This merges into existing data (same keys are overwritten). Consider exporting a backup first.</p>
        <div class="field"><label class="field__label">Backup file</label><input type="file" id="b-file" accept="application/json,.json"></div>
        <div class="field span-2" style="margin-top:10px"><label class="field__label">…or paste JSON</label><textarea class="input" id="b-text" rows="6" placeholder='{"workers":[…],"sites":[…]}'></textarea></div>`,
      onSave: (r) => {
        const text = r.querySelector("#b-text").value.trim();
        const apply = (json) => {
          try { Store.importAll(json); UI.toast("Data restored — reloading", "ok"); setTimeout(() => { try { location.reload(); } catch (e) { App.showApp(); } }, 600); }
          catch (e) { UI.toast("Could not parse that backup", "danger"); }
        };
        if (text) { apply(text); return; }
        const f = r.querySelector("#b-file").files[0];
        if (!f) { UI.toast("Choose a file or paste JSON", "danger"); return false; }
        const fr = new FileReader(); fr.onload = () => apply(fr.result); fr.readAsText(f);
      },
    });
  }
  function resetAll() {
    UI.confirm("Erase ALL data and restore demo accounts? This cannot be undone.", () => {
      const users = Store.read("users"); // keep login accounts
      Object.keys(localStorage).filter((k) => k.startsWith("erp:")).forEach((k) => localStorage.removeItem(k));
      if (users) Store.write("users", users);
      UI.toast("All data cleared", "info");
      setTimeout(() => { try { location.reload(); } catch (e) {} }, 500);
    });
  }

  function render(root) {
    const c = Commercial.Company.get();
    const users = Store.read("users", []);

    root.innerHTML = `
      <div class="panel">
        <div class="panel__head"><span class="panel__title">Company profile</span>
          ${Auth.can("Manager") ? `<button class="btn btn--sm" id="st-company" style="margin-left:auto">Edit</button>` : ""}</div>
        <div class="panel__body">
          <div class="form-grid">
            <div class="field"><label class="field__label">Company</label><div>${esc(c.name)}</div></div>
            <div class="field"><label class="field__label">VAT no.</label><div class="num">${esc(c.vatNo || "—")}</div></div>
            <div class="field"><label class="field__label">Phone</label><div>${esc(c.phone || "—")}</div></div>
            <div class="field"><label class="field__label">Email</label><div>${esc(c.email || "—")}</div></div>
            <div class="field"><label class="field__label">Company reg.</label><div class="num">${esc(c.regNo || "—")}</div></div>
            <div class="field"><label class="field__label">Address</label><div>${nl2br(c.address)}</div></div>
            <div class="field span-2"><label class="field__label">Bank / payment details</label><div>${nl2br(c.bank)}</div></div>
          </div>
          <p class="hint hint--block">These details appear on every quote, invoice and purchase order.</p>
        </div>
      </div>

      <div class="panel">
        <div class="panel__head"><span class="panel__title">Users</span><span class="muted-count num">${users.length}</span></div>
        <div class="panel__body">
          <div class="table-wrap"><table class="table table--tight">
            <thead><tr><th>Name</th><th>Username</th><th>Role</th></tr></thead>
            <tbody>${users.map((u) => `<tr><td><strong>${esc(u.name)}</strong></td><td class="num">${esc(u.username)}</td><td><span class="badge badge--${u.role === "Admin" ? "ok" : u.role === "Manager" ? "warn" : "muted"}">${esc(u.role)}</span></td></tr>`).join("")}</tbody>
          </table></div>
          <p class="hint hint--block">Prototype auth: accounts are seeded client-side. A real deployment needs a backend with hashed passwords and proper user management.</p>
        </div>
      </div>

      ${isAdmin() ? `
      <div class="panel">
        <div class="panel__head"><span class="panel__title">Data backup</span><span class="badge badge--warn">Admin</span></div>
        <div class="panel__body">
          <p class="hint" style="margin-bottom:12px">All data lives in this browser only. Export regularly — clearing the browser erases everything.</p>
          <div class="toolbar"><div class="toolbar__left filterbar">
            <button class="btn btn--primary" id="st-export">⬇ Export backup</button>
            <button class="btn" id="st-import">⬆ Import backup</button>
            <button class="btn btn--danger" id="st-reset">Erase all data</button>
          </div></div>
        </div>
      </div>` : ""}
    `;
    const ce = root.querySelector("#st-company"); if (ce) ce.addEventListener("click", () => Commercial.Company.editModal(() => render(root)));
    const ex = root.querySelector("#st-export"); if (ex) ex.addEventListener("click", exportBackup);
    const im = root.querySelector("#st-import"); if (im) im.addEventListener("click", importBackup);
    const rs = root.querySelector("#st-reset"); if (rs) rs.addEventListener("click", resetAll);
  }

  Modules.section("System");
  Modules.register({
    id: "settings", label: "Settings", title: "Settings", minRole: "Manager",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1l2-1.6-2-3.4-2.4 1a7 7 0 0 0-1.7-1L14.5 2h-4l-.3 2.6a7 7 0 0 0-1.7 1l-2.4-1-2 3.4 2 1.6a7 7 0 0 0 0 2l-2 1.6 2 3.4 2.4-1a7 7 0 0 0 1.7 1l.3 2.6h4l.3-2.6a7 7 0 0 0 1.7-1l2.4 1 2-3.4-2-1.6a7 7 0 0 0 .1-1z"/></svg>',
    render,
  });

  // Dedicated "Backup & Restore" route — reuses the Settings screen (which hosts
  // the export/import panel). Lets the consolidated nav expose Backup as its own
  // entry without duplicating the "settings" route.
  Router.register("backup", { title: "Backup & Restore", minRole: "Manager", render });
})();
