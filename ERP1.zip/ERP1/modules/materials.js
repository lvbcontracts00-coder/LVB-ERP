/* ==========================================================================
   modules/materials.js — Materials catalogue / price book (Phase 4)
   Store collection "materials". The master list of materials the company
   uses, with a unit and a unit cost. Inventory values stock from it and the
   profit module prices stock issues from it; it is reference data, so it
   carries no project cost of its own.
   Record: { id, name, category, unit, unitCost, supplierId, notes }
   ========================================================================== */
(() => {
  "use strict";
  const COL = "materials";
  const CATEGORIES = ["Aggregates & Concrete", "Cement & Mortar", "Bricks & Blocks", "Timber", "Insulation",
    "Plasterboard & Plaster", "Roofing", "Fixings & Fastenings", "Plumbing & Heating", "Electrical",
    "Paint & Decorating", "Drainage", "Other"];
  const UNITS = ["each", "m", "m²", "m³", "kg", "tonne", "bag", "box", "pack", "litre", "roll", "sheet", "length"];

  const canEdit = () => Auth.can("Manager");
  const opts = (list, sel) => list.map((o) => `<option value="${esc(o)}"${o === sel ? " selected" : ""}>${esc(o)}</option>`).join("");
  const supplierName = (id) => id ? ((Store.find("suppliers", id) || {}).name || "Unknown") : "—";
  const supplierOptions = (sel) => `<option value="">— none —</option>` +
    Store.all("suppliers").map((s) => `<option value="${s.id}"${s.id === sel ? " selected" : ""}>${esc(s.name)}</option>`).join("");

  function form(m) {
    m = m || {}; // null-safe: JS default params apply to undefined only, not null
    return `
      <div class="form-grid">
        <div class="field span-2"><label class="field__label">Material name *</label>
          <input class="input" id="m-name" value="${esc(m.name || "")}" placeholder="e.g. OPC cement 25kg"></div>
        <div class="field"><label class="field__label">Category</label>
          <select class="input" id="m-cat">${opts(CATEGORIES, m.category || "Other")}</select></div>
        <div class="field"><label class="field__label">Unit</label>
          <select class="input" id="m-unit">${opts(UNITS, m.unit || "each")}</select></div>
        <div class="field"><label class="field__label">Unit cost (£) *</label>
          <input class="input" id="m-cost" type="number" min="0" step="0.01" value="${m.unitCost ?? ""}" placeholder="0.00"></div>
        <div class="field"><label class="field__label">Preferred supplier</label>
          <select class="input" id="m-supplier">${supplierOptions(m.supplierId)}</select></div>
        <div class="field span-2"><label class="field__label">Notes</label>
          <textarea class="input" id="m-notes" rows="2" placeholder="Spec, pack size, SKU…">${esc(m.notes || "")}</textarea></div>
      </div>`;
  }
  const read = (r) => ({
    name: r.querySelector("#m-name").value.trim(),
    category: r.querySelector("#m-cat").value,
    unit: r.querySelector("#m-unit").value,
    unitCost: parseFloat(r.querySelector("#m-cost").value) || 0,
    supplierId: r.querySelector("#m-supplier").value,
    notes: r.querySelector("#m-notes").value.trim(),
  });

  function openForm(existing) {
    UI.modal({
      title: existing ? "Edit material" : "Add material", size: "lg",
      bodyHTML: form(existing), saveLabel: existing ? "Save changes" : "Add material",
      onSave: (r) => {
        const d = read(r);
        if (!d.name) { UI.toast("Material name is required", "danger"); return false; }
        if (existing) { Store.update(COL, existing.id, d); UI.toast("Material updated", "ok"); }
        else { Store.insert(COL, d); UI.toast("Material added", "ok"); }
        render(document.getElementById("view-root"));
      },
    });
  }
  function remove(m) {
    UI.confirm(`Delete ${m.name}? Existing stock and movements keep their figures.`, () => {
      Store.destroy(COL, m.id); UI.toast("Material deleted", "info");
      render(document.getElementById("view-root"));
    });
  }

  let term = "";
  function render(root) {
    const all = Store.all(COL).sort((a, b) => (a.name || "").localeCompare(b.name || ""));
    const rows = all.filter((m) => !term || (m.name + " " + m.category).toLowerCase().includes(term.toLowerCase()));

    root.innerHTML = `
      <div class="toolbar">
        <div class="toolbar__left">
          <input class="input input--search" id="m-search" placeholder="Search materials…" value="${esc(term)}">
          <span class="muted-count num">${all.length} item${all.length === 1 ? "" : "s"}</span>
        </div>
        ${canEdit() ? `<button class="btn btn--primary" id="m-add">＋ Add material</button>` : ""}
      </div>
      ${rows.length ? `
        <div class="table-wrap"><table class="table">
          <thead><tr><th>Material</th><th>Category</th><th>Unit</th><th class="ta-r">Unit cost</th><th>Supplier</th>${canEdit() ? `<th class="ta-r">Actions</th>` : ""}</tr></thead>
          <tbody>${rows.map((m) => `
            <tr>
              <td><strong>${esc(m.name)}</strong></td>
              <td><span class="badge badge--muted">${esc(m.category || "—")}</span></td>
              <td>${esc(m.unit || "—")}</td>
              <td class="ta-r num">${Fmt.gbp(m.unitCost)}</td>
              <td>${esc(supplierName(m.supplierId))}</td>
              ${canEdit() ? `<td class="ta-r nowrap"><button class="btn btn--sm" data-edit="${m.id}">Edit</button><button class="btn btn--sm btn--danger" data-del="${m.id}">Delete</button></td>` : ""}
            </tr>`).join("")}</tbody>
        </table></div>`
      : `<div class="panel"><div class="panel__body"><div class="empty">
          <svg class="empty__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 7l9-4 9 4-9 4-9-4z"/><path d="M3 7v10l9 4 9-4V7"/><path d="M12 11v10"/></svg>
          <div class="empty__title">${all.length === 0 ? "No materials yet" : "No matches"}</div>
          <div class="empty__text">${all.length === 0 ? (canEdit() ? "Build your price book — add the materials you use." : "Ask a manager to add materials.") : "Try a different search."}</div>
        </div></div></div>`}
    `;
    const search = root.querySelector("#m-search");
    search.addEventListener("input", () => { term = search.value; render(root); const s = document.getElementById("m-search"); if (s) { s.focus(); s.setSelectionRange(s.value.length, s.value.length); } });
    const add = root.querySelector("#m-add"); if (add) add.addEventListener("click", () => openForm(null));
    root.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => openForm(Store.find(COL, b.dataset.edit))));
    root.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => remove(Store.find(COL, b.dataset.del))));
  }

  Modules.section("Project Costing");          // first Phase-4 module owns the nav group
  Modules.register({
    id: "materials", label: "Materials", title: "Materials Catalogue", minRole: "Viewer",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 7l9-4 9 4-9 4-9-4z"/><path d="M3 7v10l9 4 9-4V7"/></svg>',
    render,
  });
})();
