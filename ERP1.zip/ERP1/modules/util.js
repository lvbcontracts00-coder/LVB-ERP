/* ==========================================================================
   modules/util.js — Shared utilities (Phase 6)
   Consolidates helpers that were duplicated across modules and adds the
   cross-cutting export utilities (CSV, PDF/print, chart theming). Defines
   window.Util only — registers no route. Load immediately AFTER app.js so
   every module can use it. Depends on globals from app.js (Store, esc, Fmt).
   ========================================================================== */
(() => {
  "use strict";
  const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;

  /* ---- option / name helpers (were copied into ~15 modules) ------------- */
  const opts = (list, sel) => list.map((o) => `<option value="${esc(o)}"${o === sel ? " selected" : ""}>${esc(o)}</option>`).join("");
  function options(col, sel, { none = null, filter = null, label = "name" } = {}) {
    let list = Store.all(col); if (filter) list = list.filter(filter);
    const head = none ? `<option value="">${esc(none)}</option>` : "";
    return head + list.map((it) => `<option value="${it.id}"${it.id === sel ? " selected" : ""}>${esc(it[label] || "—")}</option>`).join("");
  }
  const nameOf = (col, id, fb = "—") => id ? ((Store.find(col, id) || {})[col === "workers" || col === "sites" || col === "clients" || col === "suppliers" ? "name" : "name"] || "Unknown") : fb;
  const daysUntil = (iso) => { if (!iso) return null; const d = new Date(iso); if (isNaN(d)) return null; return Math.floor((d - new Date(Fmt.todayISO())) / 86400000); };

  /* ---- file helpers (were duplicated in expenses.js & documents.js) ----- */
  function compressImage(file, { max = 1600, quality = 0.7 } = {}) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file); const img = new Image();
      img.onload = () => {
        URL.revokeObjectURL(url); let { width, height } = img;
        if (width > height && width > max) { height = Math.round(height * max / width); width = max; }
        else if (height > max) { width = Math.round(width * max / height); height = max; }
        const c = document.createElement("canvas"); c.width = width; c.height = height;
        c.getContext("2d").drawImage(img, 0, 0, width, height);
        resolve(c.toDataURL("image/jpeg", quality));
      };
      img.onerror = reject; img.src = url;
    });
  }
  const readDataURL = (file) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(file); });

  /* ---- downloads: CSV (was duplicated in profit.js & reports.js) -------- */
  const csvCell = (v) => { const s = v == null ? "" : String(v); return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  const toCSV = (rows) => rows.map((r) => r.map(csvCell).join(",")).join("\r\n");
  function download(filename, content, mime = "text/plain;charset=utf-8;") {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob), a = document.createElement("a");
    a.href = url; a.download = filename; document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 0);
  }
  function downloadCSV(filename, rows) {
    download(filename, "\uFEFF" + toCSV(rows), "text/csv;charset=utf-8;");
    UI.toast("Exported " + filename, "ok");
  }

  /* ---- PDF export via the browser print pipeline (Save as PDF) ---------- */
  const PRINT_CSS = `
    * { box-sizing: border-box; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    body { font: 13px/1.5 -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; color: #1a1d21; margin: 32px; }
    h1 { font-size: 20px; margin: 0 0 2px; } h2 { font-size: 14px; margin: 22px 0 8px; color: #444; }
    .muted { color: #6c7077; font-size: 12px; margin-bottom: 18px; }
    table { width: 100%; border-collapse: collapse; margin: 8px 0 18px; font-size: 12.5px; }
    th, td { text-align: left; padding: 7px 10px; border-bottom: 1px solid #e2ddd2; }
    th { font-size: 11px; text-transform: uppercase; letter-spacing: .04em; color: #6c7077; }
    td.r, th.r { text-align: right; font-variant-numeric: tabular-nums; }
    tfoot td { font-weight: 700; border-top: 2px solid #cfc7b8; }
    img { max-width: 100%; }
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; }
  `;
  function printDocument(title, innerHTML, { extraCss = "" } = {}) {
    const ifr = document.createElement("iframe");
    ifr.setAttribute("aria-hidden", "true");
    ifr.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0;";
    document.body.appendChild(ifr);
    const doc = ifr.contentWindow.document;
    doc.open();
    doc.write(`<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title><style>${PRINT_CSS}${extraCss}</style></head><body>${innerHTML}</body></html>`);
    doc.close();
    const go = () => { try { ifr.contentWindow.focus(); ifr.contentWindow.print(); } catch (e) {} setTimeout(() => ifr.remove(), 1500); };
    if (doc.readyState === "complete") setTimeout(go, 200); else ifr.onload = () => setTimeout(go, 200);
  }

  /* ---- chart theming: resolve CSS custom properties for Chart.js -------- */
  function themeColors() {
    const cs = getComputedStyle(document.documentElement);
    const v = (n, fb) => ((cs.getPropertyValue(n) || "").trim() || fb);
    return {
      text: v("--text", "#1a1d21"), muted: v("--text-muted", "#6c7077"),
      border: v("--border", "#ddd7ca"), surface: v("--surface", "#ffffff"),
      accent: v("--accent", "#ef9a2b"), ok: v("--ok", "#4ba36b"),
      danger: v("--danger", "#d6584e"), warn: v("--warn", "#e0a93b"),
    };
  }
  // run cb whenever the data-theme attribute flips (used by chart views)
  function onThemeChange(cb) {
    const mo = new MutationObserver((muts) => { if (muts.some((m) => m.attributeName === "data-theme")) cb(); });
    mo.observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
    return () => mo.disconnect();
  }

  window.Util = { r2, opts, options, nameOf, daysUntil, compressImage, readDataURL, toCSV, download, downloadCSV, printDocument, themeColors, onThemeChange };
})();
