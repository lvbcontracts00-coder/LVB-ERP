/* ==========================================================================
   modules/healthSafety.js — Health & Safety / RAMS register (Phase 5)
   Store collection "healthSafety". Risk Assessments & Method Statements,
   toolbox talks, permits, COSHH and incidents, with a review date.
   Record: { id, title, type, siteId, author, date, reviewDate, status, notes }
   Review dates feed the calendar; overdue reviews drive a dashboard stat.
   ========================================================================== */
(() => {
  "use strict";
  const COL = "healthSafety";
  const canEdit = () => Auth.can("Manager");
  const TYPES = ["Risk Assessment", "Method Statement", "RAMS", "Toolbox Talk", "COSHH", "Permit to Work", "Incident / Near miss"];
  const STATUSES = ["Draft", "Active", "Under review", "Expired", "Archived"];
  const badgeKind = { "Draft": "muted", "Active": "ok", "Under review": "warn", "Expired": "warn", "Archived": "muted" };

  const opts = (list, sel) => list.map((o) => `<option value="${esc(o)}"${o === sel ? " selected" : ""}>${esc(o)}</option>`).join("");
  const siteName = (id) => id ? ((Store.find("sites", id) || {}).name || "Unknown") : "All sites";
  function siteOptions(sel) { return `<option value="">— all sites —</option>` + Store.all("sites").map((s) => `<option value="${s.id}"${s.id === sel ? " selected" : ""}>${esc(s.name)}</option>`).join(""); }
  const daysUntil = (iso) => { if (!iso) return null; const d = new Date(iso); if (isNaN(d)) return null; return Math.floor((d - new Date(Fmt.todayISO())) / 86400000); };
  const reviewDue = (h) => { const n = daysUntil(h.reviewDate); return n !== null && n <= 14 && h.status !== "Archived"; };

  function openForm(existing) {
    UI.modal({
      title: existing ? "Edit record" : "New H&S record", size: "lg",
      saveLabel: existing ? "Save changes" : "Add record",
      bodyHTML: `
        <div class="form-grid">
          <div class="field span-2"><label class="field__label">Title *</label>
            <input class="input" id="h-title" value="${esc((existing && existing.title) || "")}" placeholder="e.g. Working at height — scaffold"></div>
          <div class="field"><label class="field__label">Type</label>
            <select class="input" id="h-type">${opts(TYPES, (existing && existing.type) || "RAMS")}</select></div>
          <div class="field"><label class="field__label">Project</label>
            <select class="input" id="h-site">${siteOptions(existing && existing.siteId)}</select></div>
          <div class="field"><label class="field__label">Author</label>
            <input class="input" id="h-author" value="${esc((existing && existing.author) || (Auth.current() && Auth.current().name) || "")}"></div>
          <div class="field"><label class="field__label">Status</label>
            <select class="input" id="h-status">${opts(STATUSES, (existing && existing.status) || "Active")}</select></div>
          <div class="field"><label class="field__label">Issued</label>
            <input class="input" id="h-date" type="date" value="${esc((existing && existing.date) || Fmt.todayISO())}"></div>
          <div class="field"><label class="field__label">Review due</label>
            <input class="input" id="h-review" type="date" value="${esc((existing && existing.reviewDate) || "")}"></div>
          <div class="field span-2"><label class="field__label">Notes / scope</label>
            <textarea class="input" id="h-notes" rows="3">${esc((existing && existing.notes) || "")}</textarea></div>
        </div>`,
      onSave: (r) => {
        const title = r.querySelector("#h-title").value.trim();
        if (!title) { UI.toast("Title is required", "danger"); return false; }
        const d = { title, type: r.querySelector("#h-type").value, siteId: r.querySelector("#h-site").value,
          author: r.querySelector("#h-author").value.trim(), status: r.querySelector("#h-status").value,
          date: r.querySelector("#h-date").value, reviewDate: r.querySelector("#h-review").value, notes: r.querySelector("#h-notes").value.trim() };
        if (existing) { Store.update(COL, existing.id, d); UI.toast("Record updated", "ok"); }
        else { Store.insert(COL, d); UI.toast("Record added", "ok"); }
        render(document.getElementById("view-root"));
      },
    });
  }
  function remove(h) { UI.confirm(`Delete "${h.title}"?`, () => { Store.destroy(COL, h.id); UI.toast("Deleted", "info"); render(document.getElementById("view-root")); }); }

  let filt = "all";
  function render(root) {
    const all = Store.all(COL).sort((a, b) => (b.date || "").localeCompare(a.date || ""));
    const rows = all.filter((h) => filt === "all" ? true : filt === "review" ? reviewDue(h) : h.type === filt);
    const dueCount = all.filter(reviewDue).length;
    const fOpts = [["all", "All"], ["review", "Review due"], ...TYPES.map((t) => [t, t])].map(([v, l]) => `<option value="${v}"${filt === v ? " selected" : ""}>${l}</option>`).join("");

    root.innerHTML = `
      <div class="toolbar">
        <div class="toolbar__left filterbar">
          <select class="input" id="h-filter">${fOpts}</select>
          ${dueCount ? `<span class="badge badge--warn">${dueCount} review due</span>` : `<span class="muted-count">reviews current</span>`}
        </div>
        ${canEdit() ? `<button class="btn btn--primary" id="h-add">＋ Add record</button>` : ""}
      </div>
      ${rows.length ? `
        <div class="table-wrap"><table class="table">
          <thead><tr><th>Title</th><th>Type</th><th>Project</th><th>Author</th><th>Status</th><th>Review</th>${canEdit() ? `<th class="ta-r">Actions</th>` : ""}</tr></thead>
          <tbody>${rows.map((h) => {
            const n = daysUntil(h.reviewDate);
            const rev = h.reviewDate ? `<span class="badge badge--${n < 0 ? "warn" : n <= 14 ? "warn" : "ok"}">${n < 0 ? "overdue" : Fmt.dayMon(h.reviewDate)}</span>` : `<span class="muted-count">—</span>`;
            return `<tr>
              <td><strong>${esc(h.title)}</strong></td>
              <td>${esc(h.type || "—")}</td>
              <td>${esc(siteName(h.siteId))}</td>
              <td>${esc(h.author || "—")}</td>
              <td><span class="badge badge--${badgeKind[h.status] || "muted"}">${esc(h.status || "—")}</span></td>
              <td>${rev}</td>
              ${canEdit() ? `<td class="ta-r nowrap"><button class="btn btn--sm" data-edit="${h.id}">Edit</button><button class="btn btn--sm btn--danger" data-del="${h.id}">Del</button></td>` : ""}
            </tr>`; }).join("")}</tbody>
        </table></div>`
      : `<div class="panel"><div class="panel__body"><div class="empty">
          <svg class="empty__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 2l8 4v6c0 5-3.5 8-8 10-4.5-2-8-5-8-10V6z"/><path d="M9 12l2 2 4-4"/></svg>
          <div class="empty__title">No H&amp;S records ${filt === "all" ? "yet" : "in this view"}</div>
          <div class="empty__text">${canEdit() ? "Add risk assessments, method statements and toolbox talks." : "Ask a manager to add records."}</div>
        </div></div></div>`}
    `;
    root.querySelector("#h-filter").addEventListener("change", (e) => { filt = e.target.value; render(root); });
    const add = root.querySelector("#h-add"); if (add) add.addEventListener("click", () => openForm(null));
    root.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => openForm(Store.find(COL, b.dataset.edit))));
    root.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => remove(Store.find(COL, b.dataset.del))));
  }

  Dashboard.addStat(() => {
    const due = Store.all(COL).filter(reviewDue).length;
    return { label: "RAMS reviews", value: String(due), note: due ? "due ≤14d / overdue" : "all current", route: "healthSafety" };
  });

  Modules.register({
    id: "healthSafety", label: "Health & Safety", title: "Health & Safety / RAMS", minRole: "Viewer",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l8 4v6c0 5-3.5 8-8 10-4.5-2-8-5-8-10V6z"/><path d="M9 12l2 2 4-4"/></svg>',
    render,
  });
})();
