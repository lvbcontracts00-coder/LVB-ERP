/* ==========================================================================
   modules/calendar.js — Company calendar (Phase 5)
   Owns ad-hoc events in Store collection "calendarEvents"
   ({ id, date, title, type, siteId, notes }) and AGGREGATES dated items from
   across the system into a month grid — read-only references that deep-link to
   their source module. Aggregated sources never depend on this module loading.
   ========================================================================== */
(() => {
  "use strict";
  const COL = "calendarEvents";
  const canEdit = () => Auth.can("Manager");
  const TYPES = ["Site visit", "Meeting", "Delivery", "Inspection", "Deadline", "Other"];
  const KIND_BADGE = { due: "warn", leave: "ok", compliance: "warn", project: "muted", event: "ok" };

  const state = { y: new Date().getFullYear(), m: new Date().getMonth() };
  const pad = (n) => String(n).padStart(2, "0");
  const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const siteName = (id) => id ? ((Store.find("sites", id) || {}).name || "Unknown") : "";
  const workerName = (id) => (Store.find("workers", id) || {}).name || "Worker";

  function siteOptions(sel) { return `<option value="">— none —</option>` + Store.all("sites").map((s) => `<option value="${s.id}"${s.id === sel ? " selected" : ""}>${esc(s.name)}</option>`).join(""); }
  const opts = (list, sel) => list.map((o) => `<option value="${esc(o)}"${o === sel ? " selected" : ""}>${esc(o)}</option>`).join("");

  /* ---- aggregate every dated thing within [from,to] (YYYY-MM-DD) -------- */
  function collect(from, to) {
    const out = [];
    const inWin = (d) => d && d >= from && d <= to;
    const push = (date, label, kind, route, id) => { if (inWin(date)) out.push({ date, label, kind, route, id }); };

    Store.all(COL).forEach((e) => push((e.date || "").slice(0, 10), e.title || "Event", "event", "calendar", e.id));
    Store.all("sites").forEach((s) => push((s.startDate || "").slice(0, 10), `Start: ${s.name}`, "project", "sites"));
    Store.all("invoices").forEach((i) => { if (i.status !== "Draft" && i.status !== "Paid") push((i.date2 || "").slice(0, 10), `Invoice ${i.number || ""} due`, "due", "invoices"); });
    Store.all("quotes").forEach((q) => push((q.date2 || "").slice(0, 10), `Quote ${q.number || ""} expires`, "due", "quotes"));
    Store.all("purchaseOrders").forEach((p) => { if (p.status === "Ordered") push((p.date2 || "").slice(0, 10), `PO ${p.number || ""} required`, "due", "purchaseOrders"); });
    Store.all("skipHire").forEach((k) => { if (k.status !== "Cancelled") push((k.hireDate || "").slice(0, 10), `Skip ${k.size || ""} · ${siteName(k.siteId)}`, "project", "skipHire"); });
    Store.all("vehicles").forEach((v) => {
      [["MOT", v.motDate], ["Tax", v.taxDate], ["Insurance", v.insuranceDate], ["Service", v.serviceDate]]
        .forEach(([k, d]) => push((d || "").slice(0, 10), `${v.reg} ${k}`, "compliance", "vehicles"));
    });
    Store.all("equipment").forEach((e) => push((e.inspectionDate || "").slice(0, 10), `Inspect ${e.name}`, "compliance", "equipment"));
    Store.all("healthSafety").forEach((h) => push((h.reviewDate || "").slice(0, 10), `RAMS review: ${h.title}`, "compliance", "healthSafety"));
    // approved leave expanded across each day within the window
    Store.all("leave").forEach((l) => {
      if (l.status !== "Approved" || !l.from || !l.to) return;
      let d = new Date(l.from), end = new Date(l.to);
      for (; d <= end; d.setDate(d.getDate() + 1)) push(ymd(d), `Leave: ${workerName(l.workerId)} (${l.type})`, "leave", "leaveManagement");
    });
    return out;
  }

  /* ---- ad-hoc event editor --------------------------------------------- */
  function openForm(existing, presetDate) {
    UI.modal({
      title: existing ? "Edit event" : "Add event", size: "lg",
      saveLabel: existing ? "Save changes" : "Add event",
      bodyHTML: `
        <div class="form-grid">
          <div class="field span-2"><label class="field__label">Title *</label>
            <input class="input" id="c-title" value="${esc((existing && existing.title) || "")}" placeholder="e.g. Building control inspection"></div>
          <div class="field"><label class="field__label">Date *</label>
            <input class="input" id="c-date" type="date" value="${esc((existing && existing.date) || presetDate || Fmt.todayISO())}"></div>
          <div class="field"><label class="field__label">Type</label>
            <select class="input" id="c-type">${opts(TYPES, (existing && existing.type) || "Site visit")}</select></div>
          <div class="field span-2"><label class="field__label">Project</label>
            <select class="input" id="c-site">${siteOptions(existing && existing.siteId)}</select></div>
          <div class="field span-2"><label class="field__label">Notes</label>
            <textarea class="input" id="c-notes" rows="2">${esc((existing && existing.notes) || "")}</textarea></div>
        </div>`,
      onSave: (r) => {
        const title = r.querySelector("#c-title").value.trim();
        if (!title) { UI.toast("Title is required", "danger"); return false; }
        const d = { title, date: r.querySelector("#c-date").value || Fmt.todayISO(), type: r.querySelector("#c-type").value, siteId: r.querySelector("#c-site").value, notes: r.querySelector("#c-notes").value.trim() };
        if (existing) { Store.update(COL, existing.id, d); UI.toast("Event updated", "ok"); }
        else { Store.insert(COL, d); UI.toast("Event added", "ok"); }
        render(document.getElementById("view-root"));
      },
    });
  }
  function dayModal(dateStr, events) {
    const list = events.length ? `<ul class="activity">${events.map((e) => `
      <li class="activity__row" ${e.route ? `data-go="${e.route}" data-evid="${e.id || ""}" role="button" tabindex="0"` : ""} style="cursor:pointer">
        <span class="activity__dot"></span>
        <span class="activity__text"><span class="badge badge--${KIND_BADGE[e.kind] || "muted"}">${esc(e.kind)}</span> ${esc(e.label)}</span>
      </li>`).join("")}</ul>` : `<p class="hint">Nothing scheduled.</p>`;
    UI.modal({
      title: Fmt.date(dateStr), size: "lg",
      bodyHTML: list + (canEdit() ? `<div class="toolbar" style="margin-top:12px"><button class="btn btn--primary btn--sm" id="c-addday" style="margin-left:auto">＋ Add event this day</button></div>` : ""),
    });
    const mr = document.getElementById("modal-root");
    const addBtn = mr.querySelector("#c-addday");
    if (addBtn) addBtn.addEventListener("click", () => { UI.closeModal(); openForm(null, dateStr); });
    mr.querySelectorAll("[data-go]").forEach((el) => el.addEventListener("click", () => {
      const evid = el.dataset.evid, route = el.dataset.go;
      if (route === "calendar" && evid && canEdit()) { UI.closeModal(); openForm(Store.find(COL, evid)); }
      else { UI.closeModal(); Router.navigate(route); }
    }));
  }

  /* ---- render month grid ----------------------------------------------- */
  function render(root) {
    const first = new Date(state.y, state.m, 1);
    const gridStart = new Date(first); gridStart.setDate(1 - ((first.getDay() + 6) % 7)); // back to Monday
    const cells = []; const d = new Date(gridStart);
    for (let i = 0; i < 42; i++) { cells.push(new Date(d)); d.setDate(d.getDate() + 1); }
    const from = ymd(cells[0]), to = ymd(cells[41]);

    const byDay = {};
    collect(from, to).forEach((e) => { (byDay[e.date] = byDay[e.date] || []).push(e); });

    const todayStr = Fmt.todayISO();
    const monthLabel = first.toLocaleDateString("en-GB", { month: "long", year: "numeric" });
    const dows = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

    const cellHtml = (day) => {
      const k = ymd(day), evs = byDay[k] || [], inMonth = day.getMonth() === state.m, isToday = k === todayStr;
      const chips = evs.slice(0, 3).map((e) => `<div class="badge badge--${KIND_BADGE[e.kind] || "muted"}" style="display:block;text-align:left;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin:1px 0;font-size:11px">${esc(e.label)}</div>`).join("");
      const more = evs.length > 3 ? `<div class="muted-count" style="font-size:11px">+${evs.length - 3} more</div>` : "";
      return `<td style="vertical-align:top;padding:4px;cursor:pointer${inMonth ? "" : ";opacity:.4"}" data-day="${k}">
        <div style="min-height:74px">
          <div class="num" style="font-weight:${isToday ? "700" : "500"};${isToday ? "color:var(--accent,#2563eb)" : ""}">${day.getDate()}</div>
          ${chips}${more}
        </div></td>`;
    };
    let weeks = "";
    for (let w = 0; w < 6; w++) weeks += `<tr>${cells.slice(w * 7, w * 7 + 7).map(cellHtml).join("")}</tr>`;

    root.innerHTML = `
      <div class="toolbar">
        <div class="toolbar__left filterbar">
          <button class="btn btn--sm" id="c-prev">←</button>
          <strong style="min-width:160px;display:inline-block;text-align:center">${esc(monthLabel)}</strong>
          <button class="btn btn--sm" id="c-next">→</button>
          <button class="btn btn--sm" id="c-today">Today</button>
        </div>
        ${canEdit() ? `<button class="btn btn--primary" id="c-add">＋ Add event</button>` : ""}
      </div>
      <div class="panel"><div class="panel__body">
        <div class="table-wrap"><table class="table calendar-grid">
          <thead><tr>${dows.map((d) => `<th>${d}</th>`).join("")}</tr></thead>
          <tbody>${weeks}</tbody>
        </table></div>
      </div></div>
    `;
    root.querySelector("#c-prev").addEventListener("click", () => { state.m--; if (state.m < 0) { state.m = 11; state.y--; } render(root); });
    root.querySelector("#c-next").addEventListener("click", () => { state.m++; if (state.m > 11) { state.m = 0; state.y++; } render(root); });
    root.querySelector("#c-today").addEventListener("click", () => { const n = new Date(); state.y = n.getFullYear(); state.m = n.getMonth(); render(root); });
    const add = root.querySelector("#c-add"); if (add) add.addEventListener("click", () => openForm(null));
    root.querySelectorAll("[data-day]").forEach((td) => td.addEventListener("click", () => dayModal(td.dataset.day, byDay[td.dataset.day] || [])));
  }

  Modules.register({
    id: "calendar", label: "Calendar", title: "Calendar", minRole: "Viewer",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 9h18M8 3v4M16 3v4M7 13h3v3H7z"/></svg>',
    render,
  });
})();
