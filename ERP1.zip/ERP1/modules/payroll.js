/* ==========================================================================
   modules/payroll.js — Fortnight Payroll (rebuilt for accountant workflow)
   The company pays every 2 weeks, so the FORTNIGHT is the primary period.
   Single screen to process payroll for the whole company:
     · Payroll Period Dashboard (summary stats for the selected period)
     · Period selector — Current/Previous Week, Current/Previous Fortnight
       (default), Custom Range
     · Payroll Summary by Worker — Hours Wk1 · Hours Wk2 · Total · Rate · Pay
     · Labour Cost by Project — for the same period
     · One-click export to PDF and Excel (.xlsx)
   Saved runs are preserved (Store collection "payrollRuns").
   Manager+ only (pay data is sensitive).

   SCOPE: GROSS pay only (hours × rate, OT premium). NOT a tax engine — PAYE,
   NI and pension are out of scope (see HMRC / real payroll software).
   ========================================================================== */
(() => {
  "use strict";
  const COL = "payrollRuns";
  const PREFS = "payrollPrefs";

  // Fortnights are anchored to Mondays. 2024-01-01 was a Monday; every 14-day
  // block from there is a pay fortnight, so "current fortnight" is deterministic
  // and consistent for everyone regardless of when the screen is opened.
  const REF_MONDAY = new Date(2024, 0, 1);

  const defaults = { period: "current-fortnight", otMult: 1.5, customFrom: null, customTo: null };
  const state = Object.assign({}, defaults, Store.read(PREFS, {}));
  const savePrefs = () => Store.write(PREFS, { period: state.period, otMult: state.otMult, customFrom: state.customFrom, customTo: state.customTo });

  /* ---- date helpers ------------------------------------------------------ */
  const DAY = 86400000;
  const iso = Period.isoOf; // shared LOCAL serialisation (was UTC — day-shift bug)
  const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
  function fortnightStart(now = new Date()) {
    const monday = Period.startOfWeek(now);            // Monday of this week, 00:00
    const weeks = Math.round((monday - REF_MONDAY) / (7 * DAY));
    return (weeks % 2 !== 0) ? addDays(monday, -7) : monday; // align to 14-day grid
  }

  /* Returns a descriptor: { key, label, from, to, w1:{from,to}, w2:{from,to}|null } */
  function periodInfo() {
    const now = new Date();
    let from, to;
    if (state.period === "current-week") {
      from = Period.startOfWeek(now); to = addDays(from, 6);
    } else if (state.period === "previous-week") {
      to = addDays(Period.startOfWeek(now), -1); from = addDays(to, -6);
    } else if (state.period === "previous-fortnight") {
      from = addDays(fortnightStart(now), -14); to = addDays(from, 13);
    } else if (state.period === "custom") {
      from = state.customFrom ? new Date(state.customFrom + "T00:00:00") : fortnightStart(now);
      to = state.customTo ? new Date(state.customTo + "T00:00:00") : addDays(from, 13);
      if (to < from) { const t = from; from = to; to = t; }
    } else { // current-fortnight (default)
      from = fortnightStart(now); to = addDays(from, 13);
    }
    const w1 = { from: iso(from), to: iso(addDays(from, 6) < to ? addDays(from, 6) : to) };
    const w2start = addDays(from, 7);
    const w2 = w2start <= to ? { from: iso(w2start), to: iso(to) } : null;
    return {
      key: state.period, label: LABELS[state.period] || "Custom range",
      from: iso(from), to: iso(to), w1, w2,
    };
  }

  const LABELS = {
    "current-week": "Current week", "previous-week": "Previous week",
    "current-fortnight": "Current fortnight", "previous-fortnight": "Previous fortnight",
    "custom": "Custom range",
  };

  /* ---- calculation ------------------------------------------------------- */
  const workerName = (id) => (Store.find("workers", id) || {}).name || "Unknown worker";
  const siteName = (id) => id ? ((Store.find("sites", id) || {}).name || "Unknown site") : "Unallocated";

  function compute(info) {
    const sheets = Store.all("timesheets").filter((t) => Period.inRange(t.date, info.from, info.to));
    const byWorker = new Map();
    const bySite = new Map();

    sheets.forEach((t) => {
      const w = Store.find("workers", t.workerId);
      if (!w) return; // worker deleted — skip
      const reg = Number(t.hours) || 0, ot = Number(t.overtime) || 0, all = reg + ot;
      const inW1 = Period.inRange(t.date, info.w1.from, info.w1.to);

      const cur = byWorker.get(w.id) || {
        workerId: w.id, name: w.name, trade: w.trade || "", rate: Number(w.rate) || 0,
        regHours: 0, otHours: 0, w1Hours: 0, totalHours: 0,
      };
      cur.regHours += reg; cur.otHours += ot; cur.totalHours += all;
      if (inW1) cur.w1Hours += all;
      byWorker.set(w.id, cur);

      // labour by project (gross cost incl. OT premium)
      const rate = Number(w.rate) || 0;
      const cost = reg * rate + ot * rate * state.otMult;
      const sKey = t.siteId || "";
      const s = bySite.get(sKey) || { siteId: t.siteId || null, name: siteName(t.siteId), hours: 0, cost: 0 };
      s.hours += all; s.cost += cost;
      bySite.set(sKey, s);
    });

    const lines = [...byWorker.values()].map((l) => ({
      ...l,
      w2Hours: Math.max(0, l.totalHours - l.w1Hours), // remainder of period (week 2+)
      gross: l.regHours * l.rate + l.otHours * l.rate * state.otMult,
    })).sort((a, b) => b.gross - a.gross);

    const projects = [...bySite.values()].sort((a, b) => b.cost - a.cost);

    return {
      info, lines, projects,
      totalGross: lines.reduce((s, l) => s + l.gross, 0),
      totalHours: lines.reduce((s, l) => s + l.totalHours, 0),
      totalW1: lines.reduce((s, l) => s + l.w1Hours, 0),
      totalW2: lines.reduce((s, l) => s + l.w2Hours, 0),
      totalOT: lines.reduce((s, l) => s + l.otHours, 0),
      workerCount: lines.filter((l) => l.totalHours > 0).length,
    };
  }

  /* ---- self-contained XLSX writer (no dependency; offline-safe) ---------- */
  const Xlsx = (() => {
    const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1); t[n] = c >>> 0; } return t; })();
    const crc32 = (b) => { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
    const enc = (s) => new TextEncoder().encode(s);
    const x = (s) => String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
    const col = (i) => { let s = ""; i += 1; while (i > 0) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; };

    function zip(files) {
      const u16 = (n) => [n & 0xFF, (n >>> 8) & 0xFF];
      const u32 = (n) => [n & 0xFF, (n >>> 8) & 0xFF, (n >>> 16) & 0xFF, (n >>> 24) & 0xFF];
      const chunks = [], central = []; let offset = 0;
      files.forEach((f) => {
        const nb = enc(f.name), crc = crc32(f.data), size = f.data.length;
        const local = [].concat(u32(0x04034b50), u16(20), u16(0), u16(0), u16(0), u16(0), u32(crc), u32(size), u32(size), u16(nb.length), u16(0));
        chunks.push(new Uint8Array(local), nb, f.data);
        central.push(new Uint8Array([].concat(u32(0x02014b50), u16(20), u16(20), u16(0), u16(0), u16(0), u16(0), u32(crc), u32(size), u32(size), u16(nb.length), u16(0), u16(0), u16(0), u16(0), u32(0), u32(offset))), nb);
        offset += local.length + nb.length + size;
      });
      let cdirSize = 0; central.forEach((c) => { cdirSize += c.length; });
      const end = new Uint8Array([].concat(u32(0x06054b50), u16(0), u16(0), u16(files.length), u16(files.length), u32(cdirSize), u32(offset), u16(0)));
      const all = [...chunks, ...central, end]; let total = 0; all.forEach((a) => { total += a.length; });
      const out = new Uint8Array(total); let p = 0; all.forEach((a) => { out.set(a, p); p += a.length; });
      return out;
    }
    const sheetXml = (rows) => `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${rows.map((row, r) => `<row r="${r + 1}">${row.map((cell, c) => { const ref = col(c) + (r + 1); let v = cell, t = "s"; if (cell && typeof cell === "object") { v = cell.v; t = cell.t || "s"; } if (t === "n") { const num = Number(v); return `<c r="${ref}"><v>${isFinite(num) ? num : 0}</v></c>`; } return `<c r="${ref}" t="inlineStr"><is><t xml:space="preserve">${x(v)}</t></is></c>`; }).join("")}</row>`).join("")}</sheetData></worksheet>`;

    function build(sheets) {
      const files = [];
      const types = ['<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>', '<Default Extension="xml" ContentType="application/xml"/>', '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'];
      const rels = [], wb = [];
      sheets.forEach((s, i) => { const n = i + 1; files.push({ name: `xl/worksheets/sheet${n}.xml`, data: enc(sheetXml(s.rows)) }); types.push(`<Override PartName="/xl/worksheets/sheet${n}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`); rels.push(`<Relationship Id="rId${n}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${n}.xml"/>`); wb.push(`<sheet name="${x(s.name).slice(0, 31)}" sheetId="${n}" r:id="rId${n}"/>`); });
      files.unshift({ name: "[Content_Types].xml", data: enc(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">${types.join("")}</Types>`) });
      files.push({ name: "_rels/.rels", data: enc(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`) });
      files.push({ name: "xl/workbook.xml", data: enc(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${wb.join("")}</sheets></workbook>`) });
      files.push({ name: "xl/_rels/workbook.xml.rels", data: enc(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${rels.join("")}</Relationships>`) });
      return zip(files);
    }
    return { build };
  })();

  const fileStamp = (info) => `${info.from}_to_${info.to}`;

  function exportExcel(calc) {
    const info = calc.info;
    const co = (Commercial.Company.get && Commercial.Company.get().name) || "Company";
    const N = (v) => ({ v: Math.round((Number(v) || 0) * 100) / 100, t: "n" });
    const workerRows = [
      [co + " — Payroll by Worker"],
      [info.label, `${info.from} to ${info.to}`],
      [],
      ["Worker", "Trade", "Hours Week 1", "Hours Week 2", "Total Hours", "Hourly Rate", "Total Pay"],
      ...calc.lines.map((l) => [l.name, l.trade || "", N(l.w1Hours), N(l.w2Hours), N(l.totalHours), N(l.rate), N(l.gross)]),
      ["TOTAL", "", N(calc.totalW1), N(calc.totalW2), N(calc.totalHours), "", N(calc.totalGross)],
    ];
    const projectRows = [
      [co + " — Labour Cost by Project"],
      [info.label, `${info.from} to ${info.to}`],
      [],
      ["Project", "Total Hours", "Labour Cost"],
      ...calc.projects.map((p) => [p.name, N(p.hours), N(p.cost)]),
      ["TOTAL", N(calc.projects.reduce((s, p) => s + p.hours, 0)), N(calc.projects.reduce((s, p) => s + p.cost, 0))],
    ];
    const data = Xlsx.build([
      { name: "Payroll by Worker", rows: workerRows },
      { name: "Labour by Project", rows: projectRows },
    ]);
    Util.download(`payroll_${fileStamp(info)}.xlsx`, data, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    UI.toast("Exported payroll .xlsx", "ok");
  }

  function exportPdf(calc) {
    const info = calc.info;
    const co = (Commercial.Company.get && Commercial.Company.get().name) || "Company";
    const wrows = calc.lines.map((l) => `<tr><td>${esc(l.name)}</td><td>${esc(l.trade || "—")}</td><td class="r">${Fmt.hours(l.w1Hours)}</td><td class="r">${Fmt.hours(l.w2Hours)}</td><td class="r">${Fmt.hours(l.totalHours)}</td><td class="r">${Fmt.gbp(l.rate)}</td><td class="r">${Fmt.gbp(l.gross)}</td></tr>`).join("");
    const prows = calc.projects.map((p) => `<tr><td>${esc(p.name)}</td><td class="r">${Fmt.hours(p.hours)}</td><td class="r">${Fmt.gbp(p.cost)}</td></tr>`).join("");
    const html = `
      <h1>Payroll — ${esc(info.label)}</h1>
      <div class="muted">${esc(co)} · ${Fmt.date(info.from)} – ${Fmt.date(info.to)} · generated ${Fmt.date(Fmt.todayISO())} by ${esc(Auth.current().name)}</div>
      <div class="grid">
        <div><strong>${calc.workerCount}</strong> worker${calc.workerCount === 1 ? "" : "s"} · <strong>${Fmt.hours(calc.totalHours)}</strong> hrs</div>
        <div style="text-align:right"><strong>${Fmt.gbp(calc.totalGross)}</strong> gross</div>
      </div>
      <h2>Payroll summary by worker</h2>
      <table><thead><tr><th>Worker</th><th>Trade</th><th class="r">Hrs Wk 1</th><th class="r">Hrs Wk 2</th><th class="r">Total hrs</th><th class="r">Rate</th><th class="r">Total pay</th></tr></thead>
      <tbody>${wrows || `<tr><td colspan="7">No hours in this period</td></tr>`}</tbody>
      <tfoot><tr><td colspan="2">Total (${calc.workerCount})</td><td class="r">${Fmt.hours(calc.totalW1)}</td><td class="r">${Fmt.hours(calc.totalW2)}</td><td class="r">${Fmt.hours(calc.totalHours)}</td><td></td><td class="r">${Fmt.gbp(calc.totalGross)}</td></tr></tfoot></table>
      <h2>Labour cost by project</h2>
      <table><thead><tr><th>Project</th><th class="r">Total hrs</th><th class="r">Labour cost</th></tr></thead>
      <tbody>${prows || `<tr><td colspan="3">No labour in this period</td></tr>`}</tbody>
      <tfoot><tr><td>Total</td><td class="r">${Fmt.hours(calc.projects.reduce((s, p) => s + p.hours, 0))}</td><td class="r">${Fmt.gbp(calc.projects.reduce((s, p) => s + p.cost, 0))}</td></tr></tfoot></table>
      <p class="muted">Gross pay only — excludes PAYE tax, National Insurance and pension deductions. OT charged at ${state.otMult}× base rate. Internal estimate, not a payslip.</p>`;
    Util.printDocument(`Payroll ${info.from} to ${info.to}`, html);
  }

  /* ---- save / runs history ----------------------------------------------- */
  function saveRun(calc) {
    if (!calc.lines.length) { UI.toast("Nothing to save for this period", "danger"); return; }
    Store.insert(COL, {
      periodKey: calc.info.key, periodLabel: calc.info.label,
      from: calc.info.from, to: calc.info.to, otMult: state.otMult,
      lines: calc.lines, projects: calc.projects,
      totalGross: calc.totalGross, totalHours: calc.totalHours,
      generatedBy: Auth.current().name,
    });
    UI.toast("Payroll run saved", "ok");
    render(document.getElementById("view-root"));
  }
  function deleteRun(id) {
    UI.confirm("Delete this saved payroll run?", () => {
      Store.destroy(COL, id);
      UI.toast("Run deleted", "info");
      render(document.getElementById("view-root"));
    });
  }

  /* ---- render ------------------------------------------------------------ */
  function statCard(label, value, note) {
    return `<div class="stat"><div class="stat__label">${esc(label)}</div><div class="stat__value num">${esc(value)}</div>${note ? `<div class="stat__note">${esc(note)}</div>` : ""}</div>`;
  }

  function render(root) {
    if (!Store.all("timesheets").length) {
      root.innerHTML = `<div class="panel"><div class="panel__body"><div class="empty">
        <svg class="empty__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
        <div class="empty__title">No timesheets to process</div>
        <div class="empty__text">Log some hours first, then run payroll.</div>
        <div class="empty__actions"><button class="btn btn--sm" data-route="timesheets">Go to Timesheets</button></div>
      </div></div></div>`;
      root.querySelector("[data-route]").addEventListener("click", () => Router.navigate("timesheets"));
      return;
    }

    const info = periodInfo();
    const calc = compute(info);
    const runs = Store.all(COL).sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""));
    const single = !info.w2; // single-week period → no Week 2 split
    const avg = calc.workerCount ? calc.totalGross / calc.workerCount : 0;

    const pOpts = Object.entries(LABELS).map(([v, l]) => `<option value="${v}"${state.period === v ? " selected" : ""}>${l}</option>`).join("");

    root.innerHTML = `
      <div class="toolbar">
        <div class="toolbar__left filterbar">
          <select class="input" id="p-period">${pOpts}</select>
          ${state.period === "custom" ? `
            <label class="inline-field">From <input class="input input--mini" id="p-from" type="date" style="width:150px" value="${esc(state.customFrom || info.from)}"></label>
            <label class="inline-field">To <input class="input input--mini" id="p-to" type="date" style="width:150px" value="${esc(state.customTo || info.to)}"></label>` : ""}
          <label class="inline-field">OT ×
            <input class="input input--mini" id="p-ot" type="number" min="1" step="0.1" value="${state.otMult}">
          </label>
          <span class="muted-count num">${Fmt.date(info.from)} – ${Fmt.date(info.to)}</span>
        </div>
        <div class="filterbar">
          <button class="btn btn--sm" id="p-pdf">Export PDF</button>
          <button class="btn btn--sm" id="p-xls">Export Excel</button>
          <button class="btn btn--primary" id="p-save"${calc.lines.length ? "" : " disabled"}>Save run</button>
        </div>
      </div>

      <!-- Payroll Period Dashboard -->
      <div class="stat-grid">
        ${statCard("Gross pay", Fmt.gbp(calc.totalGross), info.label.toLowerCase())}
        ${statCard("Workers paid", String(calc.workerCount), calc.totalOT ? `incl. ${Fmt.hours(calc.totalOT)} OT hrs` : "no overtime")}
        ${statCard("Total hours", Fmt.hours(calc.totalHours), single ? "single week" : `Wk1 ${Fmt.hours(calc.totalW1)} · Wk2 ${Fmt.hours(calc.totalW2)}`)}
        ${statCard("Avg / worker", Fmt.gbp(avg), "gross")}
      </div>

      <!-- Payroll Summary by Worker -->
      <div class="panel">
        <div class="panel__head"><span class="panel__title">Payroll summary by worker</span><span class="muted-count num">${calc.workerCount} paid</span></div>
        <div class="panel__body">
          ${calc.lines.length ? `
          <div class="table-wrap"><table class="table">
            <thead><tr>
              <th>Worker</th><th>Trade</th>
              <th class="ta-r">Hours Wk 1</th><th class="ta-r">Hours Wk 2</th><th class="ta-r">Total hours</th>
              <th class="ta-r">Hourly rate</th><th class="ta-r">Total pay</th>
            </tr></thead>
            <tbody>
              ${calc.lines.map((l) => `
                <tr>
                  <td><strong>${esc(l.name)}</strong></td>
                  <td>${esc(l.trade || "—")}</td>
                  <td class="ta-r num">${Fmt.hours(l.w1Hours)}</td>
                  <td class="ta-r num">${single ? "—" : Fmt.hours(l.w2Hours)}</td>
                  <td class="ta-r num">${Fmt.hours(l.totalHours)}</td>
                  <td class="ta-r num">${Fmt.gbp(l.rate)}</td>
                  <td class="ta-r num"><strong>${Fmt.gbp(l.gross)}</strong></td>
                </tr>`).join("")}
            </tbody>
            <tfoot><tr class="totals">
              <td colspan="2">${calc.workerCount} worker${calc.workerCount === 1 ? "" : "s"}</td>
              <td class="ta-r num">${Fmt.hours(calc.totalW1)}</td>
              <td class="ta-r num">${single ? "—" : Fmt.hours(calc.totalW2)}</td>
              <td class="ta-r num">${Fmt.hours(calc.totalHours)}</td>
              <td></td>
              <td class="ta-r num">${Fmt.gbp(calc.totalGross)}</td>
            </tr></tfoot>
          </table></div>
          <p class="hint hint--block">Gross pay only — excludes PAYE tax, National Insurance and pension. OT charged at ${state.otMult}× base rate. Use as an internal estimate, not a payslip.</p>`
          : `<div class="empty"><div class="empty__title">No hours in this period</div><div class="empty__text">Switch period or log timesheets.</div></div>`}
        </div>
      </div>

      <!-- Labour Cost by Project -->
      <div class="panel">
        <div class="panel__head"><span class="panel__title">Labour cost by project</span><span class="muted-count num">${Fmt.gbp(calc.projects.reduce((s, p) => s + p.cost, 0))}</span></div>
        <div class="panel__body">
          ${calc.projects.length ? `
          <div class="table-wrap"><table class="table table--tight">
            <thead><tr><th>Project</th><th class="ta-r">Total hours</th><th class="ta-r">Labour cost</th></tr></thead>
            <tbody>
              ${calc.projects.map((p) => `<tr>
                <td><strong>${esc(p.name)}</strong></td>
                <td class="ta-r num">${Fmt.hours(p.hours)}</td>
                <td class="ta-r num">${Fmt.gbp(p.cost)}</td>
              </tr>`).join("")}
            </tbody>
            <tfoot><tr class="totals">
              <td>${calc.projects.length} project${calc.projects.length === 1 ? "" : "s"}</td>
              <td class="ta-r num">${Fmt.hours(calc.projects.reduce((s, p) => s + p.hours, 0))}</td>
              <td class="ta-r num">${Fmt.gbp(calc.projects.reduce((s, p) => s + p.cost, 0))}</td>
            </tr></tfoot>
          </table></div>`
          : `<div class="empty"><div class="empty__title">No project labour</div><div class="empty__text">No timesheets fall in this period.</div></div>`}
        </div>
      </div>

      ${runs.length ? `
        <div class="panel runs">
          <div class="panel__head"><span class="panel__title">Saved runs</span><span class="muted-count num">${runs.length}</span></div>
          <div class="panel__body">
            <div class="table-wrap"><table class="table table--tight">
              <thead><tr><th>Saved</th><th>Period</th><th>By</th><th class="ta-r">Gross total</th><th class="ta-r"></th></tr></thead>
              <tbody>
                ${runs.map((r) => `<tr>
                  <td class="num">${Fmt.date(r.createdAt)}</td>
                  <td>${esc(r.periodLabel)}${r.from ? ` <span class="muted-count num">(${Fmt.dayMon(r.from)}–${Fmt.dayMon(r.to)})</span>` : ""}</td>
                  <td>${esc(r.generatedBy || "—")}</td>
                  <td class="ta-r num"><strong>${Fmt.gbp(r.totalGross)}</strong></td>
                  <td class="ta-r"><button class="btn btn--sm btn--danger" data-delrun="${r.id}">Delete</button></td>
                </tr>`).join("")}
              </tbody>
            </table></div>
          </div>
        </div>` : ""}
    `;

    root.querySelector("#p-period").addEventListener("change", (e) => { state.period = e.target.value; savePrefs(); render(root); });
    const fromEl = root.querySelector("#p-from"), toEl = root.querySelector("#p-to");
    if (fromEl) fromEl.addEventListener("change", (e) => { state.customFrom = e.target.value; savePrefs(); render(root); });
    if (toEl) toEl.addEventListener("change", (e) => { state.customTo = e.target.value; savePrefs(); render(root); });
    root.querySelector("#p-ot").addEventListener("change", (e) => { const v = parseFloat(e.target.value); state.otMult = isNaN(v) || v < 1 ? 1 : v; savePrefs(); render(root); });
    root.querySelector("#p-pdf").addEventListener("click", () => exportPdf(calc));
    root.querySelector("#p-xls").addEventListener("click", () => exportExcel(calc));
    root.querySelector("#p-save").addEventListener("click", () => saveRun(calc));
    root.querySelectorAll("[data-delrun]").forEach((b) => b.addEventListener("click", () => deleteRun(b.dataset.delrun)));
  }

  /* ---- dashboard stat (Manager+ only — sensitive) ------------------------ */
  Dashboard.addStat(() => {
    const prev = { p: state.period, cf: state.customFrom, ct: state.customTo };
    state.period = "current-fortnight";
    const total = compute(periodInfo()).totalGross;
    state.period = prev.p; state.customFrom = prev.cf; state.customTo = prev.ct;
    return { label: "Payroll this fortnight", value: Fmt.gbp(total), note: "gross · est.", route: "payroll" };
  }, "Manager");

  Modules.register({
    id: "payroll", label: "Payroll", title: "Payroll", minRole: "Manager",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="5" width="20" height="14" rx="2"/><circle cx="12" cy="12" r="3"/><path d="M6 9v6M18 9v6"/></svg>',
    render,
  });
})();
