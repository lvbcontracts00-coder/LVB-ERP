/* ==========================================================================
   modules/supplierInvoices.js — Supplier Invoice Register (Phase 7)

   The accountant's authoritative record of supplier bills — the workflow that
   replaces the manual spreadsheet. SEPARATE from client Invoices (collection
   "invoices") and from Purchase Orders (commitments). One row = one bill.

   Store collection "supplierInvoices". Attachments (PDF/image) are kept out of
   the main collection under "supplierInvoiceFile:<id>" to isolate large blobs
   (localStorage is ~5MB total — fine for recent invoices, not an archive).

   Record: { id, supplierId, number, date, dueDate, siteId, description,
             net, vat, gross, status (Draft|Unpaid|Paid), paymentDate,
             notes, hasFile, fileName, fileMime }

   COST INTEGRATION — committed invoices (status Unpaid/Paid, gross amount)
   flow automatically through Finance.supplierInvoiceCost() → projectCost()
   → project costs, profitability and the accountant dashboard. This file owns
   the register UI plus the weekly / fortnight / outstanding reports and the
   per-supplier spend dashboard. Manager+ to edit (financial data).
   ========================================================================== */
(() => {
  "use strict";
  const COL = "supplierInvoices";
  const FILE = (id) => "supplierInvoiceFile:" + id;
  const STATUSES = ["Draft", "Unpaid", "Paid"];
  const STATUS_BADGE = { Draft: "muted", Unpaid: "warn", Paid: "ok" };
  const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
  const canEdit = () => Auth.can("Manager");

  const supplierName = (id) => id ? ((Store.find("suppliers", id) || {}).name || "Unknown supplier") : "—";
  const siteName = (id) => id ? ((Store.find("sites", id) || {}).name || "Unknown") : "—";
  /** Counts as a real cost (excludes Draft, which is not yet committed). */
  const committed = (s) => s.status === "Unpaid" || s.status === "Paid";
  const inR = (date, f, t) => Period.inRange((date || "").slice(0, 10), f, t);
  const today = () => new Date(Fmt.todayISO());
  const daysSince = (iso) => { if (!iso) return 0; const d = new Date(iso); return isNaN(d) ? 0 : Math.max(0, Math.floor((today() - d) / 86400000)); };
  const sumGross = (list) => r2(list.reduce((s, x) => s + (Number(x.gross) || 0), 0));

  /* ---- module view state (reset to register on each nav entry) ----------- */
  const st = {
    tab: "register",
    supplierFilter: "all", statusFilter: "all", periodFilter: "all",
    weekOffset: 0, fnOffset: 0,
  };
  // Deep-link intents consumed once on the next render (set by openers below,
  // e.g. the accountant dashboard quick actions).
  let pendingTab = null, pendingForm = false;

  /* ==========================================================================
     ENTRY FORM
     ========================================================================== */
  function supplierOptions(sel) {
    return Store.all("suppliers")
      .map((s) => `<option value="${s.id}"${s.id === sel ? " selected" : ""}>${esc(s.name)}</option>`).join("");
  }
  function siteOptions(sel) {
    return `<option value="">— none —</option>` +
      Store.all("sites").map((s) => `<option value="${s.id}"${s.id === sel ? " selected" : ""}>${esc(s.name)}</option>`).join("");
  }
  function statusOptions(sel) {
    return STATUSES.map((s) => `<option value="${s}"${s === sel ? " selected" : ""}>${s}</option>`).join("");
  }
  const due30 = () => Period.isoOf(Period.addDays(new Date(), 30));

  function openForm(existing) {
    if (!Store.all("suppliers").length) { UI.toast("Add a supplier first", "danger"); Router.navigate("suppliers"); return; }

    let pendingFile = null, pendingName = "", pendingMime = "";
    let removeFile = false;
    const hasExisting = existing && existing.hasFile;

    UI.modal({
      title: existing ? "Edit supplier invoice" : "Add supplier invoice", size: "lg",
      saveLabel: existing ? "Save changes" : "Add invoice",
      bodyHTML: `
        <div class="form-grid">
          <div class="field"><label class="field__label">Supplier *</label>
            <select class="input" id="si-supplier">${supplierOptions(existing && existing.supplierId)}</select></div>
          <div class="field"><label class="field__label">Invoice number *</label>
            <input class="input" id="si-number" value="${esc((existing && existing.number) || "")}" placeholder="e.g. INV-10482"></div>
          <div class="field"><label class="field__label">Invoice date *</label>
            <input class="input" id="si-date" type="date" value="${esc((existing && existing.date) || Fmt.todayISO())}"></div>
          <div class="field"><label class="field__label">Due date</label>
            <input class="input" id="si-due" type="date" value="${esc((existing && existing.dueDate) || due30())}"></div>
          <div class="field"><label class="field__label">Project / site</label>
            <select class="input" id="si-site">${siteOptions(existing && existing.siteId)}</select></div>
          <div class="field"><label class="field__label">Status</label>
            <select class="input" id="si-status">${statusOptions((existing && existing.status) || "Unpaid")}</select></div>
          <div class="field"><label class="field__label">Net amount (£) *</label>
            <input class="input" id="si-net" type="number" min="0" step="0.01" value="${(existing && existing.net) ?? ""}" placeholder="0.00"></div>
          <div class="field"><label class="field__label">VAT amount (£)</label>
            <input class="input" id="si-vat" type="number" min="0" step="0.01" value="${(existing && existing.vat) ?? ""}" placeholder="auto 20%"></div>
          <div class="field"><label class="field__label">Gross amount (£)</label>
            <input class="input" id="si-gross" type="number" step="0.01" value="${(existing && existing.gross) ?? ""}" readonly></div>
          <div class="field" id="si-pdate-wrap"><label class="field__label">Payment date</label>
            <input class="input" id="si-pdate" type="date" value="${esc((existing && existing.paymentDate) || "")}"></div>
          <div class="field span-2"><label class="field__label">Description</label>
            <input class="input" id="si-desc" value="${esc((existing && existing.description) || "")}" placeholder="e.g. Plasterboard & fixings — first fix"></div>
          <div class="field span-2"><label class="field__label">Notes</label>
            <textarea class="input" id="si-notes" rows="2" placeholder="Account ref, payment terms…">${esc((existing && existing.notes) || "")}</textarea></div>
          <div class="field span-2"><label class="field__label">Attachment (PDF or image)</label>
            <div class="receipt-input">
              <input type="file" id="si-file" accept="application/pdf,image/*">
              <div id="si-file-state" class="hint">${hasExisting ? `Current: ${esc(existing.fileName || "attachment")}` : "No attachment."}</div>
              <img id="si-file-prev" class="receipt-prev" alt="" hidden>
              <button type="button" class="btn btn--sm btn--danger" id="si-file-clear"${hasExisting ? "" : " hidden"}>Remove attachment</button>
            </div></div>
        </div>`,
      onSave: (r) => {
        const supplierId = r.querySelector("#si-supplier").value;
        const number = r.querySelector("#si-number").value.trim();
        const net = parseFloat(r.querySelector("#si-net").value);
        if (!supplierId) { UI.toast("Pick a supplier", "danger"); return false; }
        if (!number) { UI.toast("Invoice number is required", "danger"); return false; }
        if (isNaN(net) || net < 0) { UI.toast("Enter a valid net amount", "danger"); return false; }
        const vat = r2(parseFloat(r.querySelector("#si-vat").value) || 0);
        const grossInput = parseFloat(r.querySelector("#si-gross").value);
        const gross = r2(!isNaN(grossInput) && grossInput > 0 ? grossInput : r2(net) + vat);
        const status = r.querySelector("#si-status").value;
        const data = {
          supplierId, number,
          date: r.querySelector("#si-date").value,
          dueDate: r.querySelector("#si-due").value,
          siteId: r.querySelector("#si-site").value,
          description: r.querySelector("#si-desc").value.trim(),
          net: r2(net), vat, gross, status,
          paymentDate: status === "Paid" ? (r.querySelector("#si-pdate").value || Fmt.todayISO()) : "",
          notes: r.querySelector("#si-notes").value.trim(),
        };

        // persist record first (small), then handle the attachment blob
        let rec;
        if (existing) { rec = Store.update(COL, existing.id, data); }
        else { rec = Store.insert(COL, { ...data, hasFile: false, fileName: "", fileMime: "" }); }

        if (pendingFile) {
          const ok = Store.write(FILE(rec.id), pendingFile);
          if (!ok) UI.toast("Invoice saved, but the attachment was too large for local storage", "danger");
          Store.update(COL, rec.id, { hasFile: ok, fileName: ok ? pendingName : "", fileMime: ok ? pendingMime : "" });
        } else if (removeFile && hasExisting) {
          Store.remove(FILE(rec.id)); Store.update(COL, rec.id, { hasFile: false, fileName: "", fileMime: "" });
        }

        UI.toast(existing ? "Invoice updated" : "Invoice added", "ok");
        render(document.getElementById("view-root"));
      },
    });

    /* ---- live wiring inside the modal ---- */
    const mr = document.getElementById("modal-root");
    const $ = (sel) => mr.querySelector(sel);
    const netEl = $("#si-net"), vatEl = $("#si-vat"), grossEl = $("#si-gross");
    let vatTouched = !!(existing && (existing.vat ?? "") !== "");

    const recalcGross = () => {
      const net = parseFloat(netEl.value) || 0;
      const vat = parseFloat(vatEl.value) || 0;
      grossEl.value = r2(net + vat).toFixed(2);
    };
    netEl.addEventListener("input", () => {
      if (!vatTouched) { const net = parseFloat(netEl.value) || 0; vatEl.value = net ? r2(net * 0.20).toFixed(2) : ""; }
      recalcGross();
    });
    vatEl.addEventListener("input", () => { vatTouched = true; recalcGross(); });

    const statusEl = $("#si-status"), pdWrap = $("#si-pdate-wrap"), pdEl = $("#si-pdate");
    const togglePD = () => {
      const paid = statusEl.value === "Paid";
      pdWrap.style.opacity = paid ? "1" : "0.45";
      pdEl.disabled = !paid;
      if (paid && !pdEl.value) pdEl.value = Fmt.todayISO();
    };
    statusEl.addEventListener("change", togglePD); togglePD();

    $("#si-file").addEventListener("change", async (e) => {
      const f = e.target.files[0]; if (!f) return;
      try {
        pendingName = f.name || "attachment"; pendingMime = f.type || "";
        const prev = $("#si-file-prev");
        if ((f.type || "").startsWith("image/")) {
          pendingFile = await Util.compressImage(f, { max: 1400, quality: 0.6 });
          prev.src = pendingFile; prev.hidden = false;
        } else {
          pendingFile = await Util.readDataURL(f); // PDF (or other) stored as-is
          prev.hidden = true; prev.src = "";
        }
        removeFile = false;
        $("#si-file-state").textContent = `Ready: ${pendingName} (${Math.round(pendingFile.length / 1024)} KB)`;
        $("#si-file-clear").hidden = false;
      } catch { UI.toast("Could not read that file", "danger"); }
    });
    $("#si-file-clear").addEventListener("click", () => {
      pendingFile = null; removeFile = true; pendingName = ""; pendingMime = "";
      const prev = $("#si-file-prev"); prev.hidden = true; prev.src = "";
      $("#si-file").value = "";
      $("#si-file-state").textContent = "Attachment will be removed on save.";
      $("#si-file-clear").hidden = true;
    });
  }

  function viewFile(rec) {
    const data = Store.read(FILE(rec.id));
    if (!data) { UI.toast("Attachment not found", "danger"); return; }
    const isPdf = (rec.fileMime || "").includes("pdf") || /^data:application\/pdf/.test(data);
    const body = isPdf
      ? `<iframe src="${data}" style="width:100%;height:70vh;border:0;border-radius:8px;background:#fff"></iframe>`
      : `<img src="${data}" class="receipt-full" alt="Invoice attachment">`;
    UI.modal({ title: rec.fileName || "Attachment", size: "lg", bodyHTML: body });
  }

  function markPaid(rec) {
    Store.update(COL, rec.id, { status: "Paid", paymentDate: Fmt.todayISO() });
    UI.toast("Marked paid", "ok");
    render(document.getElementById("view-root"));
  }
  function remove(rec) {
    UI.confirm(`Delete invoice ${rec.number || ""} from ${supplierName(rec.supplierId)}? Its attachment will also be removed.`, () => {
      Store.remove(FILE(rec.id)); Store.destroy(COL, rec.id);
      UI.toast("Invoice deleted", "info");
      render(document.getElementById("view-root"));
    });
  }

  /* ==========================================================================
     TAB 1 — REGISTER (list + filters + entry)
     ========================================================================== */
  function periodRange() {
    if (st.periodFilter === "this-week") return Period.weekRange(0);
    if (st.periodFilter === "this-fortnight") return Period.payPeriodRange(0);
    if (st.periodFilter === "this-month") return Period.monthRange(0);
    return { from: null, to: null };
  }

  function renderRegister(root) {
    const { from, to } = periodRange();
    const all = Store.all(COL);
    const rows = all
      .filter((s) => st.supplierFilter === "all" || s.supplierId === st.supplierFilter)
      .filter((s) => st.statusFilter === "all" || s.status === st.statusFilter)
      .filter((s) => inR(s.date, from, to))
      .sort((a, b) => (b.date || "").localeCompare(a.date || ""));

    const net = r2(rows.reduce((s, x) => s + (Number(x.net) || 0), 0));
    const vat = r2(rows.reduce((s, x) => s + (Number(x.vat) || 0), 0));
    const gross = sumGross(rows);
    const outstanding = sumGross(all.filter((s) => s.status === "Unpaid"));

    const supplierFilterOpts = `<option value="all">All suppliers</option>` +
      Store.all("suppliers").map((s) => `<option value="${s.id}"${st.supplierFilter === s.id ? " selected" : ""}>${esc(s.name)}</option>`).join("");
    const statusFilterOpts = `<option value="all">All statuses</option>` +
      STATUSES.map((s) => `<option value="${s}"${st.statusFilter === s ? " selected" : ""}>${s}</option>`).join("");
    const periodFilterOpts = [["all", "All dates"], ["this-week", "This week"], ["this-fortnight", "This pay period"], ["this-month", "This month"]]
      .map(([v, l]) => `<option value="${v}"${st.periodFilter === v ? " selected" : ""}>${l}</option>`).join("");

    const colspanLead = 5; // Date, Supplier, Invoice #, Project, Due

    return `
      <div class="toolbar">
        <div class="toolbar__left filterbar">
          <select class="input" id="si-fsupplier">${supplierFilterOpts}</select>
          <select class="input" id="si-fstatus">${statusFilterOpts}</select>
          <select class="input" id="si-fperiod">${periodFilterOpts}</select>
          <span class="muted-count num">${Fmt.gbp(outstanding)} outstanding</span>
        </div>
        ${canEdit() ? `<button class="btn btn--primary" id="si-add">＋ Add invoice</button>` : ""}
      </div>
      ${rows.length ? `
        <div class="table-wrap"><table class="table">
          <thead><tr>
            <th>Date</th><th>Supplier</th><th>Invoice #</th><th>Project</th><th>Due</th>
            <th class="ta-r">Net</th><th class="ta-r">VAT</th><th class="ta-r">Gross</th>
            <th>Status</th><th>File</th>${canEdit() ? `<th class="ta-r">Actions</th>` : ""}
          </tr></thead>
          <tbody>${rows.map((s) => `
            <tr>
              <td class="num">${Fmt.date(s.date)}</td>
              <td><strong>${esc(supplierName(s.supplierId))}</strong></td>
              <td>${esc(s.number || "—")}</td>
              <td>${esc(siteName(s.siteId))}</td>
              <td class="num">${s.dueDate ? Fmt.date(s.dueDate) : "—"}</td>
              <td class="ta-r num">${Fmt.gbp(s.net)}</td>
              <td class="ta-r num">${Fmt.gbp(s.vat)}</td>
              <td class="ta-r num"><strong>${Fmt.gbp(s.gross)}</strong></td>
              <td><span class="badge badge--${STATUS_BADGE[s.status] || "muted"}">${esc(s.status)}</span>${s.status === "Paid" && s.paymentDate ? `<div class="muted-count num">${Fmt.dayMon(s.paymentDate)}</div>` : ""}</td>
              <td>${s.hasFile ? `<button class="btn btn--sm" data-file="${s.id}">📎 View</button>` : `<span class="muted-count">—</span>`}</td>
              ${canEdit() ? `<td class="ta-r nowrap">
                ${s.status !== "Paid" ? `<button class="btn btn--sm" data-paid="${s.id}">Mark paid</button>` : ""}
                <button class="btn btn--sm" data-edit="${s.id}">Edit</button>
                <button class="btn btn--sm btn--danger" data-del="${s.id}">Del</button></td>` : ""}
            </tr>`).join("")}</tbody>
          <tfoot><tr class="totals">
            <td colspan="${colspanLead}">${rows.length} invoice${rows.length === 1 ? "" : "s"}</td>
            <td class="ta-r num">${Fmt.gbp(net)}</td>
            <td class="ta-r num">${Fmt.gbp(vat)}</td>
            <td class="ta-r num">${Fmt.gbp(gross)}</td>
            <td colspan="${canEdit() ? 3 : 2}"></td>
          </tr></tfoot>
        </table></div>`
      : `<div class="panel"><div class="panel__body"><div class="empty">
          <svg class="empty__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M6 2h9l5 5v15H6z"/><path d="M14 2v6h6"/><path d="M9 13h7M9 17h7"/></svg>
          <div class="empty__title">No supplier invoices ${all.length ? "in this view" : "yet"}</div>
          <div class="empty__text">${canEdit() ? "Add a supplier invoice to start tracking supplier costs." : "Ask a manager to enter supplier invoices."}</div>
        </div></div></div>`}
    `;
  }

  function wireRegister(root) {
    const fs = root.querySelector("#si-fsupplier"); if (fs) fs.addEventListener("change", (e) => { st.supplierFilter = e.target.value; render(root); });
    const ft = root.querySelector("#si-fstatus"); if (ft) ft.addEventListener("change", (e) => { st.statusFilter = e.target.value; render(root); });
    const fp = root.querySelector("#si-fperiod"); if (fp) fp.addEventListener("change", (e) => { st.periodFilter = e.target.value; render(root); });
    const add = root.querySelector("#si-add"); if (add) add.addEventListener("click", () => openForm(null));
    root.querySelectorAll("[data-file]").forEach((b) => b.addEventListener("click", () => viewFile(Store.find(COL, b.dataset.file))));
    root.querySelectorAll("[data-paid]").forEach((b) => b.addEventListener("click", () => markPaid(Store.find(COL, b.dataset.paid))));
    root.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => openForm(Store.find(COL, b.dataset.edit))));
    root.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => remove(Store.find(COL, b.dataset.del))));
  }

  /* ==========================================================================
     TAB 2 — BY SUPPLIER (per-supplier spend dashboard)
     ========================================================================== */
  function supplierStats() {
    const wk = Period.weekRange(0), fn = Period.payPeriodRange(0), mo = Period.monthRange(0);
    const all = Store.all(COL);
    const ids = new Set(all.map((s) => s.supplierId));
    const rows = [...ids].map((id) => {
      const mine = all.filter((s) => s.supplierId === id);
      const com = mine.filter(committed);
      return {
        id, name: supplierName(id),
        week: sumGross(com.filter((s) => inR(s.date, wk.from, wk.to))),
        fortnight: sumGross(com.filter((s) => inR(s.date, fn.from, fn.to))),
        month: sumGross(com.filter((s) => inR(s.date, mo.from, mo.to))),
        outstanding: sumGross(mine.filter((s) => s.status === "Unpaid")),
        count: mine.length,
      };
    }).sort((a, b) => b.month - a.month || a.name.localeCompare(b.name));
    return { rows, wk, fn, mo };
  }

  function renderBySupplier() {
    const { rows, wk, fn, mo } = supplierStats();
    if (!rows.length) {
      return `<div class="panel"><div class="panel__body"><div class="empty">
        <div class="empty__title">No supplier spend yet</div>
        <div class="empty__text">Enter supplier invoices to see per-supplier spend.</div>
      </div></div></div>`;
    }
    const T = {
      week: r2(rows.reduce((s, r) => s + r.week, 0)),
      fortnight: r2(rows.reduce((s, r) => s + r.fortnight, 0)),
      month: r2(rows.reduce((s, r) => s + r.month, 0)),
      outstanding: r2(rows.reduce((s, r) => s + r.outstanding, 0)),
      count: rows.reduce((s, r) => s + r.count, 0),
    };
    return `
      <div class="panel">
        <div class="panel__head"><span class="panel__title">Spend by supplier</span>
          <span class="muted-count num">Week ${Period.isoWeek(new Date(wk.from))} · ${Fmt.dmy(fn.from)}–${Fmt.dmy(fn.to)} · ${esc(mo.label)}</span></div>
        <div class="panel__body">
          <div class="table-wrap"><table class="table">
            <thead><tr><th>Supplier</th>
              <th class="ta-r">This week</th><th class="ta-r">This fortnight</th><th class="ta-r">This month</th>
              <th class="ta-r">Outstanding</th><th class="ta-r">Invoices</th></tr></thead>
            <tbody>${rows.map((r) => `
              <tr>
                <td><strong>${esc(r.name)}</strong></td>
                <td class="ta-r num">${Fmt.gbp(r.week)}</td>
                <td class="ta-r num">${Fmt.gbp(r.fortnight)}</td>
                <td class="ta-r num">${Fmt.gbp(r.month)}</td>
                <td class="ta-r num">${r.outstanding > 0 ? `<span style="color:var(--danger,#dc2626)">${Fmt.gbp(r.outstanding)}</span>` : Fmt.gbp(0)}</td>
                <td class="ta-r num">${r.count}</td>
              </tr>`).join("")}</tbody>
            <tfoot><tr class="totals">
              <td>Total (${rows.length})</td>
              <td class="ta-r num">${Fmt.gbp(T.week)}</td>
              <td class="ta-r num">${Fmt.gbp(T.fortnight)}</td>
              <td class="ta-r num">${Fmt.gbp(T.month)}</td>
              <td class="ta-r num">${Fmt.gbp(T.outstanding)}</td>
              <td class="ta-r num">${T.count}</td>
            </tr></tfoot>
          </table></div>
          <p class="hint hint--block">Spend = invoices marked Unpaid or Paid, by invoice date (Draft excluded). Outstanding = unpaid gross, all dates.</p>
        </div>
      </div>`;
  }

  /* ==========================================================================
     TAB 3 — REPORTS (weekly · fortnight · outstanding)
     ========================================================================== */
  function bySupplierFor(list) {
    const m = new Map();
    list.forEach((s) => {
      const name = supplierName(s.supplierId);
      m.set(name, r2((m.get(name) || 0) + (Number(s.gross) || 0)));
    });
    return [...m.entries()].map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  }

  function periodReportData(range) {
    const list = Store.all(COL).filter((s) => committed(s) && inR(s.date, range.from, range.to));
    const suppliers = bySupplierFor(list);
    return { suppliers, total: r2(suppliers.reduce((s, x) => s + x.value, 0)), count: list.length };
  }

  function outstandingData() {
    const list = Store.all(COL).filter((s) => s.status === "Unpaid")
      .map((s) => ({
        supplier: supplierName(s.supplierId), number: s.number || "—",
        due: s.dueDate || "", date: s.date || "", gross: Number(s.gross) || 0,
        days: daysSince(s.date),
      }))
      .sort((a, b) => (a.date || "").localeCompare(b.date || "")); // oldest first
    return { rows: list, total: r2(list.reduce((s, x) => s + x.gross, 0)) };
  }

  function renderReports() {
    const wk = Period.weekRange(st.weekOffset);
    const fn = Period.payPeriodRange(st.fnOffset);
    const wkD = periodReportData(wk);
    const fnD = periodReportData(fn);
    const out = outstandingData();

    const offsetOpts = (sel, kind) => {
      const labels = kind === "week"
        ? [[0, "This week"], [-1, "Last week"], [-2, "2 weeks ago"], [-3, "3 weeks ago"]]
        : [[0, "This pay period"], [-1, "Last pay period"], [-2, "2 periods ago"], [-3, "3 periods ago"]];
      return labels.map(([v, l]) => `<option value="${v}"${sel === v ? " selected" : ""}>${l}</option>`).join("");
    };

    const periodTable = (d, emptyLabel) => d.suppliers.length ? `
      <div class="table-wrap"><table class="table table--tight">
        <thead><tr><th>Supplier</th><th class="ta-r">Cost</th></tr></thead>
        <tbody>${d.suppliers.map((s) => `<tr><td>${esc(s.name)}</td><td class="ta-r num">${Fmt.gbp(s.value)}</td></tr>`).join("")}</tbody>
        <tfoot><tr class="totals"><td>Total supplier cost</td><td class="ta-r num">${Fmt.gbp(d.total)}</td></tr></tfoot>
      </table></div>`
      : `<p class="hint hint--block">${esc(emptyLabel)}</p>`;

    return `
      <!-- WEEKLY -->
      <div class="panel">
        <div class="panel__head"><span class="panel__title">Weekly supplier cost report</span>
          <span class="filterbar"><select class="input input--sm" id="si-week">${offsetOpts(st.weekOffset, "week")}</select>
          <button class="btn btn--sm" id="si-week-print">🖨 Print</button></span></div>
        <div class="panel__body">
          <div class="muted-count num" style="margin-bottom:10px">${esc(wk.label)}</div>
          ${periodTable(wkD, "No supplier cost in this week.")}
        </div>
      </div>

      <!-- FORTNIGHT -->
      <div class="panel">
        <div class="panel__head"><span class="panel__title">Payroll period supplier report</span>
          <span class="filterbar"><select class="input input--sm" id="si-fn">${offsetOpts(st.fnOffset, "fn")}</select>
          <button class="btn btn--sm" id="si-fn-print">🖨 Print</button></span></div>
        <div class="panel__body">
          <div class="muted-count num" style="margin-bottom:10px">${Fmt.dmy(fn.from)} – ${Fmt.dmy(fn.to)}</div>
          ${periodTable(fnD, "No supplier cost in this pay period.")}
        </div>
      </div>

      <!-- OUTSTANDING -->
      <div class="panel">
        <div class="panel__head"><span class="panel__title">Outstanding supplier invoices</span>
          <span class="filterbar"><span class="muted-count num">${Fmt.gbp(out.total)} total</span>
          <button class="btn btn--sm" id="si-out-print">🖨 Print</button></span></div>
        <div class="panel__body">
          ${out.rows.length ? `
          <div class="table-wrap"><table class="table">
            <thead><tr><th>Supplier</th><th>Invoice #</th><th>Due date</th><th class="ta-r">Amount</th><th class="ta-r">Days outstanding</th></tr></thead>
            <tbody>${out.rows.map((r) => `
              <tr>
                <td><strong>${esc(r.supplier)}</strong></td>
                <td>${esc(r.number)}</td>
                <td class="num">${r.due ? Fmt.date(r.due) : "—"}</td>
                <td class="ta-r num">${Fmt.gbp(r.gross)}</td>
                <td class="ta-r num">${r.days}d</td>
              </tr>`).join("")}</tbody>
            <tfoot><tr class="totals"><td colspan="3">Total outstanding supplier balance</td><td class="ta-r num">${Fmt.gbp(out.total)}</td><td></td></tr></tfoot>
          </table></div>`
          : `<p class="hint hint--block">Nothing outstanding — all supplier invoices are paid.</p>`}
        </div>
      </div>
    `;
  }

  function wireReports(root) {
    const wkSel = root.querySelector("#si-week"); if (wkSel) wkSel.addEventListener("change", (e) => { st.weekOffset = parseInt(e.target.value, 10) || 0; render(root); });
    const fnSel = root.querySelector("#si-fn"); if (fnSel) fnSel.addEventListener("change", (e) => { st.fnOffset = parseInt(e.target.value, 10) || 0; render(root); });
    const wp = root.querySelector("#si-week-print"); if (wp) wp.addEventListener("click", () => printPeriodReport("week"));
    const fp = root.querySelector("#si-fn-print"); if (fp) fp.addEventListener("click", () => printPeriodReport("fortnight"));
    const op = root.querySelector("#si-out-print"); if (op) op.addEventListener("click", printOutstandingReport);
  }

  /* ---- printable reports (via shared print pipeline) --------------------- */
  const coName = () => (Commercial.Company.get && Commercial.Company.get().name) || "Company";

  function printPeriodReport(kind) {
    const range = kind === "week" ? Period.weekRange(st.weekOffset) : Period.payPeriodRange(st.fnOffset);
    const d = periodReportData(range);
    if (!d.suppliers.length) { UI.toast("No supplier cost in this period", "danger"); return; }
    const title = kind === "week" ? `Weekly supplier cost — ${range.label}` : `Supplier cost — pay period ${Fmt.dmy(range.from)} – ${Fmt.dmy(range.to)}`;
    const body = d.suppliers.map((s) => `<tr><td>${esc(s.name)}</td><td class="r">${Fmt.gbp(s.value)}</td></tr>`).join("");
    const html = `
      <h1>${esc(title)}</h1>
      <div class="muted">${esc(coName())} · ${Fmt.date(range.from)} – ${Fmt.date(range.to)} · generated ${Fmt.date(Fmt.todayISO())} by ${esc(Auth.current().name)}</div>
      <table><thead><tr><th>Supplier</th><th class="r">Supplier cost</th></tr></thead>
      <tbody>${body}</tbody>
      <tfoot><tr><td>Total supplier cost</td><td class="r">${Fmt.gbp(d.total)}</td></tr></tfoot></table>
      <p class="muted">Includes supplier invoices marked Unpaid or Paid, by invoice date. Draft invoices excluded. Gross (incl. VAT).</p>`;
    Util.printDocument(title, html);
  }

  function printOutstandingReport() {
    const out = outstandingData();
    if (!out.rows.length) { UI.toast("Nothing outstanding", "info"); return; }
    const body = out.rows.map((r) => `<tr><td>${esc(r.supplier)}</td><td>${esc(r.number)}</td><td>${r.due ? Fmt.date(r.due) : "—"}</td><td class="r">${Fmt.gbp(r.gross)}</td><td class="r">${r.days}d</td></tr>`).join("");
    const html = `
      <h1>Outstanding supplier invoices</h1>
      <div class="muted">${esc(coName())} · as at ${Fmt.date(Fmt.todayISO())} · generated by ${esc(Auth.current().name)}</div>
      <table><thead><tr><th>Supplier</th><th>Invoice #</th><th>Due date</th><th class="r">Amount</th><th class="r">Days outstanding</th></tr></thead>
      <tbody>${body}</tbody>
      <tfoot><tr><td colspan="3">Total outstanding supplier balance</td><td class="r">${Fmt.gbp(out.total)}</td><td></td></tr></tfoot></table>
      <p class="muted">Unpaid supplier invoices only, oldest first. Days outstanding = days since invoice date. Gross (incl. VAT).</p>`;
    Util.printDocument("Outstanding supplier invoices", html);
  }

  /* ==========================================================================
     RENDER (tabbed shell)
     ========================================================================== */
  function render(root) {
    if (!canEdit() && !Auth.can("Viewer")) { Views.forbidden(root, "Viewer"); return; }

    const tab = (id, label) => `<button class="btn btn--sm${st.tab === id ? " btn--primary" : ""}" data-tab="${id}">${label}</button>`;
    const body =
      st.tab === "by-supplier" ? renderBySupplier() :
      st.tab === "reports" ? renderReports() :
      renderRegister(root);

    root.innerHTML = `
      <div class="toolbar" style="margin-bottom:14px">
        <div class="toolbar__left filterbar">
          ${tab("register", "Invoices")}
          ${tab("by-supplier", "By supplier")}
          ${tab("reports", "Reports")}
        </div>
      </div>
      ${body}`;

    root.querySelectorAll("[data-tab]").forEach((b) => b.addEventListener("click", () => { st.tab = b.dataset.tab; render(root); }));
    if (st.tab === "register") wireRegister(root);
    else if (st.tab === "reports") wireReports(root);
  }

  /* ---- dashboard stat (standard dashboard) ------------------------------- */
  Dashboard.addStat(() => {
    const unpaid = Store.all(COL).filter((s) => s.status === "Unpaid");
    return { label: "Supplier invoices due", value: Fmt.gbp(sumGross(unpaid)), note: `${unpaid.length} unpaid`, route: "supplierInvoices" };
  }, "Manager");

  /* ---- registration ------------------------------------------------------ */
  Modules.register({
    id: "supplierInvoices", label: "Supplier Invoices", title: "Supplier Invoices", minRole: "Viewer",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2h9l5 5v15H6z"/><path d="M14 2v6h6"/><path d="M9 13h7M9 17h5"/></svg>',
    render: (root) => {
      st.tab = pendingTab || "register"; pendingTab = null;
      render(root);
      if (pendingForm) { pendingForm = false; openForm(null); }
    },
  });

  // Opener API for other screens (e.g. the accountant dashboard quick actions).
  // Sets a one-shot intent then routes here; the render above consumes it.
  window.SupplierInvoices = {
    openForm() { pendingForm = true; Router.navigate("supplierInvoices"); },
    openReports() { pendingTab = "reports"; Router.navigate("supplierInvoices"); },
  };
})();
