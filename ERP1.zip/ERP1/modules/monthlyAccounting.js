/* ==========================================================================
   modules/monthlyAccounting.js — Accounting & Reporting (Phase 7)
   A payroll-period (weekly/fortnight) workspace for the company accountant.
   Reads every existing ledger and presents period-filtered figures + reports,
   with one-click PDF and Excel (SpreadsheetML .xls) exports. Self-registers a
   route, a nav section ("Accounting") and a dashboard stat. Manager+ (financial).

   Architecture: adds NO new collections and changes no data shapes. It is a
   pure read/aggregate layer over: invoices, payments, supplierInvoices,
   timesheets+workers, expenses, cisStatements, skipHire, equipment, sites,
   suppliers, clients.

   DATA-MODEL NOTES (surfaced to the accountant so the numbers are trusted):
   • Supplier costs come from the SUPPLIER INVOICE REGISTER (collection
     "supplierInvoices"): committed = status Unpaid/Paid. Purchase orders are
     commitments only and are NOT counted here (no double-add).
   • CIS subcontractor statements carry no project, so they are reported at
     company level only (not allocated per project).
   • Vehicle running costs and retentions are not tracked in the data model,
     so those lines read £0.00 and are footnoted.
   • Cash-out timing uses each item's recorded date as a proxy where no
     explicit payment date exists.
   ========================================================================== */
(() => {
  "use strict";

  const Money = Commercial.Money;          // r2, line, subtotal, totals
  const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
  const OT = (Finance && Finance.OT) || 1.5;
  const COMPANY = () => (Commercial.Company.get().name || "Company");

  /* ---- period helpers ---------------------------------------------------- */
  const ymOf = (d) => (d || "").slice(0, 7);
  function monthRange(ym) {
    const [y, m] = String(ym).split("-").map(Number);
    const last = new Date(y, m, 0).getDate();
    return { from: `${ym}-01`, to: `${ym}-${String(last).padStart(2, "0")}` };
  }
  function addMonths(ym, delta) {
    const [y, m] = String(ym).split("-").map(Number);
    const d = new Date(y, (m - 1) + delta, 1);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
  }
  function monthLabel(ym) {
    const [y, m] = String(ym).split("-").map(Number);
    const d = new Date(y, m - 1, 1);
    return isNaN(d) ? ym : d.toLocaleDateString("en-GB", { month: "long", year: "numeric" });
  }
  const inR = (date, from, to) => Period.inRange((date || "").slice(0, 10), from, to);

  /* ---- per-record helpers (all null-safe) -------------------------------- */
  const docTotals = (d) => Money.totals((d && d.items) || [], d && d.vatRate);
  const isIssued = (i) => i && i.status !== "Draft";                   // revenue recognised when issued
  const poCounts = (p) => p && (p.status === "Ordered" || p.status === "Received");
  const siCounts = (s) => s && (s.status === "Unpaid" || s.status === "Paid"); // committed supplier invoices (AP register)
  const skipCounts = (k) => k && k.status !== "Cancelled";
  const workerRate = (id) => Number((Store.find("workers", id) || {}).rate) || 0;
  const siteName = (id) => id ? ((Store.find("sites", id) || {}).name || "Unknown") : "—";
  const supplierName = (id) => id ? ((Store.find("suppliers", id) || {}).name || "Unknown") : "—";
  const clientName = (id) => id ? ((Store.find("clients", id) || {}).name || "Unknown") : "—";
  const paidFor = (invId) => r2(Store.all("payments").filter((p) => p.invoiceId === invId).reduce((s, p) => s + (Number(p.amount) || 0), 0));

  /* ---- the figures engine ------------------------------------------------ *
     Returns every headline number for a [from,to] window. Outstanding
     balances are point-in-time (as at today) and ignore the window.        */
  function figures(from, to) {
    // Revenue (invoiced, ex-VAT) + VAT collected
    let revNet = 0, revGross = 0, vatOut = 0;
    Store.all("invoices").filter(isIssued).filter((i) => inR(i.date, from, to)).forEach((i) => {
      const t = docTotals(i); revNet += t.sub; revGross += t.total; vatOut += t.vat;
    });
    // Supplier invoices (the AP register) — committed (Unpaid/Paid) + input VAT.
    // Variable names kept (poNet/poGross/vatIn) so downstream P&L/VAT/cash/trend
    // are unchanged; they now mean supplier-invoice net/gross/VAT.
    let poNet = 0, poGross = 0, vatIn = 0;
    Store.all("supplierInvoices").filter(siCounts).filter((s) => inR(s.date, from, to)).forEach((s) => {
      poNet += Number(s.net) || 0; poGross += Number(s.gross) || 0; vatIn += Number(s.vat) || 0;
    });
    // Payroll (from timesheets × worker rate, OT premium)
    let payroll = 0;
    Store.all("timesheets").filter((t) => inR(t.date, from, to)).forEach((t) => {
      const rate = workerRate(t.workerId);
      payroll += (Number(t.hours) || 0) * rate + (Number(t.overtime) || 0) * rate * OT;
    });
    // Employee expenses
    const expenses = r2(Store.all("expenses").filter((e) => inR(e.date, from, to)).reduce((s, e) => s + (Number(e.amount) || 0), 0));
    // Subcontractors (CIS) — cost to company = gross
    let subGross = 0, subDeduction = 0;
    Store.all("cisStatements").filter((c) => inR(c.date, from, to)).forEach((c) => { subGross += Number(c.gross) || 0; subDeduction += Number(c.deduction) || 0; });
    // Skip hire / waste removal
    const skip = r2(Store.all("skipHire").filter(skipCounts).filter((k) => inR(k.hireDate, from, to)).reduce((s, k) => s + (Number(k.cost) || 0), 0));
    // Equipment capital purchases in the window
    const equipment = r2(Store.all("equipment").filter((e) => inR(e.purchaseDate, from, to)).reduce((s, e) => s + (Number(e.value) || 0), 0));
    // Client cash received
    const clientPayments = r2(Store.all("payments").filter((p) => inR(p.date, from, to)).reduce((s, p) => s + (Number(p.amount) || 0), 0));

    // direct vs indirect split for a construction P&L
    const directCost = r2(payroll + poNet + subGross + skip);
    const overheads = r2(expenses + equipment /* + vehicles(0) + other(0) */);
    const grossProfit = r2(revNet - directCost);
    const netProfit = r2(grossProfit - overheads);
    const margin = revNet ? r2((netProfit / revNet) * 100) : 0;

    return {
      from, to,
      revNet: r2(revNet), revGross: r2(revGross), vatOut: r2(vatOut),
      poNet: r2(poNet), poGross: r2(poGross), vatIn: r2(vatIn),
      payroll: r2(payroll), expenses, subGross: r2(subGross), subDeduction: r2(subDeduction),
      skip, equipment, vehicles: 0, other: 0, clientPayments,
      directCost, overheads, grossProfit, netProfit, margin,
      vatOwed: r2(vatOut - vatIn),
    };
  }

  /* ---- outstanding balances (as at today) -------------------------------- */
  function outstanding() {
    let client = 0, clientCount = 0;
    Store.all("invoices").filter((i) => i && i.status !== "Draft" && i.status !== "Paid").forEach((i) => {
      const due = docTotals(i).total - paidFor(i.id); if (due > 0) { client += due; clientCount += 1; }
    });
    let supplier = 0, supplierCount = 0;
    Store.all("supplierInvoices").filter((s) => s && s.status === "Unpaid").forEach((s) => { supplier += Number(s.gross) || 0; supplierCount += 1; });
    const reimb = r2(Store.all("expenses").filter((e) => !e.reimbursed).reduce((s, e) => s + (Number(e.amount) || 0), 0));
    return { client: r2(client), clientCount, supplier: r2(supplier), supplierCount, reimb, retentions: 0 };
  }

  /* ---- payroll rows by employee ------------------------------------------ */
  function payrollRows(from, to) {
    const by = new Map();
    Store.all("timesheets").filter((t) => inR(t.date, from, to)).forEach((t) => {
      const w = Store.find("workers", t.workerId); if (!w) return;
      const cur = by.get(w.id) || { name: w.name, trade: w.trade || "", rate: Number(w.rate) || 0, regHours: 0, otHours: 0, bonus: Number(w.bonus) || 0 };
      cur.regHours += Number(t.hours) || 0;
      cur.otHours += Number(t.overtime) || 0;
      by.set(w.id, cur);
    });
    return [...by.values()].map((l) => {
      const gross = r2(l.regHours * l.rate);
      const otPay = r2(l.otHours * l.rate * OT);
      const total = r2(gross + otPay + l.bonus);
      return { ...l, gross, otPay, total };
    }).sort((a, b) => b.total - a.total);
  }

  /* ---- supplier spend (from the supplier invoice register) --------------- */
  // Each supplier invoice is the supplier's bill. status Paid = settled,
  // Unpaid = outstanding. Total = billed (committed); Paid = settled;
  // Outstanding = unpaid. Marked paid from the Suppliers tab.
  function supplierRows(from, to) {
    const by = new Map();
    Store.all("supplierInvoices").filter(siCounts).filter((s) => inR(s.date, from, to)).forEach((s) => {
      const id = s.supplierId || "—";
      const cur = by.get(id) || { name: supplierName(s.supplierId), count: 0, total: 0, paid: 0, outstanding: 0 };
      const g = Number(s.gross) || 0;
      cur.count += 1; cur.total += g;
      if (s.status === "Paid") cur.paid += g; else cur.outstanding += g;
      by.set(id, cur);
    });
    return [...by.values()].map((s) => ({ ...s, total: r2(s.total), paid: r2(s.paid), outstanding: r2(s.outstanding) })).sort((a, b) => b.total - a.total);
  }

  /* ---- owned-stock material cost (stock issued to projects in window) ----- */
  // Distinct ledger from purchase orders (bought-for-job) — never double-counts.
  function stockIssued(from, to) {
    return r2(Store.all("stockMovements").filter((m) => m.type === "out" && inR(m.date, from, to))
      .reduce((s, m) => s + (Number(m.value) || 0), 0));
  }

  /* ---- labour cost by project for the window ----------------------------- */
  function labourByProject(from, to) {
    const by = new Map();
    Store.all("timesheets").filter((t) => inR(t.date, from, to)).forEach((t) => {
      const rate = workerRate(t.workerId);
      const reg = Number(t.hours) || 0, ot = Number(t.overtime) || 0;
      const key = t.siteId || "";
      const cur = by.get(key) || { name: t.siteId ? siteName(t.siteId) : "Unallocated", hours: 0, cost: 0 };
      cur.hours += reg + ot; cur.cost += reg * rate + ot * rate * OT;
      by.set(key, cur);
    });
    return [...by.values()].map((p) => ({ ...p, cost: r2(p.cost) })).sort((a, b) => b.cost - a.cost);
  }

  /* ---- outstanding supplier invoices (Unpaid, as at today) --------------- */
  // Listed oldest-due first. Due date = invoice due date, else invoice date.
  function outstandingSupplierInvoices() {
    return Store.all("supplierInvoices").filter((s) => s && s.status === "Unpaid").map((s) => ({
      id: s.id, number: s.number || "(no number)", supplier: supplierName(s.supplierId),
      due: s.dueDate || s.date || "", amount: r2(Number(s.gross) || 0),
    })).sort((a, b) => (a.due || "9999").localeCompare(b.due || "9999"));
  }
  function markPoPaid(id) {
    Store.update("supplierInvoices", id, { status: "Paid", paymentDate: Fmt.todayISO() });
    UI.toast("Supplier invoice marked paid", "ok");
    render(document.getElementById("view-root"));
  }

  /* ---- project (site) cost rows ------------------------------------------ */
  function projectRows(from, to) {
    return Store.all("sites").map((s) => {
      const rev = r2(Store.all("invoices").filter(isIssued).filter((i) => i.siteId === s.id && inR(i.date, from, to)).reduce((a, i) => a + docTotals(i).sub, 0));
      let labour = 0;
      Store.all("timesheets").filter((t) => t.siteId === s.id && inR(t.date, from, to)).forEach((t) => {
        const rate = workerRate(t.workerId);
        labour += (Number(t.hours) || 0) * rate + (Number(t.overtime) || 0) * rate * OT;
      });
      const materials = r2(Store.all("supplierInvoices").filter(siCounts).filter((inv) => inv.siteId === s.id && inR(inv.date, from, to)).reduce((a, inv) => a + (Number(inv.net) || 0), 0));
      const exp = r2(Store.all("expenses").filter((e) => e.siteId === s.id && inR(e.date, from, to)).reduce((a, e) => a + (Number(e.amount) || 0), 0));
      const profit = r2(rev - (r2(labour) + materials + exp));
      return { name: s.name, revenue: rev, labour: r2(labour), materials, expenses: exp, subs: 0, profit };
    }).filter((p) => p.revenue || p.labour || p.materials || p.expenses)
      .sort((a, b) => b.profit - a.profit);
  }

  /* ---- trailing period series for trend charts (week/fortnight cadence) --- */
  // Matches the accountant's cadence: trailing PAY PERIODS by default, or
  // trailing WEEKS when the selected period is weekly. No month dependency.
  function trailingSeries(n) {
    const useWeek = state.periodKind === "week";
    const out = [];
    for (let i = n - 1; i >= 0; i--) {
      const r = useWeek ? Period.weekRange(-i) : Period.payPeriodRange(-i);
      const f = figures(r.from, r.to);
      const label = useWeek ? ("W" + Period.isoWeek(new Date(r.from))) : Fmt.dayMon(r.from);
      out.push({ label, revenue: f.revNet, payroll: f.payroll, materials: f.poNet, profit: f.netProfit });
    }
    return out;
  }

  /* ======================================================================== *
     EXPORTS — PDF (print pipeline) and Excel (SpreadsheetML .xls workbook)
     ======================================================================== */
  const xmlEsc = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;" }[c]));
  const sheetName = (s) => String(s).replace(/[\\\/\?\*\[\]:]/g, " ").slice(0, 31);
  function xlsCell(v, header) {
    if (header) return `<Cell ss:StyleID="h"><Data ss:Type="String">${xmlEsc(v)}</Data></Cell>`;
    if (typeof v === "number" && isFinite(v)) return `<Cell><Data ss:Type="Number">${v}</Data></Cell>`;
    return `<Cell><Data ss:Type="String">${xmlEsc(v)}</Data></Cell>`;
  }
  function xlsSheet(name, rows) {
    const body = (rows || []).map((row, ri) => `<Row>${(row || []).map((c) => xlsCell(c, ri === 0)).join("")}</Row>`).join("");
    return `<Worksheet ss:Name="${xmlEsc(sheetName(name))}"><Table>${body}</Table></Worksheet>`;
  }
  function downloadXls(filename, sheets) {
    const xml = `<?xml version="1.0"?>\n<?mso-application progid="Excel.Sheet"?>\n` +
      `<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">` +
      `<Styles><Style ss:ID="h"><Font ss:Bold="1"/></Style></Styles>` +
      sheets.map((s) => xlsSheet(s.name, s.rows)).join("") +
      `</Workbook>`;
    Util.download(filename, xml, "application/vnd.ms-excel");
    UI.toast("Exported " + filename, "ok");
  }
  function pdf(title, bodyHTML) {
    Util.printDocument(title, `<h1>${xmlEsc(title)}</h1><div class="muted">${xmlEsc(COMPANY())} · period ${xmlEsc(state.label)} · generated ${Fmt.date(Fmt.todayISO())}</div>${bodyHTML}`);
  }
  const gbp = (n) => Fmt.gbp(n);
  const tRow = (cells, cls = "") => `<tr>${cells.map((c) => `<td class="${cls}">${c}</td>`).join("")}</tr>`;

  /* ---- export builders (return {sheets, html}) --------------------------- */
  function expPayroll() {
    const rows = payrollRows(state.from, state.to);
    const total = r2(rows.reduce((s, r) => s + r.total, 0));
    const head = ["Employee", "Trade", "Hours", "Rate", "Gross pay", "Overtime", "Bonuses", "Total pay"];
    const data = rows.map((r) => [r.name, r.trade, r2(r.regHours), r.rate, r.gross, r.otPay, r.bonus, r.total]);
    const sheets = [{ name: "Payroll " + state.label, rows: [head, ...data, ["TOTAL", "", "", "", "", "", "", total]] }];
    const html = `<h2>Payroll — ${xmlEsc(state.label)}</h2>
      <table><thead><tr><th>Employee</th><th>Trade</th><th class="r">Hours</th><th class="r">Rate</th><th class="r">Gross</th><th class="r">Overtime</th><th class="r">Bonuses</th><th class="r">Total</th></tr></thead>
      <tbody>${rows.map((r) => `<tr><td>${xmlEsc(r.name)}</td><td>${xmlEsc(r.trade)}</td><td class="r">${Fmt.hours(r.regHours)}</td><td class="r">${gbp(r.rate)}</td><td class="r">${gbp(r.gross)}</td><td class="r">${gbp(r.otPay)}</td><td class="r">${gbp(r.bonus)}</td><td class="r">${gbp(r.total)}</td></tr>`).join("")}</tbody>
      <tfoot><tr><td colspan="7">Total payroll</td><td class="r">${gbp(total)}</td></tr></tfoot></table>
      <p class="muted">Gross pay = hours × rate. Overtime at ×${OT}. Bonuses are read from a worker "bonus" field if present (not currently captured), so show £0.00 by default.</p>`;
    return { sheets, html, total };
  }
  function expPnL() {
    const f = figures(state.from, state.to);
    const sheets = [{ name: "P&L " + state.label, rows: [
      ["Profit & Loss", state.label],
      [],
      ["INCOME", ""],
      ["Project revenue (invoiced, net)", f.revNet],
      ["Client payments received (cash, memo)", f.clientPayments],
      [],
      ["DIRECT COSTS", ""],
      ["Payroll", f.payroll],
      ["Supplier invoices (net)", f.poNet],
      ["Subcontractors (CIS gross)", f.subGross],
      ["Skip hire", f.skip],
      ["Gross profit", f.grossProfit],
      [],
      ["OVERHEADS", ""],
      ["Employee expenses", f.expenses],
      ["Equipment purchases", f.equipment],
      ["Vehicles (not tracked)", f.vehicles],
      ["Other expenses", f.other],
      [],
      ["Net profit", f.netProfit],
      ["Profit margin %", f.margin],
    ] }];
    const L = (label, val, strong) => `<tr><td>${strong ? `<strong>${label}</strong>` : label}</td><td class="r">${strong ? `<strong>${gbp(val)}</strong>` : gbp(val)}</td></tr>`;
    const html = `<h2>Profit &amp; Loss — ${xmlEsc(state.label)}</h2>
      <table><tbody>
      <tr><td colspan="2"><strong>Income</strong></td></tr>
      ${L("Project revenue (invoiced, net)", f.revNet)}
      ${L("Client payments received (cash, memo)", f.clientPayments)}
      <tr><td colspan="2"><strong>Direct costs</strong></td></tr>
      ${L("Payroll", f.payroll)}
      ${L("Supplier invoices (net)", f.poNet)}
      ${L("Subcontractors (CIS gross)", f.subGross)}
      ${L("Skip hire", f.skip)}
      ${L("Gross profit", f.grossProfit, true)}
      <tr><td colspan="2"><strong>Overheads</strong></td></tr>
      ${L("Employee expenses", f.expenses)}
      ${L("Equipment purchases", f.equipment)}
      ${L("Vehicles (not tracked)", f.vehicles)}
      ${L("Other expenses", f.other)}
      ${L("Net profit", f.netProfit, true)}
      <tr><td><strong>Profit margin</strong></td><td class="r"><strong>${Fmt.hours(f.margin)}%</strong></td></tr>
      </tbody></table>
      <p class="muted">Supplier costs come from the supplier invoice register (Unpaid/Paid, net of VAT) — the actual supplier bills. Net profit is on a net-of-VAT, accruals basis.</p>`;
    return { sheets, html };
  }
  function expVAT() {
    const f = figures(state.from, state.to);
    const sheets = [{ name: "VAT " + state.label, rows: [
      ["VAT summary", state.label], [],
      ["Sales (net)", f.revNet],
      ["VAT collected (output)", f.vatOut],
      ["Purchases (net)", f.poNet],
      ["VAT paid (input)", f.vatIn],
      ["VAT owed to HMRC", f.vatOwed],
    ] }];
    const html = `<h2>VAT summary — ${xmlEsc(state.label)}</h2>
      <table><tbody>
      <tr><td>Sales (net)</td><td class="r">${gbp(f.revNet)}</td></tr>
      <tr><td>VAT collected (output)</td><td class="r">${gbp(f.vatOut)}</td></tr>
      <tr><td>Purchases (net)</td><td class="r">${gbp(f.poNet)}</td></tr>
      <tr><td>VAT paid (input)</td><td class="r">${gbp(f.vatIn)}</td></tr>
      <tr><td><strong>VAT owed to HMRC</strong></td><td class="r"><strong>${gbp(f.vatOwed)}</strong></td></tr>
      </tbody></table>
      <p class="muted">Output VAT from issued invoices; input VAT from supplier invoices (Unpaid/Paid). Confirm against your VAT scheme before filing.</p>`;
    return { sheets, html };
  }
  function expCash() {
    const f = figures(state.from, state.to);
    const out = [["Payroll", f.payroll], ["Supplier invoices", f.poGross], ["Employee expenses", f.expenses], ["Skip hire", f.skip], ["Subcontractors (CIS)", f.subGross], ["Vehicles (not tracked)", f.vehicles]];
    const totalOut = r2(out.reduce((s, [, v]) => s + v, 0));
    const net = r2(f.clientPayments - totalOut);
    const sheets = [{ name: "Cash flow " + state.label, rows: [
      ["Cash flow", state.label], [],
      ["MONEY IN", ""], ["Client payments", f.clientPayments], [],
      ["MONEY OUT", ""], ...out, ["Total money out", totalOut], [],
      ["Net cash flow", net],
    ] }];
    const html = `<h2>Cash flow — ${xmlEsc(state.label)}</h2>
      <table><tbody>
      <tr><td colspan="2"><strong>Money in</strong></td></tr>
      <tr><td>Client payments</td><td class="r">${gbp(f.clientPayments)}</td></tr>
      <tr><td colspan="2"><strong>Money out</strong></td></tr>
      ${out.map(([l, v]) => `<tr><td>${l}</td><td class="r">${gbp(v)}</td></tr>`).join("")}
      <tr><td>Total money out</td><td class="r">${gbp(totalOut)}</td></tr>
      <tr><td><strong>Net cash flow</strong></td><td class="r"><strong>${gbp(net)}</strong></td></tr>
      </tbody></table>
      <p class="muted">Indicative: outgoings use each item's recorded date as a proxy where no explicit payment date exists.</p>`;
    return { sheets, html, net };
  }

  /* ======================================================================== *
     CHARTS
     ======================================================================== */
  let charts = [], disposer = null;
  const destroyCharts = () => { charts.forEach((c) => { try { c.destroy(); } catch (e) {} }); charts = []; };
  const hasChart = () => typeof window.Chart !== "undefined";

  function drawCharts(root) {
    if (!hasChart()) return;
    const C = Util.themeColors(), tick = C.muted, grid = C.border;
    const base = { responsive: true, maintainAspectRatio: false, plugins: { legend: { labels: { color: C.text, boxWidth: 12 } } } };
    const axes = { scales: { x: { ticks: { color: tick }, grid: { color: grid } }, y: { ticks: { color: tick }, grid: { color: grid } } } };
    const s = trailingSeries(12);
    const line = (id, label, key, col) => { const el = root.querySelector(id); if (el) charts.push(new Chart(el, { type: "line", data: { labels: s.map((x) => x.label), datasets: [{ label, data: s.map((x) => x[key]), borderColor: col, backgroundColor: col, tension: .3, fill: false }] }, options: { ...base, ...axes } })); };
    line("#ma-rev", "Revenue", "revenue", C.ok);
    line("#ma-pay", "Payroll", "payroll", C.accent);
    line("#ma-mat", "Supplier spend", "materials", C.warn);
    line("#ma-prof", "Net profit", "profit", C.ok);

    const sup = supplierRows(state.from, state.to).slice(0, 8);
    const cSup = root.querySelector("#ma-sup");
    if (cSup && sup.length) charts.push(new Chart(cSup, { type: "doughnut", data: { labels: sup.map((x) => x.name), datasets: [{ data: sup.map((x) => x.total), backgroundColor: [C.accent, C.ok, C.warn, C.danger, C.muted, "#7c8a9c", "#b07bd6", "#3aa6a0"], borderColor: C.surface, borderWidth: 2 }] }, options: { ...base } }));

    const prj = projectRows(state.from, state.to).slice(0, 10);
    const cPrj = root.querySelector("#ma-prj");
    if (cPrj && prj.length) charts.push(new Chart(cPrj, { type: "bar", data: { labels: prj.map((x) => x.name), datasets: [{ label: "Profit", data: prj.map((x) => x.profit), backgroundColor: prj.map((x) => x.profit >= 0 ? C.ok : C.danger) }] }, options: { ...base, ...axes } }));
  }

  /* ======================================================================== *
     STATE + PERIOD RESOLUTION
     ======================================================================== */
  // Default to the CURRENT PAY PERIOD (fortnight) — the accountant works on a
  // 2-weekly cadence, so weekly/fortnight beats monthly as the landing view.
  const state = { preset: "this-fortnight", ym: ymOf(Fmt.todayISO()), from: "", to: "", label: "", tab: "overview", ymResolved: "", periodKind: "fortnight" };
  function resolvePeriod() {
    let from, to, label, ymResolved = "", periodKind = "custom", r;
    if (state.preset === "this-week") { r = Period.weekRange(0); periodKind = "week"; }
    else if (state.preset === "last-week") { r = Period.weekRange(-1); periodKind = "week"; }
    else if (state.preset === "this-fortnight") { r = Period.payPeriodRange(0); periodKind = "fortnight"; }
    else if (state.preset === "last-fortnight") { r = Period.payPeriodRange(-1); periodKind = "fortnight"; }
    else if (state.preset === "this-year") { r = Period.yearRange(0); periodKind = "year"; }
    if (r) { from = r.from; to = r.to; label = r.label; }
    else if (state.preset === "this-month") { ymResolved = ymOf(Fmt.todayISO()); ({ from, to } = monthRange(ymResolved)); label = monthLabel(ymResolved); periodKind = "month"; }
    else if (state.preset === "last-month") { ymResolved = addMonths(ymOf(Fmt.todayISO()), -1); ({ from, to } = monthRange(ymResolved)); label = monthLabel(ymResolved); periodKind = "month"; }
    else if (state.preset === "month") { ymResolved = state.ym || ymOf(Fmt.todayISO()); ({ from, to } = monthRange(ymResolved)); label = monthLabel(ymResolved); periodKind = "month"; }
    else { from = state.from || Fmt.todayISO(); to = state.to || Fmt.todayISO(); label = `${Fmt.date(from)} – ${Fmt.date(to)}`; periodKind = "custom"; }
    Object.assign(state, { from, to, label, ymResolved, periodKind });
  }

  /* ======================================================================== *
     RENDER
     ======================================================================== */
  const stat = (label, value, note) => `<div class="stat"><div class="stat__label">${esc(label)}</div><div class="stat__value num">${esc(value)}</div>${note ? `<div class="stat__note">${esc(note)}</div>` : ""}</div>`;

  const TABS = [["overview", "Overview"], ["pnl", "P&L"], ["payroll", "Payroll"], ["suppliers", "Suppliers"], ["projects", "Projects"], ["vat", "VAT"], ["cash", "Cash flow"], ["outstanding", "Outstanding"]];

  function periodBar() {
    const presetOpts = [
      ["this-week", "Current week"], ["last-week", "Previous week"],
      ["this-fortnight", "Current pay period (fortnight)"], ["last-fortnight", "Previous pay period"],
      ["this-month", "Current month"], ["last-month", "Previous month"],
      ["this-year", "This year"], ["month", "Choose month"], ["range", "Custom date range"],
    ].map(([v, l]) => `<option value="${v}"${state.preset === v ? " selected" : ""}>${l}</option>`).join("");
    const extra = state.preset === "month"
      ? `<input class="input" type="month" id="ma-month" value="${esc(state.ym)}">`
      : state.preset === "range"
        ? `<input class="input" type="date" id="ma-from" value="${esc(state.from)}"><span class="muted-count">to</span><input class="input" type="date" id="ma-to" value="${esc(state.to)}">`
        : "";
    return `
      <div class="toolbar">
        <div class="toolbar__left filterbar">
          <select class="input" id="ma-preset">${presetOpts}</select>
          ${extra}
          <span class="muted-count num">${esc(state.label)}</span>
        </div>
        <div class="filterbar">
          <button class="btn btn--sm" id="ma-pdf-all">Overview PDF</button>
        </div>
      </div>
      <div class="filterbar" style="flex-wrap:wrap;gap:6px;margin-bottom:14px">
        ${TABS.map(([id, l]) => `<button class="btn btn--sm${state.tab === id ? " btn--primary" : ""}" data-tab="${id}">${esc(l)}</button>`).join("")}
      </div>`;
  }

  function reportToolbar(idBase, withExcel) {
    return `<div class="toolbar"><div class="toolbar__left"><span class="muted-count">Period: ${esc(state.label)}</span></div>
      <div class="filterbar">
        <button class="btn btn--sm" data-x="${idBase}-pdf">Export PDF</button>
        ${withExcel ? `<button class="btn btn--sm" data-x="${idBase}-xls">Export Excel</button>` : `<button class="btn btn--sm" data-x="${idBase}-csv">Export CSV</button>`}
      </div></div>`;
  }

  function tabOverview() {
    const f = figures(state.from, state.to), o = outstanding();
    const lab = labourByProject(state.from, state.to);
    const labTotal = r2(lab.reduce((s, p) => s + p.cost, 0));
    const matStock = stockIssued(state.from, state.to);

    // The seven figures the accountant tracks every pay period.
    const headline = [
      stat("Payroll cost", gbp(f.payroll), "labour + overtime"),
      stat("Supplier costs", gbp(f.poGross), "supplier invoices, incl VAT"),
      stat("Material costs", gbp(matStock), "owned stock issued to jobs"),
      stat("Client payments", gbp(f.clientPayments), "cash received in period"),
      stat("Outstanding supplier invoices", gbp(o.supplier), `${o.supplierCount} open · as at today`),
      stat("Outstanding client invoices", gbp(o.client), `${o.clientCount} unpaid · as at today`),
    ].join("");

    const labourPanel = `<div class="panel">
      <div class="panel__head"><span class="panel__title">Labour cost by project</span><span class="muted-count num">${gbp(labTotal)}</span></div>
      <div class="panel__body">${lab.length ? `<div class="table-wrap"><table class="table table--tight">
        <thead><tr><th>Project</th><th class="ta-r">Hours</th><th class="ta-r">Labour cost</th></tr></thead>
        <tbody>${lab.map((p) => `<tr><td><strong>${esc(p.name)}</strong></td><td class="ta-r num">${Fmt.hours(p.hours)}</td><td class="ta-r num">${gbp(p.cost)}</td></tr>`).join("")}</tbody>
        <tfoot><tr class="totals"><td>${lab.length} project${lab.length === 1 ? "" : "s"}</td><td class="ta-r num">${Fmt.hours(lab.reduce((s, p) => s + p.hours, 0))}</td><td class="ta-r num">${gbp(labTotal)}</td></tr></tfoot>
      </table></div>` : emptyBox("No labour in this period", "Log timesheets to populate labour by project.")}</div></div>`;

    const secondary = [
      stat("Revenue (net)", gbp(f.revNet), "invoiced, ex-VAT"),
      stat("Net profit", gbp(f.netProfit), `${Fmt.hours(f.margin)}% margin`),
      stat("Employee expenses", gbp(f.expenses), "reimbursable"),
      stat("Subcontractors (CIS)", gbp(f.subGross), "gross"),
      stat("VAT collected", gbp(f.vatOut), "output VAT"),
      stat("VAT paid", gbp(f.vatIn), "input VAT"),
    ].join("");

    const chartBlock = hasChart() ? `
      <div class="panel__head" style="border:0;padding:18px 0 4px"><span class="panel__title">Trends (${state.periodKind === "week" ? "trailing 12 weeks" : "trailing 12 pay periods"})</span></div>
      <div class="panel-grid">
        <section class="panel"><div class="panel__head"><span class="panel__title">Revenue trend</span></div><div class="panel__body"><div style="position:relative;height:240px"><canvas id="ma-rev"></canvas></div></div></section>
        <section class="panel"><div class="panel__head"><span class="panel__title">Profit trend</span></div><div class="panel__body"><div style="position:relative;height:240px"><canvas id="ma-prof"></canvas></div></div></section>
        <section class="panel"><div class="panel__head"><span class="panel__title">Payroll trend</span></div><div class="panel__body"><div style="position:relative;height:240px"><canvas id="ma-pay"></canvas></div></div></section>
        <section class="panel"><div class="panel__head"><span class="panel__title">Supplier costs</span></div><div class="panel__body"><div style="position:relative;height:240px"><canvas id="ma-mat"></canvas></div></div></section>
        <section class="panel"><div class="panel__head"><span class="panel__title">Supplier spend breakdown</span></div><div class="panel__body"><div style="position:relative;height:260px"><canvas id="ma-sup"></canvas></div></div></section>
        <section class="panel"><div class="panel__head"><span class="panel__title">Project profit breakdown</span></div><div class="panel__body"><div style="position:relative;height:260px"><canvas id="ma-prj"></canvas></div></div></section>
      </div>` : "";

    return `
      <div class="panel__head" style="border:0;padding:0 0 10px"><span class="panel__title">Current pay period · ${esc(state.label)}</span></div>
      <div class="stat-grid">${headline}</div>
      ${labourPanel}
      <div class="panel__head" style="border:0;padding:18px 0 4px"><span class="panel__title">Profit, expenses &amp; VAT</span></div>
      <div class="stat-grid">${secondary}</div>
      <p class="muted-count" style="margin:10px 0 16px">Supplier costs = supplier invoices (Unpaid/Paid) from the register — the actual supplier bills. Material costs = owned stock issued to projects — a separate ledger, so the two never double-count. Outstanding balances are as at today.</p>
      ${chartBlock}`;
  }

  function tabPnL() {
    const { html } = expPnL();
    return reportToolbar("pnl", true) + `<div class="panel"><div class="panel__body">${html.replace(/class="r"/g, 'class="ta-r num"').replace(/<table>/g, '<div class="table-wrap"><table class="table">').replace(/<\/table>/g, "</table></div>")}</div></div>`;
  }
  function tabPayroll() {
    const rows = payrollRows(state.from, state.to);
    const total = r2(rows.reduce((s, r) => s + r.total, 0));
    const body = rows.length ? `<div class="table-wrap"><table class="table">
      <thead><tr><th>Employee</th><th>Trade</th><th class="ta-r">Hours</th><th class="ta-r">Rate</th><th class="ta-r">Gross</th><th class="ta-r">Overtime</th><th class="ta-r">Bonuses</th><th class="ta-r">Total</th></tr></thead>
      <tbody>${rows.map((r) => `<tr><td><strong>${esc(r.name)}</strong></td><td>${esc(r.trade)}</td><td class="ta-r num">${Fmt.hours(r.regHours)}</td><td class="ta-r num">${gbp(r.rate)}</td><td class="ta-r num">${gbp(r.gross)}</td><td class="ta-r num">${gbp(r.otPay)}</td><td class="ta-r num">${gbp(r.bonus)}</td><td class="ta-r num">${gbp(r.total)}</td></tr>`).join("")}</tbody>
      <tfoot><tr class="totals"><td colspan="7">Total payroll</td><td class="ta-r num">${gbp(total)}</td></tr></tfoot></table></div>`
      : emptyBox("No timesheets in this period", "Log timesheets to build the payroll report.");
    return reportToolbar("payroll", true) + `<div class="panel"><div class="panel__body">${body}</div></div>`;
  }
  function tabSuppliers() {
    const rows = supplierRows(state.from, state.to);
    const total = r2(rows.reduce((s, r) => s + r.total, 0));
    const paidT = r2(rows.reduce((s, r) => s + r.paid, 0));
    const outT = r2(rows.reduce((s, r) => s + r.outstanding, 0));
    const spendBody = rows.length ? `<div class="table-wrap"><table class="table">
      <thead><tr><th>Supplier</th><th class="ta-r">Invoice count</th><th class="ta-r">Total spend</th><th class="ta-r">Paid</th><th class="ta-r">Outstanding</th></tr></thead>
      <tbody>${rows.map((r) => `<tr><td><strong>${esc(r.name)}</strong></td><td class="ta-r num">${r.count}</td><td class="ta-r num">${gbp(r.total)}</td><td class="ta-r num">${gbp(r.paid)}</td><td class="ta-r num"${r.outstanding > 0 ? ' style="color:var(--danger,#dc2626)"' : ""}>${gbp(r.outstanding)}</td></tr>`).join("")}</tbody>
      <tfoot><tr class="totals"><td>${rows.length} supplier${rows.length === 1 ? "" : "s"}</td><td class="ta-r num">${rows.reduce((s, r) => s + r.count, 0)}</td><td class="ta-r num">${gbp(total)}</td><td class="ta-r num">${gbp(paidT)}</td><td class="ta-r num">${gbp(outT)}</td></tr></tfoot></table></div>`
      : emptyBox("No supplier spend in this period", "Enter supplier invoices in the register to populate this.");

    // outstanding supplier invoices — as at today, oldest due first
    const open = outstandingSupplierInvoices();
    const openTotal = r2(open.reduce((s, r) => s + r.amount, 0));
    const canPay = Auth.can("Manager");
    const openBody = open.length ? `<div class="table-wrap"><table class="table">
      <thead><tr><th>Supplier</th><th>Invoice number</th><th>Due date</th><th class="ta-r">Amount outstanding</th>${canPay ? `<th class="ta-r"></th>` : ""}</tr></thead>
      <tbody>${open.map((r) => `<tr><td><strong>${esc(r.supplier)}</strong></td><td>${esc(r.number)}</td><td class="num">${r.due ? Fmt.date(r.due) : "—"}</td><td class="ta-r num">${gbp(r.amount)}</td>${canPay ? `<td class="ta-r"><button class="btn btn--sm" data-paypo="${r.id}">Mark paid</button></td>` : ""}</tr>`).join("")}</tbody>
      <tfoot><tr class="totals"><td colspan="3">${open.length} open invoice${open.length === 1 ? "" : "s"}</td><td class="ta-r num">${gbp(openTotal)}</td>${canPay ? "<td></td>" : ""}</tr></tfoot></table></div>`
      : emptyBox("No outstanding supplier invoices", "Every supplier invoice has been marked paid.");

    return reportToolbar("suppliers") + `
      <div class="panel"><div class="panel__head"><span class="panel__title">Supplier spend · ${esc(state.label)}</span><span class="muted-count num">${gbp(total)}</span></div>
        <div class="panel__body">${spendBody}</div></div>
      <div class="panel"><div class="panel__head"><span class="panel__title">Outstanding supplier invoices</span><span class="muted-count num">${gbp(openTotal)}</span></div>
        <div class="panel__body">${openBody}</div></div>`;
  }
  function tabProjects() {
    const rows = projectRows(state.from, state.to);
    const body = rows.length ? `<div class="table-wrap"><table class="table">
      <thead><tr><th>Project</th><th class="ta-r">Revenue</th><th class="ta-r">Labour</th><th class="ta-r">Materials</th><th class="ta-r">Expenses</th><th class="ta-r">Subs</th><th class="ta-r">Profit</th></tr></thead>
      <tbody>${rows.map((r) => `<tr><td><strong>${esc(r.name)}</strong></td><td class="ta-r num">${gbp(r.revenue)}</td><td class="ta-r num">${gbp(r.labour)}</td><td class="ta-r num">${gbp(r.materials)}</td><td class="ta-r num">${gbp(r.expenses)}</td><td class="ta-r num">${gbp(r.subs)}</td><td class="ta-r num">${gbp(r.profit)}</td></tr>`).join("")}</tbody></table></div>
      <p class="muted-count" style="margin-top:8px">Subcontractor (CIS) costs aren't linked to projects in the data model, so the Subs column is company-level only (£0.00 per project).</p>`
      : emptyBox("No project activity in this period", "Invoices, timesheets, supplier invoices and expenses tagged to a project appear here.");
    return reportToolbar("projects") + `<div class="panel"><div class="panel__body">${body}</div></div>`;
  }
  function tabVAT() {
    const f = figures(state.from, state.to);
    const body = `<div class="stat-grid">
      ${stat("VAT collected", gbp(f.vatOut), "output VAT on sales")}
      ${stat("VAT paid", gbp(f.vatIn), "input VAT on purchases")}
      ${stat("VAT owed to HMRC", gbp(f.vatOwed), f.vatOwed >= 0 ? "payable" : "reclaimable")}
    </div>
    <div class="panel"><div class="panel__body"><div class="table-wrap"><table class="table">
      <tbody>
      <tr><td>Sales (net)</td><td class="ta-r num">${gbp(f.revNet)}</td></tr>
      <tr><td>VAT collected (output)</td><td class="ta-r num">${gbp(f.vatOut)}</td></tr>
      <tr><td>Purchases (net)</td><td class="ta-r num">${gbp(f.poNet)}</td></tr>
      <tr><td>VAT paid (input)</td><td class="ta-r num">${gbp(f.vatIn)}</td></tr>
      <tr class="totals"><td>VAT owed to HMRC</td><td class="ta-r num">${gbp(f.vatOwed)}</td></tr>
      </tbody></table></div></div></div>`;
    return reportToolbar("vat", true) + body;
  }
  function tabCash() {
    const { html } = expCash();
    return reportToolbar("cash", true) + `<div class="panel"><div class="panel__body">${html.replace(/class="r"/g, 'class="ta-r num"').replace(/<table>/g, '<div class="table-wrap"><table class="table">').replace(/<\/table>/g, "</table></div>")}</div></div>`;
  }
  function tabOutstanding() {
    const o = outstanding();
    return `<div class="stat-grid">
      ${stat("Outstanding client invoices", gbp(o.client), "issued, unpaid")}
      ${stat("Outstanding supplier invoices", gbp(o.supplier), "unpaid · as at today")}
      ${stat("Outstanding reimbursements", gbp(o.reimb), "owed to employees")}
      ${stat("Outstanding retentions", gbp(o.retentions), "not tracked")}
    </div>
    <p class="muted-count" style="margin-top:10px">Balances are as at today. Supplier figure = supplier invoices with status Unpaid. Retentions aren't modelled.</p>`;
  }
  const emptyBox = (title, text) => `<div class="empty"><div class="empty__title">${esc(title)}</div><div class="empty__text">${esc(text)}</div></div>`;

  function render(root) {
    if (disposer) { disposer(); disposer = null; }
    destroyCharts();
    resolvePeriod();

    const tabBody = {
      overview: tabOverview, pnl: tabPnL, payroll: tabPayroll, suppliers: tabSuppliers,
      projects: tabProjects, vat: tabVAT, cash: tabCash, outstanding: tabOutstanding,
    }[state.tab] || tabOverview;

    root.innerHTML = `<div class="page-head"><h2 class="page-head__greet">Accounting</h2>
      <p class="page-head__sub">Payroll-period overview &amp; reporting · ${esc(COMPANY())}</p></div>
      ${periodBar()}${tabBody()}`;

    /* period controls */
    root.querySelector("#ma-preset").addEventListener("change", (e) => { state.preset = e.target.value; render(root); });
    const mm = root.querySelector("#ma-month"); if (mm) mm.addEventListener("change", (e) => { state.ym = e.target.value || state.ym; render(root); });
    const ff = root.querySelector("#ma-from"); if (ff) ff.addEventListener("change", (e) => { state.from = e.target.value; render(root); });
    const tt = root.querySelector("#ma-to"); if (tt) tt.addEventListener("change", (e) => { state.to = e.target.value; render(root); });
    root.querySelectorAll("[data-tab]").forEach((b) => b.addEventListener("click", () => { state.tab = b.dataset.tab; render(root); }));

    /* overview PDF (whole-month snapshot) */
    const allBtn = root.querySelector("#ma-pdf-all");
    if (allBtn) allBtn.addEventListener("click", () => {
      const f = figures(state.from, state.to), o = outstanding();
      const row = (l, v) => `<tr><td>${l}</td><td class="r">${gbp(v)}</td></tr>`;
      pdf(`Pay period overview — ${state.label}`, `
        <h2>Headline figures</h2>
        <table><tbody>
        ${row("Revenue (net)", f.revNet)}${row("Net profit", f.netProfit)}<tr><td>Profit margin</td><td class="r">${Fmt.hours(f.margin)}%</td></tr>
        ${row("Payroll", f.payroll)}${row("Supplier invoices (net)", f.poNet)}${row("Employee expenses", f.expenses)}
        ${row("Subcontractors (CIS)", f.subGross)}${row("Skip hire", f.skip)}${row("Equipment", f.equipment)}
        ${row("VAT collected", f.vatOut)}${row("VAT paid", f.vatIn)}${row("VAT owed", f.vatOwed)}
        ${row("Client payments (cash)", f.clientPayments)}
        </tbody></table>
        <h2>Outstanding (as at today)</h2>
        <table><tbody>${row("Client invoices", o.client)}${row("Supplier invoices", o.supplier)}${row("Employee reimbursements", o.reimb)}${row("Retentions (not tracked)", o.retentions)}</tbody></table>`);
    });

    /* per-report exports */
    const exporters = {
      "pnl-pdf": () => pdf("Profit & Loss", expPnL().html),
      "pnl-xls": () => downloadXls(`profit-loss-${state.from}.xls`, expPnL().sheets),
      "payroll-pdf": () => pdf("Payroll", expPayroll().html),
      "payroll-xls": () => downloadXls(`payroll-${state.from}.xls`, expPayroll().sheets),
      "vat-pdf": () => pdf("VAT summary", expVAT().html),
      "vat-xls": () => downloadXls(`vat-${state.from}.xls`, expVAT().sheets),
      "cash-pdf": () => pdf("Cash flow", expCash().html),
      "cash-xls": () => downloadXls(`cash-flow-${state.from}.xls`, expCash().sheets),
      "suppliers-pdf": () => { const rows = supplierRows(state.from, state.to); const open = outstandingSupplierInvoices(); pdf("Supplier report", `<h2>Supplier spend — ${esc(state.label)}</h2><table><thead><tr><th>Supplier</th><th class="r">Invoice count</th><th class="r">Total spend</th><th class="r">Paid</th><th class="r">Outstanding</th></tr></thead><tbody>${rows.map((r) => `<tr><td>${esc(r.name)}</td><td class="r">${r.count}</td><td class="r">${gbp(r.total)}</td><td class="r">${gbp(r.paid)}</td><td class="r">${gbp(r.outstanding)}</td></tr>`).join("")}</tbody></table><h2>Outstanding supplier invoices (as at today)</h2><table><thead><tr><th>Supplier</th><th>Invoice no.</th><th>Due</th><th class="r">Outstanding</th></tr></thead><tbody>${open.map((r) => `<tr><td>${esc(r.supplier)}</td><td>${esc(r.number)}</td><td>${r.due ? Fmt.date(r.due) : "—"}</td><td class="r">${gbp(r.amount)}</td></tr>`).join("")}</tbody></table>`); },
      "suppliers-csv": () => { const rows = supplierRows(state.from, state.to); Util.downloadCSV(`suppliers-${state.from}.csv`, [["Supplier", "Invoice count", "Total spend", "Paid", "Outstanding"], ...rows.map((r) => [r.name, r.count, r.total, r.paid, r.outstanding])]); },
      "projects-pdf": () => { const rows = projectRows(state.from, state.to); pdf("Project costs", `<h2>Project costs — ${esc(state.label)}</h2><table><thead><tr><th>Project</th><th class="r">Revenue</th><th class="r">Labour</th><th class="r">Materials</th><th class="r">Expenses</th><th class="r">Profit</th></tr></thead><tbody>${rows.map((r) => `<tr><td>${esc(r.name)}</td><td class="r">${gbp(r.revenue)}</td><td class="r">${gbp(r.labour)}</td><td class="r">${gbp(r.materials)}</td><td class="r">${gbp(r.expenses)}</td><td class="r">${gbp(r.profit)}</td></tr>`).join("")}</tbody></table>`); },
      "projects-csv": () => { const rows = projectRows(state.from, state.to); Util.downloadCSV(`projects-${state.from}.csv`, [["Project", "Revenue", "Labour", "Materials", "Expenses", "Subs", "Profit"], ...rows.map((r) => [r.name, r.revenue, r.labour, r.materials, r.expenses, r.subs, r.profit])]); },
    };
    root.querySelectorAll("[data-x]").forEach((b) => b.addEventListener("click", () => { const fn = exporters[b.dataset.x]; if (fn) fn(); }));
    root.querySelectorAll("[data-paypo]").forEach((b) => b.addEventListener("click", () => markPoPaid(b.dataset.paypo)));

    if (state.tab === "overview" && hasChart()) {
      drawCharts(root);
      disposer = Util.onThemeChange(() => { if (document.body.contains(root) && root.querySelector("#ma-rev")) { destroyCharts(); drawCharts(root); } });
    }
  }

  /* ---- dashboard stat ---------------------------------------------------- */
  Dashboard.addStat(() => {
    const { from, to } = Period.payPeriodRange(0);
    const f = figures(from, to);
    return { label: "Payroll cost (this pay period)", value: Fmt.gbp(f.payroll), note: "labour + overtime", route: "monthly" };
  }, "Manager");

  /* ---- register ---------------------------------------------------------- */
  Modules.section("Accounting");
  Modules.register({
    id: "monthly", label: "Accounting", title: "Payroll Period Accounting", minRole: "Manager",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M8 4v16M3 14h5"/></svg>',
    render,
  });
})();
