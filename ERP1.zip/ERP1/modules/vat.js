/* ==========================================================================
   modules/vat.js — VAT reporting (Phase 5)
   A derived VAT-return summary (no own collection). Reads:
     Output VAT (Box 1) = VAT on non-draft invoices
     Input  VAT (Box 4) = VAT on purchase orders that are Ordered/Received
     Net VAT due (Box 5) = output − input
   Period: calendar quarter / year / all. Uses Commercial.Money for VAT maths.
   Standard accounting only — not Flat Rate / cash accounting / reverse charge.
   ========================================================================== */
(() => {
  "use strict";
  const Money = Commercial.Money;
  const vatOf = (d) => Money.totals(d.items, d.vatRate).vat;
  const netOf = (d) => Money.totals(d.items, d.vatRate).sub;
  const iso = Period.isoOf; // shared LOCAL serialisation (was UTC — day-shift bug)

  function periodRange(key) {
    const now = new Date(), y = now.getFullYear();
    if (key === "this-q" || key === "last-q") {
      let q = Math.floor(now.getMonth() / 3); let yy = y;
      if (key === "last-q") { q -= 1; if (q < 0) { q = 3; yy -= 1; } }
      const from = new Date(yy, q * 3, 1), to = new Date(yy, q * 3 + 3, 0);
      return { from: iso(from), to: iso(to), label: `Q${q + 1} ${yy}` };
    }
    if (key === "this-y") return { from: `${y}-01-01`, to: `${y}-12-31`, label: `${y}` };
    return { from: null, to: null, label: "All time" };
  }

  const state = { period: "this-q" };
  function compute(rng) {
    const inv = Store.all("invoices").filter((i) => i.status !== "Draft" && Period.inRange(i.date, rng.from, rng.to));
    const pos = Store.all("purchaseOrders").filter((p) => (p.status === "Ordered" || p.status === "Received") && Period.inRange(p.date, rng.from, rng.to));
    const r2 = Money.r2;
    const outVat = r2(inv.reduce((s, i) => s + vatOf(i), 0));
    const inVat = r2(pos.reduce((s, p) => s + vatOf(p), 0));
    const sales = r2(inv.reduce((s, i) => s + netOf(i), 0));
    const purch = r2(pos.reduce((s, p) => s + netOf(p), 0));
    return { outVat, inVat, net: r2(outVat - inVat), sales, purch, invCount: inv.length, poCount: pos.length };
  }

  function render(root) {
    const rng = periodRange(state.period);
    const v = compute(rng);
    const pOpts = [["this-q", "This quarter"], ["last-q", "Last quarter"], ["this-y", "This year"], ["all", "All time"]]
      .map(([val, l]) => `<option value="${val}"${state.period === val ? " selected" : ""}>${l}</option>`).join("");

    const box = (n, label, value, note) => `<tr><td class="num">${n}</td><td>${label}</td><td class="ta-r num"><strong>${Fmt.gbp(value)}</strong></td><td class="muted-count">${note}</td></tr>`;

    root.innerHTML = `
      <div class="toolbar">
        <div class="toolbar__left filterbar">
          <select class="input" id="vt-period">${pOpts}</select>
          <span class="muted-count num">${esc(rng.label)}</span>
        </div>
      </div>
      <div class="stat-grid">
        <div class="stat" data-route="invoices" role="button" tabindex="0" style="cursor:pointer"><div class="stat__label">Output VAT (sales)</div><div class="stat__value num">${Fmt.gbp(v.outVat)}</div><div class="stat__note">${v.invCount} invoice${v.invCount === 1 ? "" : "s"}</div></div>
        <div class="stat" data-route="purchaseOrders" role="button" tabindex="0" style="cursor:pointer"><div class="stat__label">Input VAT (purchases)</div><div class="stat__value num">${Fmt.gbp(v.inVat)}</div><div class="stat__note">${v.poCount} PO${v.poCount === 1 ? "" : "s"}</div></div>
        <div class="stat"><div class="stat__label">${v.net >= 0 ? "VAT due to HMRC" : "VAT reclaimable"}</div><div class="stat__value num" style="${v.net >= 0 ? "color:var(--danger,#dc2626)" : "color:var(--ok,#16a34a)"}">${Fmt.gbp(Math.abs(v.net))}</div><div class="stat__note">output − input</div></div>
      </div>
      <div class="panel">
        <div class="panel__head"><span class="panel__title">VAT return summary</span><span class="muted-count num">${esc(rng.label)}</span></div>
        <div class="panel__body">
          <div class="table-wrap"><table class="table table--tight">
            <thead><tr><th>Box</th><th>Description</th><th class="ta-r">Amount</th><th></th></tr></thead>
            <tbody>
              ${box(1, "VAT due on sales (output)", v.outVat, "from invoices")}
              ${box(4, "VAT reclaimed on purchases (input)", v.inVat, "from purchase orders")}
              ${box(6, "Total sales ex-VAT", v.sales, "net turnover")}
              ${box(7, "Total purchases ex-VAT", v.purch, "net PO spend")}
            </tbody>
            <tfoot><tr class="totals"><td class="num">5</td><td>Net VAT ${v.net >= 0 ? "due to HMRC" : "to reclaim"}</td><td class="ta-r num"><strong>${Fmt.gbp(Math.abs(v.net))}</strong></td><td></td></tr></tfoot>
          </table></div>
          <p class="hint hint--block">Estimate from invoices and POs in this period, standard VAT accounting only. Expenses carry no VAT field, so they are excluded. Not a substitute for your bookkeeping / MTD submission.</p>
        </div>
      </div>
    `;
    root.querySelector("#vt-period").addEventListener("change", (e) => { state.period = e.target.value; render(root); });
    root.querySelectorAll("[data-route]").forEach((el) => { el.addEventListener("click", () => Router.navigate(el.dataset.route)); el.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); Router.navigate(el.dataset.route); } }); });
  }

  Modules.register({
    id: "vat", label: "VAT", title: "VAT Reporting", minRole: "Manager",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 19L19 5M8 7a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zM19 17a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"/></svg>',
    render,
  });
})();
