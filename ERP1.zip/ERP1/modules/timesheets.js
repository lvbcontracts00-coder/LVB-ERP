/* ==========================================================================
   modules/timesheets.js — Timesheets (Phase 2)
   Store collection "timesheets".
   Record: { id, workerId, siteId, date, hours, overtime, notes }
   Depends on workers + sites for selects and labour-cost lookups.
   ========================================================================== */
(() => {
  "use strict";
  const COL = "timesheets";
  const DEFAULT_OT = 1.5; // OT premium used for the per-row cost *estimate*

  const canEdit = () => Auth.can("Manager");
  const workerName = (id) => (Store.find("workers", id) || {}).name || "Unknown worker";
  const siteName   = (id) => (Store.find("sites", id) || {}).name || "Unknown site";
  const workerRate = (id) => (Store.find("workers", id) || {}).rate || 0;
  const entryCost  = (t) => (Number(t.hours) || 0) * workerRate(t.workerId) + (Number(t.overtime) || 0) * workerRate(t.workerId) * DEFAULT_OT;

  // filter state (persists while navigating within the session)
  const filt = { worker: "all", period: "this-week" };

  /* ---- form -------------------------------------------------------------- */
  function workerOptions(sel) {
    return Store.all("workers")
      .filter((w) => w.status === "Active" || w.id === sel)
      .map((w) => `<option value="${w.id}"${w.id === sel ? " selected" : ""}>${esc(w.name)} — ${esc(w.trade)}</option>`).join("");
  }
  function siteOptions(sel) {
    return Store.all("sites")
      .filter((s) => s.status !== "Completed" || s.id === sel)
      .map((s) => `<option value="${s.id}"${s.id === sel ? " selected" : ""}>${esc(s.name)}</option>`).join("");
  }

  function form(t) {
    t = t || {}; // null-safe: JS default params apply to undefined only, not null
    return `
      <div class="form-grid">
        <div class="field"><label class="field__label">Worker *</label>
          <select class="input" id="t-worker">${workerOptions(t.workerId)}</select></div>
        <div class="field"><label class="field__label">Site *</label>
          <select class="input" id="t-site">${siteOptions(t.siteId)}</select></div>
        <div class="field"><label class="field__label">Date *</label>
          <input class="input" id="t-date" type="date" value="${esc(t.date || Fmt.todayISO())}"></div>
        <div class="field"><label class="field__label">Hours *</label>
          <input class="input" id="t-hours" type="number" min="0" step="0.5" value="${t.hours ?? ""}" placeholder="8"></div>
        <div class="field"><label class="field__label">Overtime hrs</label>
          <input class="input" id="t-ot" type="number" min="0" step="0.5" value="${t.overtime ?? 0}" placeholder="0"></div>
        <div class="field"><label class="field__label">&nbsp;</label>
          <div class="hint">OT estimated at ${DEFAULT_OT}× base rate.</div></div>
        <div class="field span-2"><label class="field__label">Notes</label>
          <input class="input" id="t-notes" value="${esc(t.notes || "")}" placeholder="Optional"></div>
      </div>`;
  }

  function read(rootEl) {
    return {
      workerId: rootEl.querySelector("#t-worker").value,
      siteId: rootEl.querySelector("#t-site").value,
      date: rootEl.querySelector("#t-date").value,
      hours: parseFloat(rootEl.querySelector("#t-hours").value),
      overtime: parseFloat(rootEl.querySelector("#t-ot").value) || 0,
      notes: rootEl.querySelector("#t-notes").value.trim(),
    };
  }

  function openForm(existing) {
    if (!Store.all("workers").length || !Store.all("sites").length) return; // guarded by render
    UI.modal({
      title: existing ? "Edit timesheet" : "Log timesheet",
      size: "lg",
      bodyHTML: form(existing),
      saveLabel: existing ? "Save changes" : "Log entry",
      onSave: (rootEl) => {
        const d = read(rootEl);
        if (!d.workerId || !d.siteId) { UI.toast("Pick a worker and a site", "danger"); return false; }
        if (!d.date) { UI.toast("Date is required", "danger"); return false; }
        if (isNaN(d.hours) || d.hours <= 0) { UI.toast("Enter hours worked", "danger"); return false; }
        if (existing) { Store.update(COL, existing.id, d); UI.toast("Timesheet updated", "ok"); }
        else { Store.insert(COL, d); UI.toast("Timesheet logged", "ok"); }
        render(document.getElementById("view-root"));
      },
    });
  }

  function remove(t) {
    UI.confirm("Delete this timesheet entry?", () => {
      Store.destroy(COL, t.id);
      UI.toast("Entry deleted", "info");
      render(document.getElementById("view-root"));
    });
  }

  /* ---- render ------------------------------------------------------------ */
  function filtered() {
    const { from, to } = Period.range(filt.period);
    return Store.all(COL)
      .filter((t) => filt.worker === "all" || t.workerId === filt.worker)
      .filter((t) => Period.inRange(t.date, from, to))
      .sort((a, b) => (b.date || "").localeCompare(a.date || ""));
  }

  function render(root) {
    const workers = Store.all("workers");
    const sites = Store.all("sites");

    // Need workers + sites before any time can be logged.
    if (!workers.length || !sites.length) {
      root.innerHTML = `<div class="panel"><div class="panel__body"><div class="empty">
        <svg class="empty__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M3 9h18M8 2v4M16 2v4"/></svg>
        <div class="empty__title">Set up workers and sites first</div>
        <div class="empty__text">Timesheets link a worker to a site, so add at least one of each.</div>
        <div class="empty__actions">
          ${!workers.length ? `<button class="btn btn--sm" data-route="workers">Go to Workers</button>` : ""}
          ${!sites.length ? `<button class="btn btn--sm" data-route="sites">Go to Sites</button>` : ""}
        </div>
      </div></div></div>`;
      root.querySelectorAll("[data-route]").forEach((b) => b.addEventListener("click", () => Router.navigate(b.dataset.route)));
      return;
    }

    const rows = filtered();
    const totalHours = rows.reduce((s, t) => s + (Number(t.hours) || 0) + (Number(t.overtime) || 0), 0);
    const totalCost = rows.reduce((s, t) => s + entryCost(t), 0);

    const wOpts = `<option value="all">All workers</option>` +
      workers.map((w) => `<option value="${w.id}"${filt.worker === w.id ? " selected" : ""}>${esc(w.name)}</option>`).join("");
    const pOpts = [["this-week", "This week"], ["last-week", "Last week"], ["this-month", "This month"], ["all", "All time"]]
      .map(([v, l]) => `<option value="${v}"${filt.period === v ? " selected" : ""}>${l}</option>`).join("");

    root.innerHTML = `
      <div class="toolbar">
        <div class="toolbar__left filterbar">
          <select class="input" id="t-fworker">${wOpts}</select>
          <select class="input" id="t-fperiod">${pOpts}</select>
        </div>
        ${canEdit() ? `<button class="btn btn--primary" id="t-add">＋ Log timesheet</button>` : ""}
      </div>

      ${rows.length ? `
        <div class="table-wrap"><table class="table">
          <thead><tr>
            <th>Date</th><th>Worker</th><th>Site</th><th class="ta-r">Hours</th><th class="ta-r">OT</th><th class="ta-r">Est. cost</th>
            ${canEdit() ? `<th class="ta-r">Actions</th>` : ""}
          </tr></thead>
          <tbody>
            ${rows.map((t) => `
              <tr>
                <td class="num">${Fmt.date(t.date)}</td>
                <td><strong>${esc(workerName(t.workerId))}</strong></td>
                <td>${esc(siteName(t.siteId))}</td>
                <td class="ta-r num">${Fmt.hours(t.hours)}</td>
                <td class="ta-r num">${t.overtime ? Fmt.hours(t.overtime) : "—"}</td>
                <td class="ta-r num">${Fmt.gbp(entryCost(t))}</td>
                ${canEdit() ? `<td class="ta-r nowrap">
                  <button class="btn btn--sm" data-edit="${t.id}">Edit</button>
                  <button class="btn btn--sm btn--danger" data-del="${t.id}">Delete</button></td>` : ""}
              </tr>`).join("")}
          </tbody>
          <tfoot><tr class="totals">
            <td colspan="3">${rows.length} entr${rows.length === 1 ? "y" : "ies"}</td>
            <td class="ta-r num">${Fmt.hours(totalHours)}</td><td></td>
            <td class="ta-r num">${Fmt.gbp(totalCost)}</td>${canEdit() ? "<td></td>" : ""}
          </tr></tfoot>
        </table></div>`
      : `<div class="panel"><div class="panel__body"><div class="empty">
          <svg class="empty__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M3 9h18M8 2v4M16 2v4"/></svg>
          <div class="empty__title">No entries for this filter</div>
          <div class="empty__text">Try a different period or log a new entry.</div>
        </div></div></div>`}
    `;

    root.querySelector("#t-fworker").addEventListener("change", (e) => { filt.worker = e.target.value; render(root); });
    root.querySelector("#t-fperiod").addEventListener("change", (e) => { filt.period = e.target.value; render(root); });
    const add = root.querySelector("#t-add");
    if (add) add.addEventListener("click", () => openForm(null));
    root.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => openForm(Store.find(COL, b.dataset.edit))));
    root.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => remove(Store.find(COL, b.dataset.del))));
  }

  /* ---- dashboard stat + activity ----------------------------------------- */
  Dashboard.addStat(() => {
    const { from, to } = Period.range("this-week");
    const week = Store.all(COL).filter((t) => Period.inRange(t.date, from, to));
    const hrs = week.reduce((s, t) => s + (Number(t.hours) || 0) + (Number(t.overtime) || 0), 0);
    return { label: "Hours this week", value: Fmt.hours(hrs), note: `${week.length} timesheet${week.length === 1 ? "" : "s"}`, route: "timesheets" };
  });

  Dashboard.addActivity(() =>
    Store.all(COL).map((t) => ({
      when: t.date,
      text: `${workerName(t.workerId)} · ${Fmt.hours((Number(t.hours) || 0) + (Number(t.overtime) || 0))}h · ${siteName(t.siteId)}`,
      route: "timesheets",
    }))
  );

  Modules.register({
    id: "timesheets", label: "Timesheets", title: "Timesheets", minRole: "Viewer",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M3 9h18M8 2v4M16 2v4"/><path d="M12 13v3l2 1"/></svg>',
    render,
  });
})();
