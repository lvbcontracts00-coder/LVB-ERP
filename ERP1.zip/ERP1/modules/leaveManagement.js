/* ==========================================================================
   modules/leaveManagement.js — Leave / absence requests (Phase 5)
   Store collection "leave".
   Record: { id, workerId, type, from, to, days, status, notes }
   Status: Pending · Approved · Rejected. Approved leave shows on the calendar.
   ========================================================================== */
(() => {
  "use strict";
  const COL = "leave";
  const canApprove = () => Auth.can("Manager");
  const TYPES = ["Holiday", "Sick", "Unpaid", "Compassionate", "Parental", "Other"];
  const STATUSES = ["Pending", "Approved", "Rejected"];
  const badgeKind = { "Pending": "warn", "Approved": "ok", "Rejected": "muted" };

  const opts = (list, sel) => list.map((o) => `<option value="${esc(o)}"${o === sel ? " selected" : ""}>${esc(o)}</option>`).join("");
  const workerName = (id) => (Store.find("workers", id) || {}).name || "Unknown";
  function workerOptions(sel) {
    const list = Store.all("workers").filter((w) => w.status === "Active" || w.id === sel);
    if (!list.length) return `<option value="">No workers</option>`;
    return list.map((w) => `<option value="${w.id}"${w.id === sel ? " selected" : ""}>${esc(w.name)}</option>`).join("");
  }
  function inclusiveDays(from, to) {
    if (!from || !to) return 0;
    const a = new Date(from), b = new Date(to);
    if (isNaN(a) || isNaN(b) || b < a) return 0;
    return Math.round((b - a) / 86400000) + 1;
  }

  function openForm(existing) {
    if (!Store.all("workers").length) { UI.toast("Add a worker first", "danger"); Router.navigate("workers"); return; }
    UI.modal({
      title: existing ? "Edit leave request" : "New leave request", size: "lg",
      saveLabel: existing ? "Save changes" : "Submit request",
      bodyHTML: `
        <div class="form-grid">
          <div class="field"><label class="field__label">Worker *</label>
            <select class="input" id="l-worker">${workerOptions(existing && existing.workerId)}</select></div>
          <div class="field"><label class="field__label">Type</label>
            <select class="input" id="l-type">${opts(TYPES, (existing && existing.type) || "Holiday")}</select></div>
          <div class="field"><label class="field__label">From *</label>
            <input class="input" id="l-from" type="date" value="${esc((existing && existing.from) || Fmt.todayISO())}"></div>
          <div class="field"><label class="field__label">To *</label>
            <input class="input" id="l-to" type="date" value="${esc((existing && existing.to) || Fmt.todayISO())}"></div>
          <div class="field"><label class="field__label">Days</label>
            <input class="input" id="l-days" type="number" min="0" step="0.5" value="${existing ? (existing.days ?? "") : ""}" placeholder="auto"></div>
          ${canApprove() ? `<div class="field"><label class="field__label">Status</label>
            <select class="input" id="l-status">${opts(STATUSES, (existing && existing.status) || "Pending")}</select></div>` : `<input type="hidden" id="l-status" value="${esc((existing && existing.status) || "Pending")}">`}
          <div class="field span-2"><label class="field__label">Notes</label>
            <input class="input" id="l-notes" value="${esc((existing && existing.notes) || "")}"></div>
        </div>`,
      onSave: (r) => {
        const from = r.querySelector("#l-from").value, to = r.querySelector("#l-to").value;
        if (!from || !to) { UI.toast("Pick start and end dates", "danger"); return false; }
        if (new Date(to) < new Date(from)) { UI.toast("End date is before start date", "danger"); return false; }
        const daysIn = r.querySelector("#l-days").value;
        const d = {
          workerId: r.querySelector("#l-worker").value, type: r.querySelector("#l-type").value,
          from, to, days: daysIn ? parseFloat(daysIn) : inclusiveDays(from, to),
          status: r.querySelector("#l-status").value, notes: r.querySelector("#l-notes").value.trim(),
        };
        if (!d.workerId) { UI.toast("Pick a worker", "danger"); return false; }
        if (existing) { Store.update(COL, existing.id, d); UI.toast("Request updated", "ok"); }
        else { Store.insert(COL, d); UI.toast("Leave request submitted", "ok"); }
        render(document.getElementById("view-root"));
      },
    });
    const mr = document.getElementById("modal-root");
    const sync = () => { const el = mr.querySelector("#l-days"); if (el && !el.value) el.placeholder = inclusiveDays(mr.querySelector("#l-from").value, mr.querySelector("#l-to").value) + " (auto)"; };
    mr.querySelector("#l-from").addEventListener("change", sync); mr.querySelector("#l-to").addEventListener("change", sync); sync();
  }
  function setStatus(rec, status) { Store.update(COL, rec.id, { status }); UI.toast(`Leave ${status.toLowerCase()}`, "ok"); render(document.getElementById("view-root")); }
  function remove(rec) { UI.confirm("Delete this leave request?", () => { Store.destroy(COL, rec.id); UI.toast("Deleted", "info"); render(document.getElementById("view-root")); }); }

  let filt = "all";
  function render(root) {
    const all = Store.all(COL).sort((a, b) => (b.from || "").localeCompare(a.from || ""));
    const rows = all.filter((l) => filt === "all" || l.status === filt);
    const pending = all.filter((l) => l.status === "Pending").length;
    const fOpts = [["all", "All"], ...STATUSES.map((s) => [s, s])].map(([v, l]) => `<option value="${v}"${filt === v ? " selected" : ""}>${l}</option>`).join("");

    root.innerHTML = `
      <div class="toolbar">
        <div class="toolbar__left filterbar">
          <select class="input" id="l-filter">${fOpts}</select>
          ${pending ? `<span class="badge badge--warn">${pending} pending</span>` : `<span class="muted-count">none pending</span>`}
        </div>
        <button class="btn btn--primary" id="l-add">＋ Request leave</button>
      </div>
      ${rows.length ? `
        <div class="table-wrap"><table class="table">
          <thead><tr><th>Worker</th><th>Type</th><th>From</th><th>To</th><th class="ta-r">Days</th><th>Status</th><th class="ta-r">Actions</th></tr></thead>
          <tbody>${rows.map((l) => `
            <tr>
              <td><strong>${esc(workerName(l.workerId))}</strong>${l.notes ? `<div class="muted-count">${esc(l.notes)}</div>` : ""}</td>
              <td>${esc(l.type || "—")}</td>
              <td class="num">${Fmt.date(l.from)}</td>
              <td class="num">${Fmt.date(l.to)}</td>
              <td class="ta-r num">${Fmt.hours(l.days)}</td>
              <td><span class="badge badge--${badgeKind[l.status] || "muted"}">${esc(l.status)}</span></td>
              <td class="ta-r nowrap">
                ${canApprove() && l.status === "Pending" ? `<button class="btn btn--sm" data-ok="${l.id}">Approve</button><button class="btn btn--sm btn--danger" data-no="${l.id}">Reject</button>` : ""}
                <button class="btn btn--sm" data-edit="${l.id}">Edit</button>
                <button class="btn btn--sm btn--danger" data-del="${l.id}">Del</button>
              </td>
            </tr>`).join("")}</tbody>
        </table></div>`
      : `<div class="panel"><div class="panel__body"><div class="empty">
          <svg class="empty__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 9h18M8 3v4M16 3v4M9 14l2 2 4-4"/></svg>
          <div class="empty__title">No leave ${filt === "all" ? "requests yet" : "in this view"}</div>
          <div class="empty__text">Submit a request — approved leave appears on the calendar.</div>
        </div></div></div>`}
    `;
    root.querySelector("#l-filter").addEventListener("change", (e) => { filt = e.target.value; render(root); });
    root.querySelector("#l-add").addEventListener("click", () => openForm(null));
    root.querySelectorAll("[data-ok]").forEach((b) => b.addEventListener("click", () => setStatus(Store.find(COL, b.dataset.ok), "Approved")));
    root.querySelectorAll("[data-no]").forEach((b) => b.addEventListener("click", () => setStatus(Store.find(COL, b.dataset.no), "Rejected")));
    root.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => openForm(Store.find(COL, b.dataset.edit))));
    root.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => remove(Store.find(COL, b.dataset.del))));
  }

  Dashboard.addStat(() => {
    const p = Store.all(COL).filter((l) => l.status === "Pending").length;
    return { label: "Leave to approve", value: String(p), note: p ? "pending requests" : "none pending", route: "leaveManagement" };
  }, "Manager");

  Modules.section("HR & Scheduling");
  Modules.register({
    id: "leaveManagement", label: "Leave", title: "Leave Management", minRole: "Viewer",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 9h18M8 3v4M16 3v4"/></svg>',
    render,
  });
})();
