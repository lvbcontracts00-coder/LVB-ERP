/* ==========================================================================
   modules/reports.js — Advanced reports (Phase 5)
   Financial operations reporting that complements the profit module:
     · cash flow for a period
     · aged debtors (outstanding invoices bucketed by age)
     · collections summary
   Read-only; CSV export. Manager+ (financial data). Profitability lives in the
   profit module; VAT/CIS in their own modules — this is the cash & debtor view.
   ========================================================================== */
(() => {
  "use strict";
  const r2 = Commercial.Money.r2;
  const docTotal = (d) => Commercial.Money.totals(d.items, d.vatRate).total;
  const state = { period: "this-month" };
  const PLBL = { "this-week": "This week", "last-week": "Last week", "this-month": "This month", "all": "All time" };

  const clientName = (id) => id ? ((Store.find("clients", id) || {}).name || "Unknown") : "—";
  const paidFor = (invId) => r2(Store.all("payments").filter((p) => p.invoiceId === invId).reduce((s, p) => s + (Number(p.amount) || 0), 0));
  const daysOverdue = (inv) => { const due = inv.date2 || inv.date; if (!due) return 0; return Math.floor((new Date(Fmt.todayISO()) - new Date(due)) / 86400000); };

  function agedDebtors() {
    const buckets = { notDue: 0, b30: 0, b60: 0, b90: 0, b90p: 0 };
    const rows = [];
    Store.all("invoices").filter((i) => i.status !== "Draft" && i.status !== "Paid").forEach((i) => {
      const out = r2(docTotal(i) - paidFor(i.id));
      if (out <= 0) return;
      const od = daysOverdue(i);
      const key = od <= 0 ? "notDue" : od <= 30 ? "b30" : od <= 60 ? "b60" : od <= 90 ? "b90" : "b90p";
      buckets[key] = r2(buckets[key] + out);
      rows.push({ number: i.number, client: clientName(i.partyId), due: i.date2 || i.date, overdue: od, outstanding: out });
    });
    rows.sort((a, b) => b.overdue - a.overdue);
    const total = r2(Object.values(buckets).reduce((s, n) => s + n, 0));
    return { buckets, rows, total };
  }
  function cashFlow(key) {
    if (key === "all") { const c = Finance.cashFlow(); return { in: c.in, out: c.out, net: c.net }; }
    const { from, to } = Period.range(key);
    const cin = r2(Store.all("payments").filter((p) => Period.inRange(p.date, from, to)).reduce((s, p) => s + (Number(p.amount) || 0), 0));
    const cout = r2(Store.all("expenses").filter((e) => e.reimbursed && Period.inRange(e.reimbursementDate || e.date, from, to)).reduce((s, e) => s + (Number(e.amount) || 0), 0));
    return { in: cin, out: cout, net: r2(cin - cout) };
  }

  function exportDebtors(d) {
    const rows = [["Invoice", "Client", "Due", "Days overdue", "Outstanding"], ...d.rows.map((r) => [r.number, r.client, r.due, r.overdue, r.outstanding]), ["TOTAL", "", "", "", d.total]];
    Util.downloadCSV("aged-debtors.csv", rows);
  }
  function exportPdf(d, c) {
    const body = d.rows.map((r) => `<tr><td>${esc(r.number || "—")}</td><td>${esc(r.client)}</td><td>${Fmt.date(r.due)}</td><td class="r">${r.overdue > 0 ? r.overdue + "d" : "—"}</td><td class="r">${Fmt.gbp(r.outstanding)}</td></tr>`).join("");
    const html = `<h1>Aged debtors &amp; cash flow</h1><div class="muted">${esc(Commercial.Company.get().name || "Company")} · ${Fmt.date(Fmt.todayISO())}</div>
      <h2>Outstanding invoices</h2>
      <table><thead><tr><th>Invoice</th><th>Client</th><th>Due</th><th class="r">Overdue</th><th class="r">Outstanding</th></tr></thead>
      <tbody>${body || `<tr><td colspan="5">None outstanding</td></tr>`}</tbody>
      <tfoot><tr><td colspan="4">Total outstanding</td><td class="r">${Fmt.gbp(d.total)}</td></tr></tfoot></table>
      <h2>Cash flow (${esc(PLBL[state.period])})</h2>
      <table><tbody><tr><td>Cash in</td><td class="r">${Fmt.gbp(c.in)}</td></tr><tr><td>Cash out</td><td class="r">${Fmt.gbp(c.out)}</td></tr></tbody>
      <tfoot><tr><td>Net</td><td class="r">${Fmt.gbp(c.net)}</td></tr></tfoot></table>`;
    Util.printDocument("Reports", html);
  }

  function render(root) {
    const d = agedDebtors();
    const c = cashFlow(state.period);
    const collected = Finance.collected(null), invoiced = Finance.invoiced(null);
    const B = d.buckets;
    const pOpts = Object.entries(PLBL).map(([v, l]) => `<option value="${v}"${state.period === v ? " selected" : ""}>${l}</option>`).join("");
    const sc = (label, val, note) => `<div class="stat"><div class="stat__label">${esc(label)}</div><div class="stat__value num">${esc(val)}</div><div class="stat__note">${esc(note)}</div></div>`;

    root.innerHTML = `
      <div class="toolbar">
        <div class="toolbar__left"><span class="muted-count">Financial reports · cash &amp; debtors</span></div>
        <div class="filterbar"><button class="btn btn--sm" id="rp-exp">CSV</button><button class="btn btn--sm" id="rp-pdf">PDF</button></div>
      </div>
      <div class="stat-grid">
        ${sc("Invoiced (all-time)", Fmt.gbp(invoiced), "non-draft")}
        ${sc("Collected (all-time)", Fmt.gbp(collected), "client payments")}
        ${sc("Outstanding", Fmt.gbp(d.total), `${d.rows.length} open invoice${d.rows.length === 1 ? "" : "s"}`)}
        ${sc("Collection rate", invoiced ? r2(collected / invoiced * 100).toFixed(1) + "%" : "—", "collected ÷ invoiced")}
      </div>

      <div class="panel-grid">
        <section class="panel">
          <div class="panel__head"><span class="panel__title">Aged debtors</span><span class="muted-count num">${Fmt.gbp(d.total)}</span></div>
          <div class="panel__body">
            <div class="table-wrap"><table class="table table--tight">
              <tbody>
                <tr><td>Not yet due</td><td class="ta-r num">${Fmt.gbp(B.notDue)}</td></tr>
                <tr><td>1–30 days</td><td class="ta-r num">${Fmt.gbp(B.b30)}</td></tr>
                <tr><td>31–60 days</td><td class="ta-r num">${Fmt.gbp(B.b60)}</td></tr>
                <tr><td>61–90 days</td><td class="ta-r num">${Fmt.gbp(B.b90)}</td></tr>
                <tr><td>90+ days</td><td class="ta-r num" style="${B.b90p ? "color:var(--danger,#dc2626)" : ""}">${Fmt.gbp(B.b90p)}</td></tr>
              </tbody>
              <tfoot><tr class="totals"><td>Total outstanding</td><td class="ta-r num">${Fmt.gbp(d.total)}</td></tr></tfoot>
            </table></div>
          </div>
        </section>
        <section class="panel">
          <div class="panel__head"><span class="panel__title">Cash flow</span>
            <select class="input input--mini" id="rp-period" style="margin-left:auto">${pOpts}</select></div>
          <div class="panel__body">
            <div class="table-wrap"><table class="table table--tight">
              <tbody>
                <tr><td>Cash in <span class="muted-count">payments</span></td><td class="ta-r num">${Fmt.gbp(c.in)}</td></tr>
                <tr><td>Cash out <span class="muted-count">reimbursed expenses</span></td><td class="ta-r num">${Fmt.gbp(c.out)}</td></tr>
              </tbody>
              <tfoot><tr class="totals"><td>Net (${esc(PLBL[state.period])})</td><td class="ta-r num" style="${c.net < 0 ? "color:var(--danger,#dc2626)" : "color:var(--ok,#16a34a)"}"><strong>${Fmt.gbp(c.net)}</strong></td></tr></tfoot>
            </table></div>
          </div>
        </section>
      </div>

      <div class="panel">
        <div class="panel__head"><span class="panel__title">Open invoices</span></div>
        <div class="panel__body">
          ${d.rows.length ? `<div class="table-wrap"><table class="table">
            <thead><tr><th>Invoice</th><th>Client</th><th>Due</th><th class="ta-r">Days overdue</th><th class="ta-r">Outstanding</th></tr></thead>
            <tbody>${d.rows.map((r) => `<tr>
              <td><strong>${esc(r.number || "—")}</strong></td><td>${esc(r.client)}</td>
              <td class="num">${Fmt.date(r.due)}</td>
              <td class="ta-r num">${r.overdue > 0 ? `<span class="badge badge--warn">${r.overdue}d</span>` : `<span class="muted-count">—</span>`}</td>
              <td class="ta-r num"><strong>${Fmt.gbp(r.outstanding)}</strong></td></tr>`).join("")}</tbody>
          </table></div>` : `<div class="empty"><div class="empty__title">No outstanding invoices</div><div class="empty__text">Everything invoiced has been collected.</div></div>`}
        </div>
      </div>
    `;
    root.querySelector("#rp-exp").addEventListener("click", () => exportDebtors(d));
    root.querySelector("#rp-pdf").addEventListener("click", () => exportPdf(d, c));
    root.querySelector("#rp-period").addEventListener("change", (e) => { state.period = e.target.value; render(root); });
  }

  Modules.section("Insights");
  Modules.register({
    id: "reports", label: "Reports", title: "Advanced Reports", minRole: "Manager",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/></svg>',
    render,
  });
})();
