/* ==========================================================================
   modules/quotes.js — Quotations (Phase 3)
   Thin config over Commercial.docModule. Store collection "quotes".
   Quotes addressed to clients; line items + VAT; PDF-ready preview.
   ========================================================================== */
(() => {
  "use strict";

  Commercial.docModule({
    id: "quotes", label: "Quotes", title: "Quotes", noun: "quote",
    collection: "quotes", prefix: "QUO", docTitle: "QUOTATION",
    minRole: "Viewer", editRole: "Manager",
    party: { coll: "clients", label: "Client", route: "clients" },
    dateLabel: "Date", date2: { label: "Valid until" },
    statuses: [
      { value: "Draft", badge: "muted" },
      { value: "Sent", badge: "warn" },
      { value: "Accepted", badge: "ok" },
      { value: "Rejected", badge: "danger" },
    ],
    defaultStatus: "Draft",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 2h6l2 4H7z"/><path d="M5 6h14v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2z"/><path d="M9 12h6M9 16h6"/></svg>',
    // dashboard: open (Draft+Sent) quotes count + pipeline value
    stat: () => {
      const open = Store.all("quotes").filter((q) => q.status === "Draft" || q.status === "Sent");
      const val = open.reduce((s, q) => s + Commercial.Money.totals(q.items, q.vatRate).total, 0);
      return { label: "Open quotes", value: String(open.length), note: `${Fmt.gbp(val)} pipeline`, route: "quotes" };
    },
  });
})();
