/* ==========================================================================
   modules/cis.js — CIS (Construction Industry Scheme) deductions (Phase 5)
   Store collection "cisStatements".
   Record: { id, date, subcontractor, supplierId, utr, gross, materials,
             rate, deduction, net, paid }
   CIS deduction applies to the LABOUR element only:
     deduction = (gross − materials) × rate%   (20% registered, 30% unverified,
                 0% gross-status). HMRC tax months run 6th → 5th.
   ========================================================================== */
(() => {
  "use strict";
  const COL = "cisStatements";
  const canEdit = () => Auth.can("Manager");
  const RATES = [["20", "20% — registered"], ["30", "30% — unverified"], ["0", "0% — gross status"]];
  const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;

  const supplierName = (id) => id ? ((Store.find("suppliers", id) || {}).name || "") : "";
  function supplierOptions(sel) { return `<option value="">— not linked —</option>` + Store.all("suppliers").map((s) => `<option value="${s.id}"${s.id === sel ? " selected" : ""}>${esc(s.name)}</option>`).join(""); }
  const calcDeduction = (gross, materials, rate) => r2(Math.max(0, (Number(gross) || 0) - (Number(materials) || 0)) * (Number(rate) || 0) / 100);

  // tax month (6th→5th) containing date `d`; offset shifts whole tax months back
  function taxMonth(d, offset = 0) {
    const base = new Date(d);
    let start = base.getDate() >= 6 ? new Date(base.getFullYear(), base.getMonth(), 6) : new Date(base.getFullYear(), base.getMonth() - 1, 6);
    start = new Date(start.getFullYear(), start.getMonth() + offset, 6);
    const end = new Date(start.getFullYear(), start.getMonth() + 1, 5);
    const iso = Period.isoOf; // shared LOCAL serialisation (was UTC — day-shift bug)
    const lbl = `6 ${start.toLocaleDateString("en-GB", { month: "short" })} – 5 ${end.toLocaleDateString("en-GB", { month: "short" })}`;
    return { from: iso(start), to: iso(end), label: lbl };
  }
  function periodRange(key) {
    if (key === "this") return taxMonth(new Date(), 0);
    if (key === "last") return taxMonth(new Date(), -1);
    return { from: null, to: null, label: "All time" };
  }

  function openForm(existing) {
    UI.modal({
      title: existing ? "Edit CIS statement" : "Add CIS statement", size: "lg",
      saveLabel: existing ? "Save changes" : "Add statement",
      bodyHTML: `
        <div class="form-grid">
          <div class="field"><label class="field__label">Subcontractor *</label>
            <input class="input" id="z-name" value="${esc((existing && existing.subcontractor) || "")}" placeholder="Name / trading name"></div>
          <div class="field"><label class="field__label">Linked supplier</label>
            <select class="input" id="z-supplier">${supplierOptions(existing && existing.supplierId)}</select></div>
          <div class="field"><label class="field__label">Payment date</label>
            <input class="input" id="z-date" type="date" value="${esc((existing && existing.date) || Fmt.todayISO())}"></div>
          <div class="field"><label class="field__label">UTR</label>
            <input class="input" id="z-utr" value="${esc((existing && existing.utr) || "")}" placeholder="10 digits"></div>
          <div class="field"><label class="field__label">Gross paid (£) *</label>
            <input class="input" id="z-gross" type="number" min="0" step="0.01" value="${(existing && existing.gross) ?? ""}"></div>
          <div class="field"><label class="field__label">Materials (£)</label>
            <input class="input" id="z-mat" type="number" min="0" step="0.01" value="${(existing && existing.materials) ?? ""}"></div>
          <div class="field"><label class="field__label">CIS rate</label>
            <select class="input" id="z-rate">${RATES.map(([v, l]) => `<option value="${v}"${existing && String(existing.rate) === v ? " selected" : (!existing && v === "20" ? " selected" : "")}>${l}</option>`).join("")}</select></div>
          <div class="field"><label class="field__label">Deduction (auto)</label>
            <input class="input" id="z-ded" readonly value=""></div>
          <div class="field"><label class="field__label">Paid to subbie?</label>
            <select class="input" id="z-paid"><option value="no"${existing && existing.paid ? "" : " selected"}>No</option><option value="yes"${existing && existing.paid ? " selected" : ""}>Yes</option></select></div>
        </div>
        <p class="hint hint--block">Deduction is taken on the labour element only: (gross − materials) × rate. Net paid to the subcontractor = gross − deduction.</p>`,
      onSave: (r) => {
        const gross = parseFloat(r.querySelector("#z-gross").value);
        if (isNaN(gross) || gross < 0) { UI.toast("Enter the gross amount", "danger"); return false; }
        const name = r.querySelector("#z-name").value.trim();
        if (!name) { UI.toast("Subcontractor name is required", "danger"); return false; }
        const materials = parseFloat(r.querySelector("#z-mat").value) || 0;
        const rate = parseFloat(r.querySelector("#z-rate").value) || 0;
        const deduction = calcDeduction(gross, materials, rate);
        const d = { subcontractor: name, supplierId: r.querySelector("#z-supplier").value, date: r.querySelector("#z-date").value,
          utr: r.querySelector("#z-utr").value.trim(), gross: r2(gross), materials: r2(materials), rate,
          deduction, net: r2(gross - deduction), paid: r.querySelector("#z-paid").value === "yes" };
        if (existing) { Store.update(COL, existing.id, d); UI.toast("Statement updated", "ok"); }
        else { Store.insert(COL, d); UI.toast("Statement added", "ok"); }
        render(document.getElementById("view-root"));
      },
    });
    const mr = document.getElementById("modal-root");
    const recalc = () => { mr.querySelector("#z-ded").value = Fmt.gbp(calcDeduction(mr.querySelector("#z-gross").value, mr.querySelector("#z-mat").value, mr.querySelector("#z-rate").value)); };
    ["#z-gross", "#z-mat", "#z-rate"].forEach((s) => mr.querySelector(s).addEventListener("input", recalc));
    mr.querySelector("#z-rate").addEventListener("change", recalc); recalc();
  }
  function remove(z) { UI.confirm(`Delete the CIS statement for ${z.subcontractor}?`, () => { Store.destroy(COL, z.id); UI.toast("Deleted", "info"); render(document.getElementById("view-root")); }); }

  const state = { period: "this" };
  function render(root) {
    const all = Store.all(COL).sort((a, b) => (b.date || "").localeCompare(a.date || ""));
    const rng = periodRange(state.period);
    const rows = all.filter((z) => Period.inRange(z.date, rng.from, rng.to));
    const sum = (k) => r2(rows.reduce((s, z) => s + (Number(z[k]) || 0), 0));
    const mtd = (() => { const r = taxMonth(new Date(), 0); return r2(all.filter((z) => Period.inRange(z.date, r.from, r.to)).reduce((s, z) => s + (Number(z.deduction) || 0), 0)); })();

    const pOpts = [["this", "This tax month"], ["last", "Last tax month"], ["all", "All time"]]
      .map(([v, l]) => `<option value="${v}"${state.period === v ? " selected" : ""}>${l}</option>`).join("");

    root.innerHTML = `
      <div class="toolbar">
        <div class="toolbar__left filterbar">
          <select class="input" id="z-period">${pOpts}</select>
          <span class="muted-count num">${rng.from ? rng.label : "All time"}</span>
        </div>
        ${canEdit() ? `<button class="btn btn--primary" id="z-add">＋ Add statement</button>` : ""}
      </div>
      <div class="stat-grid">
        <div class="stat"><div class="stat__label">Gross paid</div><div class="stat__value num">${Fmt.gbp(sum("gross"))}</div><div class="stat__note">this period</div></div>
        <div class="stat"><div class="stat__label">Materials</div><div class="stat__value num">${Fmt.gbp(sum("materials"))}</div><div class="stat__note">excluded from deduction</div></div>
        <div class="stat"><div class="stat__label">CIS deducted</div><div class="stat__value num">${Fmt.gbp(sum("deduction"))}</div><div class="stat__note">payable to HMRC</div></div>
        <div class="stat"><div class="stat__label">Net to subbies</div><div class="stat__value num">${Fmt.gbp(sum("net"))}</div><div class="stat__note">gross − deduction</div></div>
      </div>
      ${rows.length ? `
        <div class="table-wrap"><table class="table">
          <thead><tr><th>Date</th><th>Subcontractor</th><th class="ta-r">Gross</th><th class="ta-r">Materials</th><th class="ta-r">Rate</th><th class="ta-r">Deduction</th><th class="ta-r">Net</th><th>Paid</th>${canEdit() ? `<th class="ta-r">Actions</th>` : ""}</tr></thead>
          <tbody>${rows.map((z) => `
            <tr>
              <td class="num">${Fmt.date(z.date)}</td>
              <td><strong>${esc(z.subcontractor)}</strong>${z.utr ? `<div class="muted-count num">UTR ${esc(z.utr)}</div>` : ""}</td>
              <td class="ta-r num">${Fmt.gbp(z.gross)}</td>
              <td class="ta-r num">${Fmt.gbp(z.materials)}</td>
              <td class="ta-r num">${z.rate}%</td>
              <td class="ta-r num"><strong>${Fmt.gbp(z.deduction)}</strong></td>
              <td class="ta-r num">${Fmt.gbp(z.net)}</td>
              <td>${z.paid ? `<span class="badge badge--ok">Paid</span>` : `<span class="badge badge--warn">Due</span>`}</td>
              ${canEdit() ? `<td class="ta-r nowrap"><button class="btn btn--sm" data-edit="${z.id}">Edit</button><button class="btn btn--sm btn--danger" data-del="${z.id}">Del</button></td>` : ""}
            </tr>`).join("")}</tbody>
          <tfoot><tr class="totals"><td colspan="5">${rows.length} statement${rows.length === 1 ? "" : "s"} · CIS deducted</td><td class="ta-r num">${Fmt.gbp(sum("deduction"))}</td><td colspan="${canEdit() ? 3 : 2}"></td></tr></tfoot>
        </table></div>`
      : `<div class="panel"><div class="panel__body"><div class="empty">
          <svg class="empty__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/></svg>
          <div class="empty__title">No CIS statements ${state.period === "all" ? "yet" : "this period"}</div>
          <div class="empty__text">${canEdit() ? "Record subcontractor payments to track CIS deductions." : "Ask a manager to record CIS statements."}</div>
        </div></div></div>`}
      <p class="hint hint--block">Monthly CIS return is due to HMRC by the 19th. This is an internal record, not a filing — verify against your HMRC CIS account.</p>
    `;
    root.querySelector("#z-period").addEventListener("change", (e) => { state.period = e.target.value; render(root); });
    const add = root.querySelector("#z-add"); if (add) add.addEventListener("click", () => openForm(null));
    root.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => openForm(Store.find(COL, b.dataset.edit))));
    root.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => remove(Store.find(COL, b.dataset.del))));
  }

  Dashboard.addStat(() => {
    const r = taxMonth(new Date(), 0);
    const v = r2(Store.all(COL).filter((z) => Period.inRange(z.date, r.from, r.to)).reduce((s, z) => s + (Number(z.deduction) || 0), 0));
    return { label: "CIS this month", value: Fmt.gbp(v), note: "deducted (tax month)", route: "cis" };
  }, "Manager");

  Modules.section("Tax");
  Modules.register({
    id: "cis", label: "CIS", title: "CIS Deductions", minRole: "Viewer",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/></svg>',
    render,
  });
})();
