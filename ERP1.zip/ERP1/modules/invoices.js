/* ==========================================================================
   modules/invoices.js — Client invoices (Phase 3)
   Thin config over Commercial.docModule. Store collection "invoices".
   Can be generated from an Accepted quote; supports a quick "Mark paid".
   Shows bank/payment details on the PDF.
   ========================================================================== */
(() => {
  "use strict";

  Commercial.docModule({
    id: "invoices", label: "Invoices", title: "Invoices", noun: "invoice",
    collection: "invoices", prefix: "INV", docTitle: "INVOICE",
    minRole: "Viewer", editRole: "Manager",
    party: { coll: "clients", label: "Client", route: "clients" },
    dateLabel: "Issued", date2: { label: "Due date" },
    showBank: true,
    statuses: [
      { value: "Draft", badge: "muted" },
      { value: "Sent", badge: "warn" },
      { value: "Paid", badge: "ok" },
      { value: "Overdue", badge: "danger" },
    ],
    defaultStatus: "Draft",
    quickStatus: { to: "Paid", label: "Mark paid", when: (d) => d.status !== "Paid" },
    // generate a new invoice from an accepted quote (copies client + lines)
    newFrom: {
      coll: "quotes", label: "quote", partyColl: "clients",
      filter: (q) => q.status === "Accepted",
      map: (q) => ({
        partyId: q.partyId, siteId: q.siteId,
        items: JSON.parse(JSON.stringify(q.items || [])),
        vatRate: q.vatRate, notes: q.notes,
      }),
    },
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2h12v20l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6"/></svg>',
    // dashboard: outstanding (unpaid) invoice value
    stat: () => {
      const unpaid = Store.all("invoices").filter((i) => i.status !== "Paid" && i.status !== "Draft");
      const overdue = unpaid.filter((i) => i.status === "Overdue").length;
      const val = unpaid.reduce((s, i) => s + Commercial.Money.totals(i.items, i.vatRate).total, 0);
      return { label: "Outstanding", value: Fmt.gbp(val), note: overdue ? `${overdue} overdue` : `${unpaid.length} unpaid`, route: "invoices" };
    },
  });
})();
