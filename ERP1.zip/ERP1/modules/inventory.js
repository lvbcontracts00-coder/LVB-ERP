/* ==========================================================================
   modules/inventory.js — Stock management (Phase 4)
   Store collections "inventory" (one stock line per material) and
   "stockMovements" (the in/out audit trail).

   inventory record:      { id, materialId, qtyOnHand, reorderLevel, location, notes }
   stockMovements record: { id, materialId, type:"in"|"out", qty, siteId, date,
                            unitCost, value, note }

   Receiving adds stock; issuing to a project removes stock and books a cost to
   that site. "Issue to project" movements are the owned-stock material cost the
   profit module adds to project cost (separate from bought-for-job POs, so the
   two never double-count). Stock is valued at the material's catalogue cost.
   ========================================================================== */
(() => {
  "use strict";
  const COL = "inventory", MOVES = "stockMovements";
  const canEdit = () => Auth.can("Manager");

  const material = (id) => Store.find("materials", id) || null;
  const matName = (id) => (material(id) || {}).name || "Unknown material";
  const matUnit = (id) => (material(id) || {}).unit || "";
  const matCost = (id) => Number((material(id) || {}).unitCost) || 0;
  const siteName = (id) => id ? ((Store.find("sites", id) || {}).name || "Unknown") : "—";
  const isLow = (r) => Number(r.reorderLevel) > 0 && Number(r.qtyOnHand) <= Number(r.reorderLevel);

  function materialOptions(sel) {
    const list = Store.all("materials");
    if (!list.length) return `<option value="">No materials in catalogue</option>`;
    return list.map((m) => `<option value="${m.id}"${m.id === sel ? " selected" : ""}>${esc(m.name)} (${esc(m.unit)})</option>`).join("");
  }
  function siteOptions(sel) {
    return `<option value="">— select project —</option>` +
      Store.all("sites").map((s) => `<option value="${s.id}"${s.id === sel ? " selected" : ""}>${esc(s.name)}</option>`).join("");
  }

  /* ---- add / edit a stock line ----------------------------------------- */
  function openForm(existing) {
    if (!Store.all("materials").length) { UI.toast("Add a material to the catalogue first", "danger"); Router.navigate("materials"); return; }
    UI.modal({
      title: existing ? "Edit stock line" : "Add stock line", size: "lg",
      saveLabel: existing ? "Save changes" : "Add stock",
      bodyHTML: `
        <div class="form-grid">
          <div class="field span-2"><label class="field__label">Material *</label>
            <select class="input" id="i-material"${existing ? " disabled" : ""}>${materialOptions(existing && existing.materialId)}</select></div>
          <div class="field"><label class="field__label">Quantity on hand</label>
            <input class="input" id="i-qty" type="number" min="0" step="0.01" value="${existing ? (existing.qtyOnHand ?? 0) : 0}"></div>
          <div class="field"><label class="field__label">Reorder level</label>
            <input class="input" id="i-reorder" type="number" min="0" step="0.01" value="${existing ? (existing.reorderLevel ?? 0) : 0}"></div>
          <div class="field span-2"><label class="field__label">Location</label>
            <input class="input" id="i-loc" value="${esc((existing && existing.location) || "")}" placeholder="e.g. Yard rack B / Van 2"></div>
          <div class="field span-2"><label class="field__label">Notes</label>
            <textarea class="input" id="i-notes" rows="2">${esc((existing && existing.notes) || "")}</textarea></div>
        </div>`,
      onSave: (r) => {
        const materialId = existing ? existing.materialId : r.querySelector("#i-material").value;
        if (!materialId) { UI.toast("Pick a material", "danger"); return false; }
        const d = {
          materialId,
          qtyOnHand: parseFloat(r.querySelector("#i-qty").value) || 0,
          reorderLevel: parseFloat(r.querySelector("#i-reorder").value) || 0,
          location: r.querySelector("#i-loc").value.trim(),
          notes: r.querySelector("#i-notes").value.trim(),
        };
        if (existing) { Store.update(COL, existing.id, d); UI.toast("Stock line updated", "ok"); }
        else { Store.insert(COL, d); UI.toast("Stock line added", "ok"); }
        render(document.getElementById("view-root"));
      },
    });
  }

  /* ---- receive (+) / issue (−) ----------------------------------------- */
  function receive(item) {
    UI.modal({
      title: `Receive stock · ${matName(item.materialId)}`, saveLabel: "Receive",
      bodyHTML: `
        <div class="form-grid">
          <div class="field"><label class="field__label">Quantity in *</label>
            <input class="input" id="r-qty" type="number" min="0.01" step="0.01" placeholder="0"></div>
          <div class="field"><label class="field__label">Date</label>
            <input class="input" id="r-date" type="date" value="${Fmt.todayISO()}"></div>
          <div class="field span-2"><label class="field__label">Note</label>
            <input class="input" id="r-note" placeholder="e.g. PO-0007 delivery"></div>
        </div>`,
      onSave: (r) => {
        const qty = parseFloat(r.querySelector("#r-qty").value);
        if (isNaN(qty) || qty <= 0) { UI.toast("Enter a quantity", "danger"); return false; }
        const cost = matCost(item.materialId);
        Store.update(COL, item.id, { qtyOnHand: Number(item.qtyOnHand || 0) + qty });
        Store.insert(MOVES, { materialId: item.materialId, type: "in", qty, siteId: "",
          date: r.querySelector("#r-date").value || Fmt.todayISO(), unitCost: cost, value: Money(qty * cost),
          note: r.querySelector("#r-note").value.trim() });
        UI.toast(`Received ${qty} ${matUnit(item.materialId)}`, "ok");
        render(document.getElementById("view-root"));
      },
    });
  }
  function issue(item) {
    if (!Store.all("sites").length) { UI.toast("Add a project (site) first", "danger"); Router.navigate("sites"); return; }
    UI.modal({
      title: `Issue to project · ${matName(item.materialId)}`, saveLabel: "Issue",
      bodyHTML: `
        <p class="hint" style="margin-bottom:12px">On hand: <strong>${Fmt.hours(item.qtyOnHand)} ${esc(matUnit(item.materialId))}</strong> · valued at ${Fmt.gbp(matCost(item.materialId))}/${esc(matUnit(item.materialId))}</p>
        <div class="form-grid">
          <div class="field"><label class="field__label">Quantity out *</label>
            <input class="input" id="o-qty" type="number" min="0.01" step="0.01" placeholder="0"></div>
          <div class="field"><label class="field__label">Date</label>
            <input class="input" id="o-date" type="date" value="${Fmt.todayISO()}"></div>
          <div class="field span-2"><label class="field__label">Project *</label>
            <select class="input" id="o-site">${siteOptions()}</select></div>
          <div class="field span-2"><label class="field__label">Note</label>
            <input class="input" id="o-note" placeholder="e.g. first-fix joinery"></div>
        </div>`,
      onSave: (r) => {
        const qty = parseFloat(r.querySelector("#o-qty").value);
        if (isNaN(qty) || qty <= 0) { UI.toast("Enter a quantity", "danger"); return false; }
        if (qty > Number(item.qtyOnHand || 0)) { UI.toast("Not enough stock on hand", "danger"); return false; }
        const siteId = r.querySelector("#o-site").value;
        if (!siteId) { UI.toast("Pick a project to book the cost to", "danger"); return false; }
        const cost = matCost(item.materialId);
        Store.update(COL, item.id, { qtyOnHand: Number(item.qtyOnHand || 0) - qty });
        Store.insert(MOVES, { materialId: item.materialId, type: "out", qty, siteId,
          date: r.querySelector("#o-date").value || Fmt.todayISO(), unitCost: cost, value: Money(qty * cost),
          note: r.querySelector("#o-note").value.trim() });
        UI.toast(`Issued ${qty} ${matUnit(item.materialId)} → ${siteName(siteId)}`, "ok");
        render(document.getElementById("view-root"));
      },
    });
  }
  const Money = (n) => Math.round((Number(n) || 0) * 100) / 100;

  function remove(item) {
    UI.confirm(`Remove the stock line for ${matName(item.materialId)}? Movement history is kept.`, () => {
      Store.destroy(COL, item.id); UI.toast("Stock line removed", "info");
      render(document.getElementById("view-root"));
    });
  }

  /* ---- render ----------------------------------------------------------- */
  let filt = "all"; // all | low
  function render(root) {
    let items = Store.all(COL);
    items.sort((a, b) => matName(a.materialId).localeCompare(matName(b.materialId)));
    const lowCount = items.filter(isLow).length;
    const totalValue = items.reduce((s, it) => s + Money(Number(it.qtyOnHand || 0) * matCost(it.materialId)), 0);
    const rows = items.filter((it) => filt === "all" || isLow(it));

    const fOpts = [["all", "All stock"], ["low", "Low stock"]]
      .map(([v, l]) => `<option value="${v}"${filt === v ? " selected" : ""}>${l}</option>`).join("");

    root.innerHTML = `
      <div class="toolbar">
        <div class="toolbar__left filterbar">
          <select class="input" id="i-filter">${fOpts}</select>
          <span class="muted-count num">${Fmt.gbp(totalValue)} stock value</span>
          ${lowCount ? `<span class="badge badge--warn">${lowCount} low</span>` : ""}
        </div>
        ${canEdit() ? `<button class="btn btn--primary" id="i-add">＋ Add stock line</button>` : ""}
      </div>
      ${rows.length ? `
        <div class="table-wrap"><table class="table">
          <thead><tr><th>Material</th><th>Location</th><th class="ta-r">On hand</th><th class="ta-r">Reorder</th><th class="ta-r">Value</th><th>Status</th>${canEdit() ? `<th class="ta-r">Actions</th>` : ""}</tr></thead>
          <tbody>${rows.map((it) => {
            const cost = matCost(it.materialId), val = Money(Number(it.qtyOnHand || 0) * cost);
            return `<tr>
              <td><strong>${esc(matName(it.materialId))}</strong>${it.notes ? `<div class="muted-count">${esc(it.notes)}</div>` : ""}</td>
              <td>${esc(it.location || "—")}</td>
              <td class="ta-r num">${Fmt.hours(it.qtyOnHand)} ${esc(matUnit(it.materialId))}</td>
              <td class="ta-r num">${Number(it.reorderLevel) ? Fmt.hours(it.reorderLevel) : "—"}</td>
              <td class="ta-r num">${Fmt.gbp(val)}</td>
              <td>${isLow(it) ? `<span class="badge badge--warn">Low</span>` : `<span class="badge badge--ok">OK</span>`}</td>
              ${canEdit() ? `<td class="ta-r nowrap">
                <button class="btn btn--sm" data-recv="${it.id}">Receive</button>
                <button class="btn btn--sm" data-issue="${it.id}">Issue</button>
                <button class="btn btn--sm" data-edit="${it.id}">Edit</button>
                <button class="btn btn--sm btn--danger" data-del="${it.id}">Del</button></td>` : ""}
            </tr>`; }).join("")}</tbody>
          <tfoot><tr class="totals"><td colspan="4">${items.length} stock line${items.length === 1 ? "" : "s"}</td><td class="ta-r num">${Fmt.gbp(totalValue)}</td><td colspan="${canEdit() ? 2 : 1}"></td></tr></tfoot>
        </table></div>`
      : `<div class="panel"><div class="panel__body"><div class="empty">
          <svg class="empty__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="8" width="18" height="12" rx="1"/><path d="M3 8l3-4h12l3 4M12 8v12"/></svg>
          <div class="empty__title">${items.length === 0 ? "No stock tracked yet" : "No low-stock items"}</div>
          <div class="empty__text">${items.length === 0 ? (canEdit() ? "Add a stock line for a catalogue material." : "Ask a manager to set up stock.") : "Everything is above its reorder level."}</div>
        </div></div></div>`}
    `;
    root.querySelector("#i-filter").addEventListener("change", (e) => { filt = e.target.value; render(root); });
    const add = root.querySelector("#i-add"); if (add) add.addEventListener("click", () => openForm(null));
    root.querySelectorAll("[data-recv]").forEach((b) => b.addEventListener("click", () => receive(Store.find(COL, b.dataset.recv))));
    root.querySelectorAll("[data-issue]").forEach((b) => b.addEventListener("click", () => issue(Store.find(COL, b.dataset.issue))));
    root.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => openForm(Store.find(COL, b.dataset.edit))));
    root.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => remove(Store.find(COL, b.dataset.del))));
  }

  Dashboard.addStat(() => {
    const items = Store.all(COL);
    const low = items.filter(isLow).length;
    return { label: "Low stock", value: String(low), note: low ? "below reorder level" : "all stocked", route: "inventory" };
  });

  Modules.register({
    id: "inventory", label: "Inventory", title: "Stock / Inventory", minRole: "Viewer",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="8" width="18" height="12" rx="1"/><path d="M3 8l3-4h12l3 4M12 8v12"/></svg>',
    render,
  });
})();
