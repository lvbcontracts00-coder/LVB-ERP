/* ==========================================================================
   modules/sites.js — Site management (Phase 2)
   Store collection "sites".
   Record: { id, name, address, client, status, startDate, manager, notes }
   ========================================================================== */
(() => {
  "use strict";
  const COL = "sites";
  const STATUSES = ["Active", "On hold", "Completed"];
  const badgeKind = { "Active": "ok", "On hold": "warn", "Completed": "muted" };

  const canEdit = () => Auth.can("Manager");
  const opts = (list, sel) => list.map((o) => `<option value="${esc(o)}"${o === sel ? " selected" : ""}>${esc(o)}</option>`).join("");

  function form(s) {
    s = s || {}; // null-safe: JS default params apply to undefined only, not null
    return `
      <div class="form-grid">
        <div class="field span-2"><label class="field__label">Site name *</label>
          <input class="input" id="s-name" value="${esc(s.name || "")}" placeholder="e.g. 14 Oakwood Rd Extension"></div>
        <div class="field span-2"><label class="field__label">Address</label>
          <input class="input" id="s-address" value="${esc(s.address || "")}" placeholder="Street, area, postcode"></div>
        <div class="field"><label class="field__label">Client</label>
          <input class="input" id="s-client" value="${esc(s.client || "")}" placeholder="Client name"></div>
        <div class="field"><label class="field__label">Status</label>
          <select class="input" id="s-status">${opts(STATUSES, s.status || "Active")}</select></div>
        <div class="field"><label class="field__label">Site manager</label>
          <input class="input" id="s-manager" value="${esc(s.manager || "")}" placeholder="Optional"></div>
        <div class="field"><label class="field__label">Start date</label>
          <input class="input" id="s-start" type="date" value="${esc(s.startDate || "")}"></div>
        <div class="field span-2"><label class="field__label">Notes</label>
          <textarea class="input" id="s-notes" rows="2" placeholder="Optional">${esc(s.notes || "")}</textarea></div>
      </div>`;
  }

  function read(rootEl) {
    return {
      name: rootEl.querySelector("#s-name").value.trim(),
      address: rootEl.querySelector("#s-address").value.trim(),
      client: rootEl.querySelector("#s-client").value.trim(),
      status: rootEl.querySelector("#s-status").value,
      manager: rootEl.querySelector("#s-manager").value.trim(),
      startDate: rootEl.querySelector("#s-start").value,
      notes: rootEl.querySelector("#s-notes").value.trim(),
    };
  }

  function openForm(existing) {
    UI.modal({
      title: existing ? "Edit site" : "Add site",
      size: "lg",
      bodyHTML: form(existing),
      saveLabel: existing ? "Save changes" : "Add site",
      onSave: (rootEl) => {
        const data = read(rootEl);
        if (!data.name) { UI.toast("Site name is required", "danger"); return false; }
        if (existing) { Store.update(COL, existing.id, data); UI.toast("Site updated", "ok"); }
        else { Store.insert(COL, data); UI.toast("Site added", "ok"); }
        render(document.getElementById("view-root"));
      },
    });
  }

  function remove(s) {
    UI.confirm(`Delete ${s.name}? Timesheets linked to it will keep a reference but show "Unknown site".`, () => {
      Store.destroy(COL, s.id);
      UI.toast("Site deleted", "info");
      render(document.getElementById("view-root"));
    });
  }

  let term = "";

  function render(root) {
    const all = Store.all(COL);
    const rows = all.filter((s) => !term || (s.name + " " + s.client + " " + s.address).toLowerCase().includes(term.toLowerCase()));

    root.innerHTML = `
      <div class="toolbar">
        <div class="toolbar__left">
          <input class="input input--search" id="s-search" placeholder="Search sites…" value="${esc(term)}">
          <span class="muted-count num">${all.length} total</span>
        </div>
        ${canEdit() ? `<button class="btn btn--primary" id="s-add">＋ Add site</button>` : ""}
      </div>

      ${rows.length ? `
        <div class="table-wrap"><table class="table">
          <thead><tr>
            <th>Site</th><th>Address</th><th>Client</th><th>Started</th><th>Status</th>
            ${canEdit() ? `<th class="ta-r">Actions</th>` : ""}
          </tr></thead>
          <tbody>
            ${rows.map((s) => `
              <tr>
                <td><strong>${esc(s.name)}</strong></td>
                <td>${esc(s.address || "—")}</td>
                <td>${esc(s.client || "—")}</td>
                <td class="num">${Fmt.date(s.startDate)}</td>
                <td><span class="badge badge--${badgeKind[s.status] || "muted"}">${esc(s.status)}</span></td>
                ${canEdit() ? `<td class="ta-r nowrap">
                  <button class="btn btn--sm" data-edit="${s.id}">Edit</button>
                  <button class="btn btn--sm btn--danger" data-del="${s.id}">Delete</button></td>` : ""}
              </tr>`).join("")}
          </tbody>
        </table></div>`
      : `<div class="panel"><div class="panel__body"><div class="empty">
          <svg class="empty__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 21V8l9-5 9 5v13"/><path d="M9 21v-6h6v6"/></svg>
          <div class="empty__title">${all.length === 0 ? "No sites yet" : "No matches"}</div>
          <div class="empty__text">${all.length === 0 ? (canEdit() ? "Add your first site." : "Ask a manager to add sites.") : "Try a different search."}</div>
        </div></div></div>`}
    `;

    const search = root.querySelector("#s-search");
    search.addEventListener("input", () => { term = search.value; render(root);
      const s = document.getElementById("s-search"); if (s) { s.focus(); s.setSelectionRange(s.value.length, s.value.length); } });
    const add = root.querySelector("#s-add");
    if (add) add.addEventListener("click", () => openForm(null));
    root.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => openForm(Store.find(COL, b.dataset.edit))));
    root.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => remove(Store.find(COL, b.dataset.del))));
  }

  Dashboard.addStat(() => {
    const active = Store.all(COL).filter((s) => s.status === "Active").length;
    return { label: "Active sites", value: String(active), note: `${Store.all(COL).length} total`, route: "sites" };
  });

  Modules.register({
    id: "sites", label: "Projects", title: "Projects", minRole: "Viewer",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 21V8l9-5 9 5v13"/><path d="M9 21v-6h6v6"/></svg>',
    render,
  });
})();
