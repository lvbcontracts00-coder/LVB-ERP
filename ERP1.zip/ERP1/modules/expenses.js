/* ==========================================================================
   modules/expenses.js — Employee expenses / reimbursements (Phase 3.5)
   Store collection "expenses". Receipts stored separately under
   "receipt:<id>" (kept out of the main collection to isolate large blobs).

   Record: { id, date, workerId, siteId (project), supplierId, description,
             amount, hasReceipt, reimbursed, reimbursementDate }

   Feeds Finance.projectCost() → project costs, profitability, dashboard.
   NOTE: receipts are downscaled to a small JPEG client-side. localStorage is
   ~5MB total, so this suits a handful of receipts, not a document archive —
   a real deployment would store files on a server/object store.
   ========================================================================== */
(() => {
  "use strict";
  const COL = "expenses";
  const canEdit = () => Auth.can("Manager");

  const workerName = (id) => (Store.find("workers", id) || {}).name || "—";
  const siteName = (id) => id ? ((Store.find("sites", id) || {}).name || "Unknown") : "—";
  const supplierName = (id) => id ? ((Store.find("suppliers", id) || {}).name || "Unknown") : "—";

  /* receipt image compression now lives in Util.compressImage (Phase 6 dedup) */

  /* ---- form -------------------------------------------------------------- */
  function workerOptions(sel) {
    return Store.all("workers").filter((w) => w.status === "Active" || w.id === sel)
      .map((w) => `<option value="${w.id}"${w.id === sel ? " selected" : ""}>${esc(w.name)}</option>`).join("");
  }
  function siteOptions(sel) {
    return `<option value="">— none —</option>` + Store.all("sites").map((s) => `<option value="${s.id}"${s.id === sel ? " selected" : ""}>${esc(s.name)}</option>`).join("");
  }
  function supplierOptions(sel) {
    return `<option value="">— none —</option>` + Store.all("suppliers").map((s) => `<option value="${s.id}"${s.id === sel ? " selected" : ""}>${esc(s.name)}</option>`).join("");
  }

  function openForm(existing) {
    if (!Store.all("workers").length) { UI.toast("Add a worker first", "danger"); Router.navigate("workers"); return; }

    let pendingReceipt = null;          // new dataURL captured this session
    let removeReceipt = false;          // user cleared an existing receipt
    const hasExisting = existing && existing.hasReceipt;

    UI.modal({
      title: existing ? "Edit expense" : "Add expense", size: "lg",
      saveLabel: existing ? "Save changes" : "Add expense",
      bodyHTML: `
        <div class="form-grid">
          <div class="field"><label class="field__label">Date *</label>
            <input class="input" id="x-date" type="date" value="${esc((existing && existing.date) || Fmt.todayISO())}"></div>
          <div class="field"><label class="field__label">Worker (to reimburse) *</label>
            <select class="input" id="x-worker">${workerOptions(existing && existing.workerId)}</select></div>
          <div class="field"><label class="field__label">Project</label>
            <select class="input" id="x-site">${siteOptions(existing && existing.siteId)}</select></div>
          <div class="field"><label class="field__label">Supplier</label>
            <select class="input" id="x-supplier">${supplierOptions(existing && existing.supplierId)}</select></div>
          <div class="field"><label class="field__label">Amount (£) *</label>
            <input class="input" id="x-amount" type="number" min="0" step="0.01" value="${(existing && existing.amount) ?? ""}" placeholder="0.00"></div>
          <div class="field"><label class="field__label">Reimbursed?</label>
            <select class="input" id="x-reimb">
              <option value="no"${existing && existing.reimbursed ? "" : " selected"}>No — pending</option>
              <option value="yes"${existing && existing.reimbursed ? " selected" : ""}>Yes — paid</option>
            </select></div>
          <div class="field" id="x-rdate-wrap"><label class="field__label">Reimbursement date</label>
            <input class="input" id="x-rdate" type="date" value="${esc((existing && existing.reimbursementDate) || "")}"></div>
          <div class="field"></div>
          <div class="field span-2"><label class="field__label">Description</label>
            <input class="input" id="x-desc" value="${esc((existing && existing.description) || "")}" placeholder="e.g. Timber & fixings for first fix"></div>
          <div class="field span-2"><label class="field__label">Receipt (image)</label>
            <div class="receipt-input">
              <input type="file" id="x-file" accept="image/*">
              <div id="x-rec-state" class="hint">${hasExisting ? "Current receipt attached." : "No receipt."}</div>
              <img id="x-rec-prev" class="receipt-prev" alt="" hidden>
              <button type="button" class="btn btn--sm btn--danger" id="x-rec-clear"${hasExisting ? "" : " hidden"}>Remove receipt</button>
            </div></div>
        </div>`,
      onSave: (r) => {
        const amount = parseFloat(r.querySelector("#x-amount").value);
        if (isNaN(amount) || amount <= 0) { UI.toast("Enter a valid amount", "danger"); return false; }
        const reimbursed = r.querySelector("#x-reimb").value === "yes";
        const data = {
          date: r.querySelector("#x-date").value,
          workerId: r.querySelector("#x-worker").value,
          siteId: r.querySelector("#x-site").value,
          supplierId: r.querySelector("#x-supplier").value,
          description: r.querySelector("#x-desc").value.trim(),
          amount, reimbursed,
          reimbursementDate: reimbursed ? (r.querySelector("#x-rdate").value || Fmt.todayISO()) : "",
        };

        // persist record first (small), then handle the receipt blob
        let rec;
        if (existing) { rec = Store.update(COL, existing.id, data); }
        else { rec = Store.insert(COL, { ...data, hasReceipt: false }); }

        const key = "receipt:" + rec.id;
        if (pendingReceipt) {
          const ok = Store.write(key, pendingReceipt);
          if (!ok) UI.toast("Expense saved, but receipt was too large for local storage", "danger");
          Store.update(COL, rec.id, { hasReceipt: ok });
        } else if (removeReceipt && hasExisting) {
          Store.remove(key); Store.update(COL, rec.id, { hasReceipt: false });
        }

        UI.toast(existing ? "Expense updated" : "Expense added", "ok");
        render(document.getElementById("view-root"));
      },
    });

    // ---- wire dynamic bits in the modal ----
    const mr = document.getElementById("modal-root");
    const toggleRDate = () => { mr.querySelector("#x-rdate-wrap").style.opacity = mr.querySelector("#x-reimb").value === "yes" ? "1" : "0.45"; mr.querySelector("#x-rdate").disabled = mr.querySelector("#x-reimb").value !== "yes"; };
    mr.querySelector("#x-reimb").addEventListener("change", toggleRDate); toggleRDate();

    mr.querySelector("#x-file").addEventListener("change", async (e) => {
      const f = e.target.files[0]; if (!f) return;
      try {
        pendingReceipt = await Util.compressImage(f, { max: 1024, quality: 0.6 }); removeReceipt = false;
        const prev = mr.querySelector("#x-rec-prev"); prev.src = pendingReceipt; prev.hidden = false;
        mr.querySelector("#x-rec-state").textContent = "New receipt ready (" + Math.round(pendingReceipt.length / 1024) + " KB).";
        mr.querySelector("#x-rec-clear").hidden = false;
      } catch { UI.toast("Could not read that image", "danger"); }
    });
    mr.querySelector("#x-rec-clear").addEventListener("click", () => {
      pendingReceipt = null; removeReceipt = true;
      const prev = mr.querySelector("#x-rec-prev"); prev.hidden = true; prev.src = "";
      mr.querySelector("#x-file").value = "";
      mr.querySelector("#x-rec-state").textContent = "Receipt will be removed on save.";
      mr.querySelector("#x-rec-clear").hidden = true;
    });
  }

  function viewReceipt(id) {
    const data = Store.read("receipt:" + id);
    if (!data) { UI.toast("Receipt not found", "danger"); return; }
    UI.modal({ title: "Receipt", size: "lg", bodyHTML: `<img src="${data}" class="receipt-full" alt="Receipt">` });
  }

  function reimburseNow(e) {
    Store.update(COL, e.id, { reimbursed: true, reimbursementDate: Fmt.todayISO() });
    UI.toast("Marked reimbursed", "ok");
    render(document.getElementById("view-root"));
  }

  function remove(e) {
    UI.confirm("Delete this expense? Its receipt will also be removed.", () => {
      Store.remove("receipt:" + e.id); Store.destroy(COL, e.id);
      UI.toast("Expense deleted", "info");
      render(document.getElementById("view-root"));
    });
  }

  /* ---- render ------------------------------------------------------------ */
  let filt = "all"; // all | pending | done

  function render(root) {
    const all = Store.all(COL).sort((a, b) => (b.date || "").localeCompare(a.date || ""));
    const rows = all.filter((e) => filt === "all" || (filt === "pending" ? !e.reimbursed : e.reimbursed));
    const pendingTotal = all.filter((e) => !e.reimbursed).reduce((s, e) => s + (Number(e.amount) || 0), 0);
    const shownTotal = rows.reduce((s, e) => s + (Number(e.amount) || 0), 0);

    const fOpts = [["all", "All"], ["pending", "To reimburse"], ["done", "Reimbursed"]]
      .map(([v, l]) => `<option value="${v}"${filt === v ? " selected" : ""}>${l}</option>`).join("");

    root.innerHTML = `
      <div class="toolbar">
        <div class="toolbar__left filterbar">
          <select class="input" id="x-filter">${fOpts}</select>
          <span class="muted-count num">${Fmt.gbp(pendingTotal)} to reimburse</span>
        </div>
        ${canEdit() ? `<button class="btn btn--primary" id="x-add">＋ Add expense</button>` : ""}
      </div>
      ${rows.length ? `
        <div class="table-wrap"><table class="table">
          <thead><tr><th>Date</th><th>Worker</th><th>Project</th><th>Supplier</th><th>Description</th><th class="ta-r">Amount</th><th>Receipt</th><th>Status</th>${canEdit() ? `<th class="ta-r">Actions</th>` : ""}</tr></thead>
          <tbody>${rows.map((e) => `
            <tr>
              <td class="num">${Fmt.date(e.date)}</td>
              <td><strong>${esc(workerName(e.workerId))}</strong></td>
              <td>${esc(siteName(e.siteId))}</td>
              <td>${esc(supplierName(e.supplierId))}</td>
              <td>${esc(e.description || "—")}</td>
              <td class="ta-r num">${Fmt.gbp(e.amount)}</td>
              <td>${e.hasReceipt ? `<button class="btn btn--sm" data-rec="${e.id}">📎 View</button>` : `<span class="muted-count">—</span>`}</td>
              <td>${e.reimbursed ? `<span class="badge badge--ok">Reimbursed</span><div class="muted-count num">${Fmt.dayMon(e.reimbursementDate)}</div>` : `<span class="badge badge--warn">Pending</span>`}</td>
              ${canEdit() ? `<td class="ta-r nowrap">
                ${!e.reimbursed ? `<button class="btn btn--sm" data-reimb="${e.id}">Reimburse</button>` : ""}
                <button class="btn btn--sm" data-edit="${e.id}">Edit</button>
                <button class="btn btn--sm btn--danger" data-del="${e.id}">Del</button></td>` : ""}
            </tr>`).join("")}</tbody>
          <tfoot><tr class="totals"><td colspan="5">${rows.length} expense${rows.length === 1 ? "" : "s"}</td><td class="ta-r num">${Fmt.gbp(shownTotal)}</td><td colspan="${canEdit() ? 3 : 2}"></td></tr></tfoot>
        </table></div>`
      : `<div class="panel"><div class="panel__body"><div class="empty">
          <svg class="empty__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 4h16v16l-2-1.5L16 20l-2-1.5L12 20l-2-1.5L8 20l-2-1.5L4 20z"/><path d="M8 9h8M8 13h5"/></svg>
          <div class="empty__title">No expenses ${filt === "all" ? "yet" : "in this view"}</div>
          <div class="empty__text">${canEdit() ? "Log a worker expense to start tracking reimbursements." : "Ask a manager to log expenses."}</div>
        </div></div></div>`}
    `;

    root.querySelector("#x-filter").addEventListener("change", (e) => { filt = e.target.value; render(root); });
    const add = root.querySelector("#x-add"); if (add) add.addEventListener("click", () => openForm(null));
    root.querySelectorAll("[data-rec]").forEach((b) => b.addEventListener("click", () => viewReceipt(b.dataset.rec)));
    root.querySelectorAll("[data-reimb]").forEach((b) => b.addEventListener("click", () => reimburseNow(Store.find(COL, b.dataset.reimb))));
    root.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => openForm(Store.find(COL, b.dataset.edit))));
    root.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => remove(Store.find(COL, b.dataset.del))));
  }

  /* ---- dashboard stat ---------------------------------------------------- */
  Dashboard.addStat(() => {
    const pending = Store.all(COL).filter((e) => !e.reimbursed);
    const val = pending.reduce((s, e) => s + (Number(e.amount) || 0), 0);
    return { label: "To reimburse", value: Fmt.gbp(val), note: `${pending.length} pending`, route: "expenses" };
  });

  Modules.section("Finance");
  Modules.register({
    id: "expenses", label: "Expenses", title: "Employee Expenses", minRole: "Viewer",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16v15l-2-1.3L16 19l-2-1.3L12 19l-2-1.3L8 19l-2-1.3L4 19z"/><path d="M8 9h8M8 13h6"/></svg>',
    render,
  });
})();
