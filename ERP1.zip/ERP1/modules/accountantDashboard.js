/* ==========================================================================
   modules/accountantDashboard.js — Accountant home screen (Phase 6)

   The dedicated landing screen for the accountant. Opens straight onto the
   CURRENT PAYROLL PERIOD (the fortnight, matching the Payroll module's grid)
   and surfaces the figures and actions the accountant touches every day.

   CARDS (all scoped to / linked to existing modules — single source of truth):
     · Workers This Period      — distinct workers with hours this fortnight
     · Total Hours              — hours logged this fortnight
     · Payroll Cost             — gross pay this fortnight (hours × rate, OT×1.5)
     · Supplier Costs           — supplier-invoice spend (Unpaid/Paid) this period
     · Outstanding Supplier Inv — unpaid supplier invoices (gross balance)
     · Outstanding Client Inv   — unpaid client invoices (total − payments)
     · Current Project Profit   — Finance.projectPnL (revenue − cost) all-time

   QUICK ACTIONS (done from here, no hunting through the menu):
     · Enter Weekly Labour      → Labour Sheet
     · Process Payroll          → Payroll (Fortnight)
     · Add Supplier Invoice     → opens the Supplier Invoice Register entry form
     · Generate Payroll Report  → PDF for the current period (print/save)
     · Generate Supplier Report → opens the Supplier Invoice reports (weekly/period/outstanding)

   Manager+ only (financial data), matching Payroll. The standard Dashboard is
   left intact and still reachable from the sidebar.
   ========================================================================== */
(() => {
  "use strict";

  const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
  const FIN = (typeof Finance !== "undefined") ? Finance : null;   // global lexical binding
  const OT = (FIN && FIN.OT) || 1.5;
  const docTotal = (d) => Commercial.Money.totals(d.items, d.vatRate).total;
  const inR = (date, f, t) => Period.inRange((date || "").slice(0, 10), f, t);
  const siteName = (id) => id ? ((Store.find("sites", id) || {}).name || "Unknown site") : "Unallocated";
  const supplierName = (id) => id ? ((Store.find("suppliers", id) || {}).name || "Unknown supplier") : "—";

  /* current pay period = the fortnight, identical to Payroll's grid ------- */
  const period = () => Period.payPeriodRange(0); // { from, to, label }

  /* ---- payroll figures for the current period ---------------------------- */
  function payrollCalc() {
    const { from, to, label } = period();
    const sheets = Store.all("timesheets").filter((x) => inR(x.date, from, to));
    const byWorker = new Map(), bySite = new Map();
    let totalHours = 0, gross = 0;

    sheets.forEach((x) => {
      const w = Store.find("workers", x.workerId); if (!w) return;
      const rate = Number(w.rate) || 0;
      const reg = Number(x.hours) || 0, ot = Number(x.overtime) || 0, all = reg + ot;
      const cost = reg * rate + ot * rate * OT;
      totalHours += all; gross += cost;

      const cw = byWorker.get(w.id) || { name: w.name, trade: w.trade || "", rate, hours: 0, gross: 0 };
      cw.hours += all; cw.gross += cost; byWorker.set(w.id, cw);

      const sid = x.siteId || "";
      const cs = bySite.get(sid) || { name: siteName(x.siteId), hours: 0, cost: 0 };
      cs.hours += all; cs.cost += cost; bySite.set(sid, cs);
    });

    const workers = [...byWorker.values()].sort((a, b) => b.gross - a.gross);
    const projects = [...bySite.values()].sort((a, b) => b.cost - a.cost);
    return {
      from, to, label, workers, projects,
      workerCount: workers.filter((w) => w.hours > 0).length,
      totalHours: r2(totalHours), gross: r2(gross),
    };
  }

  /* ---- supplier figures (from the Supplier Invoice Register) ------------- */
  // The accountant's actual supplier costs: committed = Unpaid/Paid, gross.
  // Drafts excluded. Replaces the earlier PO-based estimate.
  const supplierCostPeriod = () => {
    const { from, to } = period();
    return r2(Store.all("supplierInvoices")
      .filter((s) => (s.status === "Unpaid" || s.status === "Paid") && inR(s.date, from, to))
      .reduce((sum, s) => sum + (Number(s.gross) || 0), 0));
  };
  function outstandingSuppliers() {
    const list = Store.all("supplierInvoices").filter((s) => s.status === "Unpaid");
    return { count: list.length, value: r2(list.reduce((sum, s) => sum + (Number(s.gross) || 0), 0)) };
  }

  /* ---- client invoices outstanding (total − payments) -------------------- */
  const paidFor = (invId) => r2(Store.all("payments").filter((p) => p.invoiceId === invId).reduce((s, p) => s + (Number(p.amount) || 0), 0));
  function outstandingClients() {
    let value = 0, count = 0;
    Store.all("invoices").filter((i) => i.status !== "Draft" && i.status !== "Paid").forEach((i) => {
      const out = r2(docTotal(i) - paidFor(i.id));
      if (out > 0) { value += out; count++; }
    });
    return { count, value: r2(value) };
  }

  /* ==========================================================================
     RENDER
     ========================================================================== */
  function render(root) {
    if (!Auth.can("Manager")) { Views.forbidden(root, "Manager"); return; }

    const u = Auth.current();
    const hour = new Date().getHours();
    const greet = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";

    const pc = payrollCalc();
    const supCost = supplierCostPeriod();
    const supOut = outstandingSuppliers();
    const cliOut = outstandingClients();
    const pnl = (FIN && FIN.projectPnL) ? FIN.projectPnL(null) : { profit: 0, revenue: 0, margin: 0 };

    const card = (label, value, note, route, accent) => `
      <div class="stat${accent ? " stat--accent" : ""}" ${route ? `data-route="${route}" role="button" tabindex="0"` : ""}>
        <div class="stat__label">${esc(label)}</div>
        <div class="stat__value num">${esc(value)}</div>
        ${note ? `<div class="stat__note">${esc(note)}</div>` : ""}
      </div>`;

    root.innerHTML = `
      <div class="page-head">
        <h2 class="page-head__greet">${greet}, ${esc(u.name.split(" ")[0])}.</h2>
        <p class="page-head__sub">Accountant overview · signed in as <strong>${esc(u.role)}</strong>.</p>
      </div>

      <!-- CURRENT PAYROLL PERIOD banner -->
      <div class="acc-period" data-route="payroll" role="button" tabindex="0">
        <div>
          <div class="acc-period__label">Current payroll period</div>
          <div class="acc-period__range num">${Fmt.date(pc.from)} – ${Fmt.date(pc.to)}</div>
        </div>
        <div class="acc-period__totals">
          <div><span class="num">${pc.workerCount}</span> workers</div>
          <div><span class="num">${Fmt.hours(pc.totalHours)}</span> hrs</div>
          <div class="acc-period__gross"><span class="num">${Fmt.gbp(pc.gross)}</span> gross</div>
        </div>
      </div>

      <!-- CARDS -->
      <div class="stat-grid">
        ${card("Workers this period", String(pc.workerCount), "with logged labour", "labour-sheet")}
        ${card("Total hours", Fmt.hours(pc.totalHours), "this pay period", "payroll")}
        ${card("Payroll cost", Fmt.gbp(pc.gross), "gross · est.", "payroll", true)}
        ${card("Supplier costs", Fmt.gbp(supCost), "this period · invoices", "supplierInvoices")}
        ${card("Outstanding supplier inv.", Fmt.gbp(supOut.value), `${supOut.count} unpaid`, "supplierInvoices")}
        ${card("Outstanding client inv.", Fmt.gbp(cliOut.value), `${cliOut.count} unpaid`, "invoices")}
        ${card("Current project profit", Fmt.gbp(pnl.profit), `${Fmt.hours(pnl.margin)}% margin`, "profit", true)}
      </div>

      <!-- QUICK ACTIONS -->
      <section class="panel" style="margin-top:20px">
        <div class="panel__head"><span class="panel__title">Quick actions</span></div>
        <div class="panel__body">
          <div class="acc-actions">
            <button class="acc-action" id="qa-labour">
              <span class="acc-action__ic">🗓️</span>
              <span class="acc-action__t">Enter weekly labour</span>
              <span class="acc-action__s">Spreadsheet entry for the week</span>
            </button>
            <button class="acc-action" id="qa-payroll">
              <span class="acc-action__ic">£</span>
              <span class="acc-action__t">Process payroll</span>
              <span class="acc-action__s">Run the fortnight</span>
            </button>
            <button class="acc-action" id="qa-po">
              <span class="acc-action__ic">＋</span>
              <span class="acc-action__t">Add supplier invoice</span>
              <span class="acc-action__s">New purchase order</span>
            </button>
            <button class="acc-action" id="qa-payreport">
              <span class="acc-action__ic">📄</span>
              <span class="acc-action__t">Generate payroll report</span>
              <span class="acc-action__s">PDF · this period</span>
            </button>
            <button class="acc-action" id="qa-supreport">
              <span class="acc-action__ic">📦</span>
              <span class="acc-action__t">Generate supplier report</span>
              <span class="acc-action__s">PDF · spend &amp; outstanding</span>
            </button>
          </div>
        </div>
      </section>

      <p class="hint hint--block">Figures cover the current pay period (${Fmt.date(pc.from)} – ${Fmt.date(pc.to)}).
        Payroll is gross only — excludes PAYE, NI and pension. Cards link straight to the underlying module.</p>
    `;

    injectStyles();

    // card / banner navigation
    root.querySelectorAll("[data-route]").forEach((el) => {
      const go = () => Router.navigate(el.dataset.route);
      el.addEventListener("click", go);
      el.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(); } });
    });

    // quick actions
    root.querySelector("#qa-labour").addEventListener("click", () => Router.navigate("labour-sheet"));
    root.querySelector("#qa-payroll").addEventListener("click", () => Router.navigate("payroll"));
    root.querySelector("#qa-po").addEventListener("click", () => {
      if (!Store.all("suppliers").length) { UI.toast("Add a supplier first", "danger"); Router.navigate("suppliers"); return; }
      if (window.SupplierInvoices) window.SupplierInvoices.openForm();
      else Router.navigate("supplierInvoices");
    });
    root.querySelector("#qa-payreport").addEventListener("click", () => generatePayrollReport(payrollCalc()));
    root.querySelector("#qa-supreport").addEventListener("click", () => {
      if (window.SupplierInvoices) window.SupplierInvoices.openReports();
      else Router.navigate("supplierInvoices");
    });
  }

  /* ==========================================================================
     REPORTS (generated directly from the dashboard via the print pipeline)
     ========================================================================== */
  function generatePayrollReport(pc) {
    if (!pc.workers.length) { UI.toast("No labour logged in this period", "danger"); return; }
    const co = (Commercial.Company.get && Commercial.Company.get().name) || "Company";
    const wrows = pc.workers.map((l) => `<tr><td>${esc(l.name)}</td><td>${esc(l.trade || "—")}</td><td class="r">${Fmt.hours(l.hours)}</td><td class="r">${Fmt.gbp(l.rate)}</td><td class="r">${Fmt.gbp(r2(l.gross))}</td></tr>`).join("");
    const prows = pc.projects.map((p) => `<tr><td>${esc(p.name)}</td><td class="r">${Fmt.hours(p.hours)}</td><td class="r">${Fmt.gbp(r2(p.cost))}</td></tr>`).join("");
    const html = `
      <h1>Payroll report — ${esc(pc.label)}</h1>
      <div class="muted">${esc(co)} · ${Fmt.date(pc.from)} – ${Fmt.date(pc.to)} · generated ${Fmt.date(Fmt.todayISO())} by ${esc(Auth.current().name)}</div>
      <div class="grid">
        <div><strong>${pc.workerCount}</strong> worker${pc.workerCount === 1 ? "" : "s"} · <strong>${Fmt.hours(pc.totalHours)}</strong> hrs</div>
        <div style="text-align:right"><strong>${Fmt.gbp(pc.gross)}</strong> gross</div>
      </div>
      <h2>Pay by worker</h2>
      <table><thead><tr><th>Worker</th><th>Trade</th><th class="r">Hours</th><th class="r">Rate</th><th class="r">Gross pay</th></tr></thead>
      <tbody>${wrows}</tbody>
      <tfoot><tr><td colspan="2">Total (${pc.workerCount})</td><td class="r">${Fmt.hours(pc.totalHours)}</td><td></td><td class="r">${Fmt.gbp(pc.gross)}</td></tr></tfoot></table>
      <h2>Labour cost by project</h2>
      <table><thead><tr><th>Project</th><th class="r">Hours</th><th class="r">Labour cost</th></tr></thead>
      <tbody>${prows || `<tr><td colspan="3">No labour in this period</td></tr>`}</tbody>
      <tfoot><tr><td>Total</td><td class="r">${Fmt.hours(pc.projects.reduce((s, p) => s + p.hours, 0))}</td><td class="r">${Fmt.gbp(r2(pc.projects.reduce((s, p) => s + p.cost, 0)))}</td></tr></tfoot></table>
      <p class="muted">Gross pay only — excludes PAYE tax, National Insurance and pension. OT charged at ${OT}× base rate. Internal estimate, not a payslip.</p>`;
    Util.savePdfFromHtml(`payroll-${pc.from}.pdf`, html, { title: `Payroll report — ${pc.label}` });
  }

  /* Supplier reports now live in the Supplier Invoice Register (weekly,
     pay-period and outstanding). The "Generate supplier report" quick action
     above opens that module's Reports tab. */

  /* ==========================================================================
     STYLES (scoped, injected once)
     ========================================================================== */
  function injectStyles() {
    if (document.getElementById("accountant-dash-styles")) return;
    const css = `
      .acc-period { display:flex; justify-content:space-between; align-items:center; gap:18px; flex-wrap:wrap;
        margin:4px 0 20px; padding:16px 20px; border:1px solid var(--border); border-radius:var(--r, 12px);
        background:linear-gradient(120deg, var(--accent-soft), transparent 70%), var(--surface);
        cursor:pointer; transition:border-color .15s var(--ease); }
      .acc-period:hover { border-color:var(--accent); }
      .acc-period__label { font-family:var(--font-mono); font-size:0.68rem; text-transform:uppercase; letter-spacing:.06em; color:var(--text-faint); }
      .acc-period__range { font-size:1.2rem; font-weight:600; margin-top:4px; }
      .acc-period__totals { display:flex; gap:22px; flex-wrap:wrap; color:var(--text-muted); font-size:0.86rem; }
      .acc-period__totals .num { font-size:1.05rem; font-weight:600; color:var(--text); }
      .acc-period__gross .num { color:var(--accent-strong); }
      .stat--accent { border-color:var(--accent-soft); box-shadow:0 4px 16px var(--accent-soft); }
      .stat--accent .stat__value { color:var(--accent-strong); }
      .acc-actions { display:grid; grid-template-columns:repeat(auto-fill, minmax(210px, 1fr)); gap:12px; }
      .acc-action { display:flex; flex-direction:column; align-items:flex-start; gap:3px; text-align:left;
        padding:14px 16px; border:1px solid var(--border); border-radius:var(--r-sm); background:var(--surface-2);
        cursor:pointer; transition:all .15s var(--ease); }
      .acc-action:hover { border-color:var(--accent); transform:translateY(-1px); box-shadow:0 6px 18px var(--accent-soft); }
      .acc-action__ic { display:grid; place-items:center; width:30px; height:30px; border-radius:8px;
        background:var(--accent-soft); color:var(--accent-strong); font-weight:700; font-size:0.95rem; }
      .acc-action__t { font-weight:600; font-size:0.92rem; color:var(--text); margin-top:6px; }
      .acc-action__s { font-size:0.74rem; color:var(--text-faint); }
    `;
    const tag = document.createElement("style");
    tag.id = "accountant-dash-styles"; tag.textContent = css;
    document.head.appendChild(tag);
  }

  /* ==========================================================================
     REGISTRATION — appears at the very top of the sidebar (Manager+ only)
     ========================================================================== */
  Modules.register({
    id: "accountant", label: "Dashboard", title: "Dashboard", minRole: "Manager",
    icon: '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16v6H4zM4 14h6v6H4zM14 14h6v6h-6z"/><path d="M7 7h2"/></svg>',
    render,
  });

  // Promote to the top of the sidebar — sits right under Dashboard as a
  // top-level item (above the "Operations" section) so the accountant's home
  // is the first thing in the menu, not buried in a group.
  try {
    const i = NAV.findIndex((e) => e.type === "item" && e.path === "accountant");
    if (i > -1) {
      const [item] = NAV.splice(i, 1);
      const dash = NAV.findIndex((e) => e.type === "item" && e.path === "dashboard");
      NAV.splice(dash > -1 ? dash + 1 : 0, 0, item);
    }
  } catch (e) { /* non-fatal: falls back to default append position */ }
})();
