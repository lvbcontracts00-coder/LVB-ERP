/* Integration test — loads index.html + all module scripts in jsdom,
   logs in as admin, seeds data, and verifies the Supplier Invoice Register
   plus its Finance/profit integration. Run: node test.integration.js */
const fs = require("fs");
const path = require("path");
const { JSDOM } = require("jsdom");

const DIR = __dirname;
const html = fs.readFileSync(path.join(DIR, "index (2).html"), "utf8");

// Collect module script srcs in document order (skip the external Chart.js CDN).
const srcs = [...html.matchAll(/<script src="([^"]+)"><\/script>/g)]
  .map((m) => m[1]).filter((s) => !/^https?:/.test(s));

const dom = new JSDOM(html, { runScripts: "outside-only", pretendToBeVisual: true, url: "http://localhost/" });
const { window } = dom;
global.window = window; global.document = window.document;
// minimal shims jsdom lacks
window.crypto = window.crypto || {};
if (!window.crypto.randomUUID) window.crypto.randomUUID = () => "id-" + Math.random().toString(36).slice(2);
window.matchMedia = window.matchMedia || (() => ({ matches: false, addEventListener() {}, removeEventListener() {} }));
window.print = () => {};
window.URL.createObjectURL = () => "blob:x"; window.URL.revokeObjectURL = () => {};
window.scrollTo = () => {};

// Evaluate each script in the window context (concatenate; they're IIFE/global).
const vm = require("vm");
const ctx = dom.getInternalVMContext();
for (const src of srcs) {
  const code = fs.readFileSync(path.join(DIR, src), "utf8");
  vm.runInContext(code, ctx, { filename: src });
}

// Boot
window.document.dispatchEvent(new window.Event("DOMContentLoaded"));

const evalIn = (expr) => vm.runInContext(expr, ctx);
const Store = evalIn("Store"), Auth = evalIn("Auth"), Finance = evalIn("Finance"), Router = evalIn("Router");
const Dashboard = evalIn("Dashboard");
const resolve = () => evalIn("Router.resolve()");
let fails = 0;
const ok = (cond, msg) => { console.log((cond ? "PASS" : "FAIL") + " — " + msg); if (!cond) fails++; };

// --- login as admin ---
Auth.login("admin", "admin123");

// --- module registered + routable ---
ok(Router.has("supplierInvoices"), "supplierInvoices route registered");
ok(typeof window.SupplierInvoices === "object", "window.SupplierInvoices opener API exposed");
ok(typeof Finance.supplierInvoiceCost === "function", "Finance.supplierInvoiceCost exists");

// --- seed suppliers + a site ---
const mgn = Store.insert("suppliers", { name: "MGN", category: "Builders Merchant" });
const selco = Store.insert("suppliers", { name: "Selco", category: "Builders Merchant" });
const site = Store.insert("sites", { name: "Twickenham Ext", status: "Active" });

// --- seed supplier invoices ---
const today = new Date().toISOString().slice(0, 10);
Store.insert("supplierInvoices", { supplierId: mgn.id, number: "M-1", date: today, dueDate: today, siteId: site.id, net: 1000, vat: 200, gross: 1200, status: "Unpaid" });
Store.insert("supplierInvoices", { supplierId: selco.id, number: "S-1", date: today, dueDate: today, siteId: site.id, net: 500, vat: 100, gross: 600, status: "Paid", paymentDate: today });
Store.insert("supplierInvoices", { supplierId: mgn.id, number: "M-DRAFT", date: today, dueDate: today, siteId: site.id, net: 999, vat: 0, gross: 999, status: "Draft" });

// --- cost integration: committed (Unpaid+Paid) = 1200 + 600 = 1800; Draft excluded ---
ok(Finance.supplierInvoiceCost(site.id) === 1800, "supplierInvoiceCost(site) = 1800 (Draft excluded), got " + Finance.supplierInvoiceCost(site.id));
ok(Finance.supplierInvoiceCost(null) === 1800, "supplierInvoiceCost(all) = 1800");
const pc = Finance.projectCost(site.id);
ok(pc.supplierInvoices === 1800, "projectCost.supplierInvoices = 1800");
ok(pc.total === 1800, "projectCost.total includes supplier invoices = 1800 (no other costs), got " + pc.total);

// --- render the module (register tab) ---
const root = window.document.getElementById("view-root");
Router.navigate("supplierInvoices"); resolve();
const regHtml = root.innerHTML;
ok(/Add invoice/.test(regHtml), "register shows Add invoice button");
ok(/MGN/.test(regHtml) && /Selco/.test(regHtml), "register lists both suppliers' invoices");
ok(/£1,800\.00 outstanding|£1,200\.00 outstanding/.test(regHtml), "register shows outstanding figure");
// outstanding = unpaid only = 1200
ok(/£1,200\.00 outstanding/.test(regHtml), "outstanding = unpaid gross = £1,200.00");

// --- by-supplier tab ---
window.SupplierInvoices.openReports(); // navigates (hash differs in app); resolve happens via that navigate
const repHtml = root.innerHTML;
ok(/Weekly supplier cost report/.test(repHtml), "reports: weekly section present");
ok(/Payroll period supplier report/.test(repHtml), "reports: fortnight section present");
ok(/Outstanding supplier invoices/.test(repHtml), "reports: outstanding section present");
ok(/Total outstanding supplier balance/.test(repHtml), "reports: outstanding total label present");

// --- profit page includes supplier invoices ---
Router.navigate("profit"); resolve();
const profHtml = root.innerHTML;
ok(/Supplier invoices/.test(profHtml), "profit cost breakdown lists Supplier invoices");
ok(/£1,800\.00/.test(profHtml), "profit reflects £1,800 supplier-invoice cost somewhere");

// --- dashboard stat present (standard dashboard) ---
ok(Dashboard.stats().some((s) => /Supplier invoices due/.test(s.label)), "dashboard stat 'Supplier invoices due' contributed");

// --- accountant dashboard supplier cards now invoice-based ---
Router.navigate("accountant"); resolve();
const accHtml = root.innerHTML;
ok(/Supplier costs/.test(accHtml), "accountant dashboard has Supplier costs card");
ok(/£1,200\.00/.test(accHtml), "accountant dashboard outstanding supplier inv. = £1,200.00 (unpaid)");

console.log(fails === 0 ? "\nALL PASSED" : `\n${fails} CHECK(S) FAILED`);
process.exit(fails === 0 ? 0 : 1);
