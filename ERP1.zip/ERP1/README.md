# Construction ERP

A complete **site & office management** system for a construction company —
estimating, projects, payroll, commercial documents, costing, compliance, tax
and reporting — built as a single-page app in **plain HTML, CSS and vanilla
JavaScript**. No framework, no build step, no server required.

All data is stored locally in the browser (`localStorage`, namespaced `erp:`).
Open `index.html` and it runs.

---

## Features

**Operations** — workers, sites/projects, timesheets, payroll (period aggregation, OT)
**Commercial** — clients, quotes, invoices, suppliers, purchase orders (branded printable docs, VAT)
**Finance** — employee expenses (with receipt capture), client payments
**Project Costing** — materials price book, stock/inventory control, skip hire, full profitability dashboard with margins
**Fleet & Assets** — vehicles (MOT/tax/insurance renewals), tool & equipment register (PAT/LOLER)
**HR & Scheduling** — company calendar (aggregates dates from the whole system), leave management
**Compliance** — document storage, Health & Safety / RAMS register with review tracking
**Tax** — CIS deductions (HMRC tax-month periods), VAT return summary
**Insights** — advanced reports (aged debtors, cash flow), visual analytics (Chart.js)
**System** — company profile, user list, JSON backup / restore, CSV & PDF exports

### Roles
Three access levels enforced throughout: **Viewer** (read), **Manager** (edit +
financials), **Admin** (everything, incl. backup/restore).

| Account | Password | Role |
| --- | --- | --- |
| `admin` | `admin123` | Admin |
| `manager` | `manager123` | Manager |
| `viewer` | `viewer123` | Viewer |

> Prototype auth only — accounts are seeded client-side. See *Security* below.

---

## Quick start

No build step. Any static web server works (recommended over `file://` so that
web fonts and Chart.js load over HTTPS):

```bash
# Python (built in)
python3 -m http.server 8080
# then open http://localhost:8080

# …or Node
npx serve .
```

Or simply double-click `index.html` (an internet connection is needed the first
time for the web fonts and the Chart.js CDN; everything else is local).

Full steps in **INSTALLATION.md**. Hosting options in **DEPLOYMENT.md**.

---

## Project structure

```
construction-erp/
├── index.html              # shell: login + sidebar/topbar + routed view
├── app.js                  # core framework (Store, Auth, Router, Modules,
│                           #   Dashboard, UI, Fmt, Period, Finance, Commercial)
├── styles.css              # design system, responsive layout, print, theming
├── styles.enhance.css      # additive polish (calendar grid, charts, code)
├── README.md
├── INSTALLATION.md
├── DEPLOYMENT.md
├── FINALISATION.md         # phase-6 notes, QA review, future improvements
└── modules/
    ├── util.js             # shared helpers + CSV/PDF/chart utilities
    ├── workers.js  sites.js  timesheets.js  payroll.js          # Operations
    ├── clients.js  quotes.js  invoices.js  suppliers.js  purchaseOrders.js  # Commercial
    ├── expenses.js  payments.js                                 # Finance
    ├── materials.js  inventory.js  skipHire.js  profit.js       # Project Costing
    ├── vehicles.js  equipment.js                                # Fleet & Assets
    ├── calendar.js  leaveManagement.js                          # HR & Scheduling
    ├── documents.js  healthSafety.js                            # Compliance
    ├── cis.js  vat.js                                           # Tax
    ├── reports.js  analytics.js                                 # Insights
    └── settings.js                                              # System
```

26 feature modules + `util.js` over a single core. **Load order = sidebar
order**; `util.js` must load right after `app.js`, before the feature modules.

---

## Architecture

- **Core (`app.js`)** exposes small global services: `Store` (localStorage CRUD
  with ids/timestamps), `Auth` (roles), `Router` (hash routing), `Modules`
  (registration + nav), `Dashboard` (stat cards), `UI` (modals/toasts/nav),
  `Fmt`/`Period` (formatting + date ranges), `Finance` (single source of truth
  for project cost & profitability), `Commercial` (money maths + company
  profile + printable documents).
- **Modules** are self-contained IIFEs that call `Modules.register({...})` to
  add a route + sidebar entry, and read/write `Store` collections. Modules never
  call each other directly — they share state through `Store`, so any module can
  be added or removed independently.
- **Adding a module:** drop a file in `modules/`, register it, add one
  `<script>` tag to `index.html`. That's it.

## Data & persistence

Everything lives in the browser under `erp:*` keys. **Back up regularly**
(Settings → Export backup) — clearing the browser erases all data, and data does
not sync between browsers or devices. The ~5 MB `localStorage` budget suits a
small firm's working set; heavy document storage needs a backend (see
*Future improvements* in FINALISATION.md).

## Exports
- **CSV** — profitability, aged debtors, analytics.
- **PDF** — invoices/quotes/POs, profitability, reports, analytics (via the
  browser's print → *Save as PDF*).
- **JSON** — full backup/restore in Settings.

## Security
This is a client-side prototype. The login is for UX/role demonstration only —
there is no server, passwords are not hashed, and anyone with the files can read
the local data. For real-world use, put it behind a backend with proper
authentication and move storage server-side.

## Tech
Vanilla JS (ES2020), CSS custom properties (light/dark themes), Chart.js 4 for
analytics. No bundler, no dependencies to install.
