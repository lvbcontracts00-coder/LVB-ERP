# Installation Guide

Construction ERP is a static single-page app — **no build, no dependencies, no
server-side runtime**. You only need the files and a way to serve them.

## Requirements
- A modern browser (Chrome, Edge, Firefox or Safari — last 2 years).
- Internet on first load (web fonts + the Chart.js CDN). Everything else is
  local. See *Offline use* below to remove that requirement.

## Option A — Run with a local static server (recommended)

Serving over `http://` (rather than opening the file directly) avoids browser
restrictions on fonts and CDN scripts.

**Python (already on macOS/Linux):**
```bash
cd construction-erp
python3 -m http.server 8080
```
Open <http://localhost:8080>.

**Node.js:**
```bash
cd construction-erp
npx serve .          # or: npx http-server -p 8080
```

**VS Code:** install the *Live Server* extension, right-click `index.html` →
*Open with Live Server*.

## Option B — Open directly
Double-click `index.html`. It works on `file://`, but some browsers restrict CDN
fonts/scripts there, so prefer Option A.

## First run
1. The login screen appears. Use a demo account:
   - `admin` / `admin123` (full access)
   - `manager` / `manager123`
   - `viewer` / `viewer123`
2. You start with an empty dataset. Add a worker and a site, then explore.
3. Data is saved automatically in this browser. Use **Settings → Export backup**
   to save a JSON snapshot.

## Restoring data
**Settings → Import backup** → paste the JSON or choose a `.json` file → *Restore
data*. To start clean: **Settings → Erase all data** (Admin only).

## Offline use (optional)
Charts load Chart.js from a CDN. To run fully offline:
1. Download `chart.umd.min.js` (Chart.js v4) into `modules/` (or a `vendor/`
   folder).
2. In `index.html`, change the Chart.js `<script src>` to point at the local
   copy.
The Google Fonts link is optional too — the UI falls back to system fonts if it
is removed or unreachable.

## Updating
Replace the changed files (e.g. a module in `modules/`). No rebuild needed —
reload the page. Stored data is unaffected as long as collection shapes don't
change. Take a backup before large updates.

## Troubleshooting
- **Charts show "charts library not loaded"** — Chart.js didn't load (offline or
  blocked). The page still works and shows data tables; fix the Chart.js tag.
- **Blank page / nothing registers** — open the browser console; ensure
  `app.js` and `modules/util.js` load *before* the feature modules.
- **Data "disappeared"** — it is per-browser/per-origin. A different browser,
  profile, or private window has its own store. Restore from a backup.
