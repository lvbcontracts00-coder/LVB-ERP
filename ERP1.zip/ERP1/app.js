/* ==========================================================================
   Construction ERP — app.js
   Phase 1: core framework (no business modules yet).

   This single file is organised into self-contained modules so later phases
   can extract pieces into /modules without rewriting them:

     Store   – generic localStorage data layer (reused by every future module)
     Auth    – demo users, session, role hierarchy (Admin > Manager > Viewer)
     Theme   – light/dark switching, persisted
     Router  – hash routing with auth + role guards; routes are registered,
               so adding a module later = one Router.register() call
     Views   – view renderers (Phase 1 ships Dashboard + fallbacks)
     UI      – sidebar/topbar rendering, toasts
     App     – bootstrap / wiring

   NOTE ON SECURITY: auth here is client-side prototype only. Credentials live
   in localStorage in plain text — fine for an internal demo, but real
   deployment needs a backend with hashed passwords. Flagged again where used.
   ========================================================================== */

"use strict";

/* ==========================================================================
   1. STORE — localStorage framework
   Namespaced keys + generic collection CRUD with auto id/timestamps.
   Every future module (projects, quotes, invoices…) builds on this.
   ========================================================================== */
const Store = (() => {
  const PREFIX = "erp:"; // all keys namespaced to avoid collisions

  const key = (name) => PREFIX + name;

  /** Read a JSON value, returning `fallback` if missing/corrupt. */
  function read(name, fallback = null) {
    try {
      const raw = localStorage.getItem(key(name));
      return raw === null ? fallback : JSON.parse(raw);
    } catch (e) {
      console.warn(`[Store] could not read "${name}":`, e);
      return fallback;
    }
  }

  /** Write any JSON-serialisable value. */
  function write(name, value) {
    try {
      localStorage.setItem(key(name), JSON.stringify(value));
      return true;
    } catch (e) {
      console.error(`[Store] could not write "${name}":`, e);
      return false;
    }
  }

  function remove(name) { localStorage.removeItem(key(name)); }

  /** RFC4122-ish unique id (good enough for client records). */
  function uuid() {
    if (crypto && crypto.randomUUID) return crypto.randomUUID();
    return "id-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8);
  }

  /* ---- Generic collection CRUD -----------------------------------------
     A "collection" is just an array stored under its name, e.g. "projects".
     These are the methods future modules will lean on. -------------------- */
  const all    = (col)       => read(col, []);
  const find   = (col, id)   => all(col).find((r) => r.id === id) || null;
  const query  = (col, fn)   => all(col).filter(fn);

  function insert(col, record) {
    const rows = all(col);
    const now = new Date().toISOString();
    const row = { id: uuid(), createdAt: now, updatedAt: now, ...record };
    rows.push(row);
    write(col, rows);
    return row;
  }

  function update(col, id, patch) {
    const rows = all(col);
    const i = rows.findIndex((r) => r.id === id);
    if (i === -1) return null;
    rows[i] = { ...rows[i], ...patch, updatedAt: new Date().toISOString() };
    write(col, rows);
    return rows[i];
  }

  function destroy(col, id) {
    const rows = all(col).filter((r) => r.id !== id);
    write(col, rows);
  }

  /* ---- Backup helpers (handy from the console; UI hook comes later) ----- */
  function exportAll() {
    const dump = {};
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(PREFIX)) dump[k.slice(PREFIX.length)] = read(k.slice(PREFIX.length));
    }
    return JSON.stringify(dump, null, 2);
  }
  function importAll(json) {
    const data = typeof json === "string" ? JSON.parse(json) : json;
    Object.entries(data).forEach(([k, v]) => write(k, v));
  }

  return { read, write, remove, uuid, all, find, query, insert, update, destroy, exportAll, importAll };
})();

/* ==========================================================================
   2. AUTH — users, session, role hierarchy
   ========================================================================== */
const Auth = (() => {
  // Role hierarchy as numeric levels so guards can do ">=" comparisons.
  const ROLES = { Viewer: 1, Manager: 2, Admin: 3 };

  // Default demo accounts seeded on first run.
  // SECURITY: plain-text passwords — prototype only. Replace with backend auth.
  const SEED_USERS = [
    { id: "u-admin",   username: "admin",   password: "admin123",   name: "Site Admin",      role: "Admin" },
    { id: "u-manager", username: "manager", password: "manager123", name: "Project Manager", role: "Manager" },
    { id: "u-viewer",  username: "viewer",  password: "viewer123",  name: "Site Viewer",     role: "Viewer" },
  ];

  function seed() {
    if (!Store.read("users")) Store.write("users", SEED_USERS);
  }

  function login(username, password) {
    const users = Store.read("users", []);
    const u = users.find(
      (x) => x.username.toLowerCase() === String(username).trim().toLowerCase() && x.password === password
    );
    if (!u) return { ok: false, error: "Invalid username or password." };
    // store a session WITHOUT the password field
    const { password: _omit, ...safe } = u;
    Store.write("session", safe);
    return { ok: true, user: safe };
  }

  function logout() { Store.remove("session"); }

  const current = () => Store.read("session", null);
  const isAuthed = () => current() !== null;
  const level = (role) => ROLES[role] || 0;

  /** True if the current user meets a minimum role (default Viewer). */
  function can(minRole = "Viewer") {
    const u = current();
    return !!u && level(u.role) >= level(minRole);
  }

  return { ROLES, seed, login, logout, current, isAuthed, can, level };
})();

/* ==========================================================================
   3. THEME — light/dark, persisted, respects system preference first time
   ========================================================================== */
const Theme = (() => {
  const ICON_SUN  = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" width="18" height="18"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M19 5l-1.5 1.5M6.5 17.5L5 19"/></svg>';
  const ICON_MOON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="18" height="18"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>';

  function get() { return document.documentElement.getAttribute("data-theme") || "light"; }

  function apply(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    Store.write("theme", theme);
    // every theme button shows the icon of the *other* mode (the action it triggers)
    const icon = theme === "dark" ? ICON_SUN : ICON_MOON;
    document.querySelectorAll("[data-theme-icon]").forEach((el) => (el.innerHTML = icon));
  }

  function toggle() { apply(get() === "dark" ? "light" : "dark"); }

  function init() {
    const saved = Store.read("theme");
    const prefersDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
    apply(saved || (prefersDark ? "dark" : "light"));
  }

  return { get, apply, toggle, init };
})();

/* ==========================================================================
   4. ROUTER — hash routing with auth + role guards
   Register routes once; navigation, guarding and active-state are automatic.
   Future phases add modules with a single Router.register(...) call.
   ========================================================================== */
const Router = (() => {
  const routes = new Map(); // path -> { title, render, minRole }
  let notFound = null;

  /**
   * @param path     e.g. "dashboard"
   * @param config   { title, render(root), minRole }
   */
  function register(path, config) { routes.set(path, config); }
  function has(path) { return routes.has(path); }
  function setNotFound(fn) { notFound = fn; }

  function navigate(path) {
    if (("#/" + path) === location.hash) resolve();
    else location.hash = "#/" + path;
  }

  function currentPath() {
    const h = location.hash.replace(/^#\/?/, "");
    return h || "dashboard";
  }

  function resolve() {
    const root = document.getElementById("view-root");
    if (!root) return;

    // Auth guard — bounce to login if no session.
    if (!Auth.isAuthed()) { App.showLogin(); return; }

    const path = currentPath();
    const route = routes.get(path);

    if (!route) {
      (notFound || (() => { root.innerHTML = ""; }))(root);
      UI.setActiveNav(null);
      UI.setTitle("Not found");
      return;
    }

    // Role guard.
    if (route.minRole && !Auth.can(route.minRole)) {
      Views.forbidden(root, route.minRole);
      UI.setActiveNav(null);
      UI.setTitle("Access denied");
      return;
    }

    root.innerHTML = "";
    route.render(root);
    UI.setActiveNav(path);
    UI.setTitle(route.title);
    root.focus({ preventScroll: true });
  }

  function start() {
    window.addEventListener("hashchange", resolve);
    resolve();
  }

  return { register, has, setNotFound, navigate, resolve, start, currentPath };
})();

/* ==========================================================================
   5. NAV CONFIG + VIEWS
   ========================================================================== */

// Sidebar navigation registry. `minRole` controls visibility.
// Seeded with Dashboard + an "Operations" header; modules append their own
// items via Modules.register() when their script loads (see /modules).
const NAV = [
  { type: "item", path: "dashboard", label: "Dashboard", minRole: "Viewer", icon:
    '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/></svg>' },
  { type: "section", label: "Operations" },
  // ← module nav items are appended here at load time
];

/* --------------------------------------------------------------------------
   MODULES registry — the one call every future module makes to plug in.
   It (a) registers a guarded route and (b) adds a role-filtered nav item.
   Adding a whole feature later costs exactly one Modules.register({...}).
   -------------------------------------------------------------------------- */
const Modules = {
  register({ id, label, icon, minRole = "Viewer", title, render }) {
    Router.register(id, { title: title || label, minRole, render });
    NAV.push({ type: "item", path: id, label, minRole, icon });
  },
  section(label) { NAV.push({ type: "section", label }); },
};

/* --------------------------------------------------------------------------
   DASHBOARD registry — modules contribute stat cards (and optional recent
   activity) so the dashboard stays decoupled from each module's data shape.
   -------------------------------------------------------------------------- */
const Dashboard = {
  _stats: [],      // each: { fn: () => ({label,value,note,route}), minRole }
  _activity: [],   // each: { fn: () => [{when, text, route}], minRole }
  addStat(fn, minRole = "Viewer") { this._stats.push({ fn, minRole }); },
  addActivity(fn, minRole = "Viewer") { this._activity.push({ fn, minRole }); },
  stats()    { return this._stats.filter((s) => Auth.can(s.minRole)).map((s) => s.fn()); },
  activity() {
    return this._activity
      .filter((a) => Auth.can(a.minRole))
      .flatMap((a) => a.fn())
      .sort((x, y) => (y.when || "").localeCompare(x.when || ""))
      .slice(0, 6);
  },
};

const Views = {
  /** Dashboard — renders stat cards + recent activity contributed by modules. */
  dashboard(root) {
    const u = Auth.current();
    const hour = new Date().getHours();
    const part = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";

    const stats = Dashboard.stats();
    const activity = Dashboard.activity();

    const statCards = stats.length
      ? stats.map((s) => `
          <div class="stat" ${s.route ? `data-route="${s.route}" role="button" tabindex="0"` : ""}>
            <div class="stat__label">${esc(s.label)}</div>
            <div class="stat__value num">${esc(s.value)}</div>
            ${s.note ? `<div class="stat__note">${esc(s.note)}</div>` : ""}
          </div>`).join("")
      : `<div class="stat"><div class="stat__label">No data yet</div>
           <div class="stat__value num">—</div>
           <div class="stat__note">Add workers, sites and timesheets to populate.</div></div>`;

    const activityBody = activity.length
      ? `<ul class="activity">${activity.map((a) => `
           <li class="activity__row" ${a.route ? `data-route="${a.route}" role="button" tabindex="0"` : ""}>
             <span class="activity__dot"></span>
             <span class="activity__text">${esc(a.text)}</span>
             <span class="activity__when num">${esc(Fmt.dayMon(a.when))}</span>
           </li>`).join("")}</ul>`
      : `<div class="empty">
           <svg class="empty__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>
           <div class="empty__title">No activity yet</div>
           <div class="empty__text">Logged timesheets will show up here.</div>
         </div>`;

    root.innerHTML = `
      <div class="page-head">
        <h2 class="page-head__greet">${part}, ${esc(u.name.split(" ")[0])}.</h2>
        <p class="page-head__sub">Workspace overview · signed in as <strong>${esc(u.role)}</strong>.</p>
      </div>

      <div class="stat-grid">${statCards}</div>

      <div class="panel-grid">
        <section class="panel">
          <div class="panel__head"><span class="panel__title">Recent activity</span></div>
          <div class="panel__body">${activityBody}</div>
        </section>

        <section class="panel">
          <div class="panel__head"><span class="panel__title">Quick actions</span></div>
          <div class="panel__body">
            <div class="quick">
              <button class="quick__item" data-route="workers"><span>＋ Manage workers</span><span>Go</span></button>
              <button class="quick__item" data-route="sites"><span>＋ Manage sites</span><span>Go</span></button>
              <button class="quick__item" data-route="timesheets"><span>＋ Log timesheet</span><span>Go</span></button>
              ${Auth.can("Manager") ? `<button class="quick__item" data-route="payroll"><span>£ Run payroll</span><span>Go</span></button>` : ""}
            </div>
          </div>
        </section>
      </div>`;

    // make stat cards / activity rows / quick actions navigate
    root.querySelectorAll("[data-route]").forEach((el) => {
      el.style.cursor = "pointer";
      el.addEventListener("click", () => Router.navigate(el.dataset.route));
      el.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); Router.navigate(el.dataset.route); } });
    });
  },

  /** Shown when a user lacks the required role for a route. */
  forbidden(root, minRole) {
    root.innerHTML = `
      <div class="notice">
        <div class="notice__code">403</div>
        <h2 class="notice__title">Access denied</h2>
        <p class="notice__text">This area requires <strong>${esc(minRole)}</strong> permissions or higher.
        You're signed in as <strong>${esc(Auth.current().role)}</strong>.</p>
      </div>`;
  },

  /** Generic not-found fallback. */
  notFound(root) {
    root.innerHTML = `
      <div class="notice">
        <div class="notice__code">404</div>
        <h2 class="notice__title">Page not found</h2>
        <p class="notice__text">The view you requested doesn't exist yet.</p>
      </div>`;
  },
};

/* ==========================================================================
   6. UI — sidebar/topbar rendering + toasts
   ========================================================================== */
const UI = {
  /** Build the sidebar nav, filtered by the current user's role. */
  renderNav() {
    const nav = document.getElementById("nav");
    nav.innerHTML = NAV.map((entry) => {
      if (entry.type === "section") return `<div class="nav__section">${entry.label}</div>`;
      if (entry.type === "locked") {
        return `<div class="nav__item nav__item--locked">
                  ${entry.icon}<span>${entry.label}</span><span class="nav__lock">${entry.phase}</span>
                </div>`;
      }
      // standard item — skip if role too low
      if (entry.minRole && !Auth.can(entry.minRole)) return "";
      return `<button class="nav__item" data-route="${entry.path}">
                ${entry.icon}<span>${entry.label}</span>
              </button>`;
    }).join("");

    nav.querySelectorAll("[data-route]").forEach((btn) =>
      btn.addEventListener("click", () => {
        Router.navigate(btn.dataset.route);
        document.body.classList.remove("sidebar-open"); // close drawer on mobile
      })
    );
  },

  setActiveNav(path) {
    document.querySelectorAll(".nav__item[data-route]").forEach((b) =>
      b.classList.toggle("is-active", b.dataset.route === path)
    );
  },

  setTitle(title) {
    document.getElementById("page-title").textContent = title;
    document.title = `${title} · Construction ERP`;
  },

  /** Fill the sidebar user chip + topbar role badge. */
  renderUser() {
    const u = Auth.current();
    if (!u) return;
    const initials = u.name.split(" ").map((s) => s[0]).slice(0, 2).join("").toUpperCase();
    document.getElementById("user-avatar").textContent = initials;
    document.getElementById("user-name").textContent = u.name;
    document.getElementById("user-role").textContent = u.role;
    document.getElementById("role-badge").textContent = u.role;
  },

  toast(message, type = "info") {
    const wrap = document.getElementById("toasts");
    const el = document.createElement("div");
    el.className = `toast toast--${type}`;
    el.textContent = message;
    wrap.appendChild(el);
    setTimeout(() => {
      el.style.opacity = "0";
      el.style.transition = "opacity .3s";
      setTimeout(() => el.remove(), 300);
    }, 3200);
  },

  /**
   * Reusable modal dialog. Returns { root, close }.
   * @param title     header text
   * @param bodyHTML  inner HTML for the body (e.g. a form)
   * @param onSave    optional (rootEl) => boolean|void — return false to keep open
   * @param saveLabel save button label
   * @param size      "lg" for a wider modal
   */
  modal({ title, bodyHTML, onSave, saveLabel = "Save", size }) {
    const root = document.getElementById("modal-root");
    root.innerHTML = `
      <div class="modal-overlay">
        <div class="modal ${size === "lg" ? "modal--lg" : ""}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
          <div class="modal__head">
            <h3 class="modal__title">${esc(title)}</h3>
            <button class="iconbtn" data-modal-close aria-label="Close">
              <svg viewBox="0 0 24 24" width="16" height="16"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
            </button>
          </div>
          <div class="modal__body">${bodyHTML}</div>
          <div class="modal__foot">
            <button class="btn" data-modal-close>Cancel</button>
            ${onSave ? `<button class="btn btn--primary" data-modal-save>${esc(saveLabel)}</button>` : ""}
          </div>
        </div>
      </div>`;
    const overlay = root.querySelector(".modal-overlay");
    root.querySelectorAll("[data-modal-close]").forEach((b) => b.addEventListener("click", UI.closeModal));
    overlay.addEventListener("mousedown", (e) => { if (e.target === overlay) UI.closeModal(); });
    const saveBtn = root.querySelector("[data-modal-save]");
    if (saveBtn && onSave) saveBtn.addEventListener("click", () => { if (onSave(root) !== false) UI.closeModal(); });
    const first = root.querySelector("input, select, textarea");
    if (first) first.focus();
    return { root, close: UI.closeModal };
  },

  closeModal() { document.getElementById("modal-root").innerHTML = ""; },

  /** Lightweight styled confirm via modal. cb runs on confirm. */
  confirm(message, cb) {
    UI.modal({
      title: "Please confirm",
      bodyHTML: `<p style="color:var(--text-muted)">${esc(message)}</p>`,
      saveLabel: "Confirm",
      onSave: () => { cb(); },
    });
  },
};

/* ==========================================================================
   7. APP — bootstrap & wiring
   ========================================================================== */
const App = (() => {
  /** Reveal the login view, hide the app. */
  function showLogin() {
    document.getElementById("login-view").hidden = false;
    document.getElementById("app-view").hidden = true;
    const err = document.getElementById("login-error");
    if (err) err.hidden = true;
    const u = document.getElementById("login-user");
    if (u) u.focus();
  }

  /** Single source of truth for the consolidated sidebar. Runs once at boot,
      after every module has registered, and rebuilds NAV into the simplified
      information architecture. Modules keep their own registrations; we only
      reorder / relabel / regroup here, so nothing loses its route or features.
      Any registered module not explicitly placed still appears (under "More"),
      so functionality can never silently disappear. */
  function reorganizeNav() {
    const ICON_BACKUP =
      '<svg class="nav__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 1.7 3.6 3 8 3s8-1.3 8-3V5"/><path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/></svg>';

    const byPath = {};
    NAV.forEach((e) => { if (e.type === "item") byPath[e.path] = e; });

    // nav label overrides for the consolidated menu (routes/ids are unchanged)
    const relabel = { accountant: "Dashboard", "labour-sheet": "Weekly Labour Sheet", sites: "Projects" };

    const layout = [
      // primary menu — sits at the very top, no section header
      { items: ["accountant", "labour-sheet", "payroll", "supplierInvoices", "suppliers", "sites", "reports"] },
      // everything else stays reachable, grouped logically
      { section: "Commercial",            items: ["quotes", "invoices", "payments", "purchaseOrders", "expenses"] },
      { section: "Payroll & Tax",         items: ["timesheets", "cis", "vat", "monthly"] },
      { section: "Project Costing",       items: ["materials", "skipHire", "profit"] },
      { section: "Scheduling & Insights", items: ["calendar", "leaveManagement", "analytics"] },
      // secondary modules requested under Administration
      { section: "Administration",        items: ["workers", "clients", "inventory", "equipment", "vehicles", "documents", "healthSafety", "settings", "__backup"] },
    ];

    const placed = new Set();
    const next = [];
    layout.forEach((grp) => {
      const items = [];
      grp.items.forEach((path) => {
        if (path === "__backup") {
          if (Router.has("backup")) { items.push({ type: "item", path: "backup", label: "Backup & Restore", minRole: "Manager", icon: ICON_BACKUP }); placed.add("backup"); }
          return;
        }
        const it = byPath[path];
        if (!it) return;                          // module absent — skip gracefully
        it.label = relabel[path] || it.label;
        items.push(it); placed.add(path);
      });
      if (!items.length) return;
      if (grp.section) next.push({ type: "section", label: grp.section });
      next.push(...items);
    });

    // safety net: any registered module we didn't place (and the retired basic
    // "dashboard") — keep the former reachable so no feature is lost.
    const leftovers = NAV.filter((e) => e.type === "item" && e.path !== "dashboard" && !placed.has(e.path));
    if (leftovers.length) { next.push({ type: "section", label: "More" }); next.push(...leftovers); }

    NAV.length = 0;
    NAV.push(...next);
  }

  /** Where a freshly-opened session lands. The accountant (Manager+) opens
      straight onto the dedicated accountant dashboard if it's registered;
      everyone else gets the standard dashboard. Only used when no explicit
      hash is present, so deep links and reloads are never overridden. */
  function landingRoute() {
    if (Auth.can("Manager") && Router.has && Router.has("accountant")) return "accountant";
    return "dashboard";
  }

  /** Reveal the app shell, render chrome, route. */
  function showApp() {
    document.getElementById("login-view").hidden = true;
    document.getElementById("app-view").hidden = false;
    UI.renderNav();
    UI.renderUser();
    Router.resolve();
  }

  function handleLogin() {
    const user = document.getElementById("login-user").value;
    const pass = document.getElementById("login-pass").value;
    const err = document.getElementById("login-error");
    const res = Auth.login(user, pass);
    if (!res.ok) {
      err.textContent = res.error;
      err.hidden = false;
      return;
    }
    err.hidden = true;
    document.getElementById("login-pass").value = "";
    if (!location.hash) location.hash = "#/" + landingRoute();
    showApp();
    UI.toast(`Signed in as ${res.user.name}`, "ok");
  }

  function handleLogout() {
    Auth.logout();
    showLogin();
    UI.toast("Signed out", "info");
  }

  /** Global click delegation for [data-action] buttons. */
  function wireActions() {
    document.addEventListener("click", (e) => {
      const el = e.target.closest("[data-action]");
      if (!el) return;
      switch (el.dataset.action) {
        case "toggle-theme":  Theme.toggle(); break;
        case "logout":        handleLogout(); break;
        case "open-sidebar":  document.body.classList.add("sidebar-open"); break;
        case "close-sidebar": document.body.classList.remove("sidebar-open"); break;
      }
    });

    // login interactions
    document.getElementById("login-submit").addEventListener("click", handleLogin);
    ["login-user", "login-pass"].forEach((id) =>
      document.getElementById(id).addEventListener("keydown", (e) => {
        if (e.key === "Enter") handleLogin();
      })
    );

    // Escape closes any open modal
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") UI.closeModal(); });
  }

  function init() {
    Theme.init();
    Auth.seed();

    // Register Phase 1 routes. Adding a module later = one more line here.
    // Legacy "dashboard" route now folds into the single consolidated Dashboard
    // (the accountant view) for Manager+. Viewers still get the basic page.
    Router.register("dashboard", { title: "Dashboard", minRole: "Viewer", render: (root) => {
      if (Auth.can("Manager") && Router.has("accountant")) { Router.navigate("accountant"); return; }
      Views.dashboard(root);
    }});
    Router.setNotFound(Views.notFound);

    // Collapse the sidebar into the consolidated menu (one Dashboard, grouped rest).
    reorganizeNav();

    wireActions();
    Router.start();

    // Decide entry screen based on existing session.
    if (Auth.isAuthed()) {
      if (!location.hash) location.hash = "#/" + landingRoute();
      showApp();
    } else showLogin();
  }

  return { init, showLogin, showApp };
})();

/* Boot once the DOM is ready. */
document.addEventListener("DOMContentLoaded", App.init);

/* ---- small helpers -------------------------------------------------------- */
/** Escape user-supplied text before injecting into HTML. */
function esc(str) {
  return String(str).replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
  );
}

/* Shared formatting / date helpers used by Phase 2 modules. */
const Fmt = {
  gbp(n) {
    const v = Number(n) || 0;
    return "£" + v.toLocaleString("en-GB", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  },
  hours(n) { return (Number(n) || 0).toLocaleString("en-GB", { maximumFractionDigits: 2 }); },
  /** Parse a value to a Date. A bare "YYYY-MM-DD" is parsed at LOCAL midnight
      (not UTC) so calendar dates never shift a day across time zones. */
  _parse(v) {
    if (v instanceof Date) return v;
    if (typeof v === "string" && /^\d{4}-\d{2}-\d{2}$/.test(v)) {
      const [y, m, d] = v.split("-").map(Number);
      return new Date(y, m - 1, d);
    }
    return new Date(v);
  },
  date(iso) {
    if (!iso) return "—";
    const d = Fmt._parse(iso);
    return isNaN(d) ? "—" : d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
  },
  dayMon(iso) {
    if (!iso) return "";
    const d = Fmt._parse(iso);
    return isNaN(d) ? "" : d.toLocaleDateString("en-GB", { day: "2-digit", month: "short" });
  },
  dmy(iso) {
    if (!iso) return "";
    const d = Fmt._parse(iso);
    return isNaN(d) ? "" : d.toLocaleDateString("en-GB", { day: "2-digit", month: "2-digit", year: "numeric" });
  },
  /** Today's LOCAL calendar date as YYYY-MM-DD (not UTC — avoids day-shift). */
  todayISO() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  },
};

/* Date-range helpers for timesheets / payroll. UK working weeks are
   Monday-anchored; the labour working week runs Mon–Sat (see workWeekRange).
   All serialisation goes through Period.isoOf, which uses LOCAL calendar
   components so dates never shift a day across time zones. */
const Period = {
  startOfWeek(d = new Date()) {
    const x = new Date(d); const day = (x.getDay() + 6) % 7; // Mon=0
    x.setHours(0, 0, 0, 0); x.setDate(x.getDate() - day); return x;
  },
  range(key) {
    const now = new Date(); let from, to;
    if (key === "this-week") { from = Period.startOfWeek(now); to = new Date(from); to.setDate(to.getDate() + 6); }
    else if (key === "last-week") { to = new Date(Period.startOfWeek(now)); to.setDate(to.getDate() - 1); from = new Date(to); from.setDate(from.getDate() - 6); }
    else if (key === "this-month") { from = new Date(now.getFullYear(), now.getMonth(), 1); to = new Date(now.getFullYear(), now.getMonth() + 1, 0); }
    else { return { from: null, to: null }; } // "all"
    return { from: Period.isoOf(from), to: Period.isoOf(to) };
  },
  inRange(dateISO, from, to) {
    if (!from && !to) return true;
    return (!from || dateISO >= from) && (!to || dateISO <= to);
  },
};

/* --------------------------------------------------------------------------
   Pay-period helpers — the accountant pays workers every 2 weeks, so the
   FORTNIGHT (pay period) is a first-class reporting window alongside week,
   month and year. Fortnights are Monday-anchored on a fixed 14-day grid
   (reference Monday 2024-01-01) so "current pay period" is deterministic and
   identical everywhere (payroll, accounting, supplier and project reports all
   line up). All functions are additive — nothing above is changed.
   -------------------------------------------------------------------------- */
Object.assign(Period, {
  _DAY: 86400000,
  _REF_MONDAY: new Date(2024, 0, 1), // a Monday
  /** LOCAL calendar date as YYYY-MM-DD (never UTC — avoids the day-shift that
      made Monday render as the previous Sunday in UK/BST). Single source of
      truth for date serialisation across the ERP. */
  isoOf(d) {
    const x = new Date(d);
    return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, "0")}-${String(x.getDate()).padStart(2, "0")}`;
  },
  addDays(d, n) { const x = new Date(d); x.setDate(x.getDate() + n); return x; },

  /** Monday that starts the pay fortnight containing `now`. */
  payPeriodStart(now = new Date()) {
    const monday = Period.startOfWeek(now);
    const weeks = Math.round((monday - Period._REF_MONDAY) / (7 * Period._DAY));
    return (weeks % 2 !== 0) ? Period.addDays(monday, -7) : monday;
  },
  /** ISO-8601 week number (1–53) for "Week NN" labels. */
  isoWeek(d) {
    const x = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    const day = (x.getUTCDay() + 6) % 7;          // Mon=0
    x.setUTCDate(x.getUTCDate() - day + 3);        // nearest Thursday
    const firstThu = new Date(Date.UTC(x.getUTCFullYear(), 0, 4));
    const ftDay = (firstThu.getUTCDay() + 6) % 7;
    firstThu.setUTCDate(firstThu.getUTCDate() - ftDay + 3);
    return 1 + Math.round((x - firstThu) / (7 * Period._DAY));
  },

  /** Calendar week window (Mon–Sun) for general filtering. offset 0 = current. */
  weekRange(offset = 0) {
    const from = Period.addDays(Period.startOfWeek(new Date()), offset * 7);
    const to = Period.addDays(from, 6);
    return { from: Period.isoOf(from), to: Period.isoOf(to), label: `Week ${Period.isoWeek(from)} · ${Fmt.dayMon(Period.isoOf(from))}–${Fmt.dayMon(Period.isoOf(to))}` };
  },
  /** UK working week (Mon–Sat) — the labour-entry week (Saturdays are worked).
      offset 0 = current. Label format: "Week 24 · 08 Jun 2026 – 13 Jun 2026".
      Used by the Labour Sheet and the dashboard so they agree on week number
      and dates. */
  workWeekRange(offset = 0) {
    const mon = Period.addDays(Period.startOfWeek(new Date()), offset * 7);
    const sat = Period.addDays(mon, 5);
    const f = Period.isoOf(mon), t = Period.isoOf(sat);
    return { from: f, to: t, week: Period.isoWeek(mon), label: `Week ${Period.isoWeek(mon)} · ${Fmt.date(f)} – ${Fmt.date(t)}` };
  },
  /** Pay-period (fortnight) window. offset 0 = current, -1 = previous. */
  payPeriodRange(offset = 0) {
    const from = Period.addDays(Period.payPeriodStart(new Date()), offset * 14);
    const to = Period.addDays(from, 13);
    const f = Period.isoOf(from), t = Period.isoOf(to);
    return { from: f, to: t, label: `Pay period · ${Fmt.dmy(f)} – ${Fmt.dmy(t)}` };
  },
  /** Calendar-month window. offset 0 = current, -1 = previous. */
  monthRange(offset = 0) {
    const n = new Date();
    const from = new Date(n.getFullYear(), n.getMonth() + offset, 1);
    const to = new Date(n.getFullYear(), n.getMonth() + offset + 1, 0);
    return { from: Period.isoOf(from), to: Period.isoOf(to), label: from.toLocaleDateString("en-GB", { month: "long", year: "numeric" }) };
  },
  /** Calendar-year window. offset 0 = current, -1 = previous. */
  yearRange(offset = 0) {
    const y = new Date().getFullYear() + offset;
    return { from: `${y}-01-01`, to: `${y}-12-31`, label: String(y) };
  },
});

/* ==========================================================================
   8. COMMERCIAL — shared infrastructure for Phase 3 document modules
   (quotes / invoices / purchase orders all build on this; clients &
   suppliers are simple CRUD and live in their own module files.)

   Provides: Money/VAT maths · document numbering · company profile ·
   printable PDF-ready layout · a docModule() factory that produces a full
   list + line-item editor + print-preview module from a small config.
   ========================================================================== */
const Commercial = (() => {
  const DEFAULT_VAT = 20; // UK standard rate

  // Deep-link intent: another screen (e.g. the accountant dashboard) can ask a
  // doc module to open its "new" editor on next render. Consumed once.
  let pendingNew = null;
  function requestNew(id) { pendingNew = id; }
  function takeNewIntent(id) { if (pendingNew === id) { pendingNew = null; return true; } return false; }

  /* ---- money / VAT ------------------------------------------------------- */
  const Money = {
    r2: (n) => Math.round((Number(n) || 0) * 100) / 100,
    line: (it) => { it = it || {}; return Money.r2((Number(it.qty) || 0) * (Number(it.unitPrice) || 0)); },
    subtotal: (items) => Money.r2((items || []).reduce((s, it) => s + Money.line(it), 0)),
    totals(items, vatRate) {
      const sub = Money.subtotal(items);
      const vat = Money.r2(sub * (Number(vatRate) || 0) / 100);
      return { sub, vat, total: Money.r2(sub + vat) };
    },
  };

  /* ---- sequential document numbers (QUO-0001 …) -------------------------- */
  function nextNumber(col, prefix) {
    const max = Store.all(col).reduce((m, r) => Math.max(m, r.seq || 0), 0);
    const seq = max + 1;
    return { seq, number: `${prefix}-${String(seq).padStart(4, "0")}` };
  }

  /* ---- company profile (appears on every document) ----------------------- */
  const Company = {
    DEFAULT: {
      name: "Your Company Ltd",
      address: "1 High Street\nLondon\nSW1A 1AA",
      phone: "020 0000 0000", email: "hello@company.co.uk",
      vatNo: "GB000000000", regNo: "00000000",
      bank: "Bank: —\nSort code: 00-00-00\nAccount: 00000000",
    },
    get() {
      const c = Store.read("company");
      if (!c) { Store.write("company", Company.DEFAULT); return { ...Company.DEFAULT }; }
      return c;
    },
    save(patch) { Store.write("company", { ...Company.get(), ...patch }); },
    editModal(after) {
      const c = Company.get();
      UI.modal({
        title: "Company details", size: "lg", saveLabel: "Save details",
        bodyHTML: `
          <p class="hint" style="margin-bottom:14px">These details appear on your quotes, invoices and purchase orders.</p>
          <div class="form-grid">
            <div class="field span-2"><label class="field__label">Company name</label><input class="input" id="c-name" value="${esc(c.name)}"></div>
            <div class="field"><label class="field__label">Phone</label><input class="input" id="c-phone" value="${esc(c.phone)}"></div>
            <div class="field"><label class="field__label">Email</label><input class="input" id="c-email" value="${esc(c.email)}"></div>
            <div class="field"><label class="field__label">VAT number</label><input class="input" id="c-vat" value="${esc(c.vatNo)}"></div>
            <div class="field"><label class="field__label">Company reg.</label><input class="input" id="c-reg" value="${esc(c.regNo)}"></div>
            <div class="field span-2"><label class="field__label">Address</label><textarea class="input" id="c-addr" rows="3">${esc(c.address)}</textarea></div>
            <div class="field span-2"><label class="field__label">Bank / payment details (shown on invoices)</label><textarea class="input" id="c-bank" rows="3">${esc(c.bank)}</textarea></div>
          </div>`,
        onSave: (r) => {
          Company.save({
            name: r.querySelector("#c-name").value, phone: r.querySelector("#c-phone").value,
            email: r.querySelector("#c-email").value, vatNo: r.querySelector("#c-vat").value,
            regNo: r.querySelector("#c-reg").value, address: r.querySelector("#c-addr").value,
            bank: r.querySelector("#c-bank").value,
          });
          UI.toast("Company details saved", "ok");
          if (after) after();
        },
      });
    },
  };

  /* ---- printable document layout (Print → Save as PDF) ------------------- */
  const nl2br = (s) => esc(s).replace(/\n/g, "<br>");

  function buildDocHTML(doc, cfg) {
    const co = Company.get();
    const party = Store.find(cfg.party.coll, doc.partyId) || {};
    const site = doc.siteId ? Store.find("sites", doc.siteId) : null;
    const t = Money.totals(doc.items, doc.vatRate);
    const rows = (doc.items || []).map((raw) => { const it = raw || {}; return `
      <tr><td>${esc(it.description || "")}</td>
        <td class="r">${Fmt.hours(it.qty)}</td>
        <td>${esc(it.unit || "")}</td>
        <td class="r">${Fmt.gbp(it.unitPrice)}</td>
        <td class="r">${Fmt.gbp(Money.line(it))}</td></tr>`; }).join("");
    const partyAddr = [party.company, party.address].filter(Boolean).join("\n");

    return `
      <div class="doc">
        <div class="doc__top">
          <div class="doc__co">
            <div class="doc__co-name">${esc(co.name)}</div>
            <div class="doc__muted">${nl2br(co.address)}</div>
            <div class="doc__muted">${esc(co.phone)} · ${esc(co.email)}</div>
            <div class="doc__muted">VAT ${esc(co.vatNo)} · Reg ${esc(co.regNo)}</div>
          </div>
          <div class="doc__meta">
            <div class="doc__title">${esc(cfg.docTitle)}</div>
            <table class="doc__metatbl">
              <tr><td>Number</td><td>${esc(doc.number || "—")}</td></tr>
              <tr><td>${esc(cfg.dateLabel || "Date")}</td><td>${Fmt.date(doc.date)}</td></tr>
              ${cfg.date2 ? `<tr><td>${esc(cfg.date2.label)}</td><td>${Fmt.date(doc.date2)}</td></tr>` : ""}
              <tr><td>Status</td><td>${esc(doc.status)}</td></tr>
            </table>
          </div>
        </div>

        <div class="doc__parties">
          <div>
            <div class="doc__lbl">${esc(cfg.party.label)}</div>
            <div class="doc__party-name">${esc(party.name || "—")}</div>
            <div class="doc__muted">${nl2br(partyAddr)}</div>
            <div class="doc__muted">${esc(party.email || "")}${party.phone ? " · " + esc(party.phone) : ""}</div>
          </div>
          ${site ? `<div><div class="doc__lbl">Site</div><div class="doc__party-name">${esc(site.name)}</div><div class="doc__muted">${nl2br(site.address || "")}</div></div>` : ""}
        </div>

        <table class="doc__items">
          <thead><tr><th>Description</th><th class="r">Qty</th><th>Unit</th><th class="r">Unit price</th><th class="r">Amount</th></tr></thead>
          <tbody>${rows || `<tr><td colspan="5" class="doc__muted">No line items.</td></tr>`}</tbody>
        </table>

        <div class="doc__foot">
          <div class="doc__notes">
            ${doc.notes ? `<div class="doc__lbl">Notes</div><div class="doc__muted">${nl2br(doc.notes)}</div>` : ""}
            ${cfg.showBank ? `<div class="doc__lbl" style="margin-top:12px">Payment details</div><div class="doc__muted">${nl2br(co.bank)}</div>` : ""}
          </div>
          <table class="doc__totals">
            <tr><td>Subtotal</td><td class="r">${Fmt.gbp(t.sub)}</td></tr>
            <tr><td>VAT @ ${Fmt.hours(doc.vatRate)}%</td><td class="r">${Fmt.gbp(t.vat)}</td></tr>
            <tr class="doc__grand"><td>Total</td><td class="r">${Fmt.gbp(t.total)}</td></tr>
          </table>
        </div>
      </div>`;
  }

  /* ---- document module factory ------------------------------------------ *
     Produces a complete module (list view + editor + print preview) from a
     compact config. Used by quotes.js, invoices.js, purchaseOrders.js.
     ----------------------------------------------------------------------- */
  function docModule(cfg) {
    cfg.vatDefault = cfg.vatDefault ?? DEFAULT_VAT;
    const COL = cfg.collection;
    const canEdit = () => Auth.can(cfg.editRole || "Manager");
    const badge = {}; cfg.statuses.forEach((s) => (badge[s.value] = s.badge));
    const blankItem = () => ({ description: "", qty: 1, unit: "", unitPrice: 0 });

    // per-module UI state (persists within session, reset on nav entry)
    const st = { mode: "list", editing: null, draft: null, statusFilter: "all" };

    const partyName = (id) => (Store.find(cfg.party.coll, id) || {}).name || "—";
    const partyOptions = (sel) => Store.all(cfg.party.coll).map((p) => `<option value="${p.id}"${p.id === sel ? " selected" : ""}>${esc(p.name)}</option>`).join("");
    const siteOptions = (sel) => `<option value="">— none —</option>` + Store.all("sites").map((s) => `<option value="${s.id}"${s.id === sel ? " selected" : ""}>${esc(s.name)}</option>`).join("");
    const statusOptions = (sel) => cfg.statuses.map((s) => `<option value="${s.value}"${s.value === sel ? " selected" : ""}>${s.value}</option>`).join("");

    /* ----- LIST ----- */
    function renderList(root) {
      const all = Store.all(COL).sort((a, b) => (b.seq || 0) - (a.seq || 0));
      const rows = all.filter((d) => st.statusFilter === "all" || d.status === st.statusFilter);
      const sOpts = `<option value="all">All statuses</option>` + cfg.statuses.map((s) => `<option value="${s.value}"${st.statusFilter === s.value ? " selected" : ""}>${s.value}</option>`).join("");

      root.innerHTML = `
        <div class="toolbar">
          <div class="toolbar__left filterbar">
            <select class="input" id="d-fstatus">${sOpts}</select>
            <span class="muted-count num">${all.length} total</span>
          </div>
          ${canEdit() && cfg.newFrom ? `<button class="btn" id="d-newfrom">New from ${esc(cfg.newFrom.label)}</button>` : ""}
          ${canEdit() ? `<button class="btn btn--primary" id="d-new">＋ New ${esc(cfg.noun)}</button>` : ""}
        </div>
        ${rows.length ? `
          <div class="table-wrap"><table class="table">
            <thead><tr><th>Number</th><th>${esc(cfg.party.label)}</th><th>${esc(cfg.dateLabel || "Date")}</th><th>Status</th><th class="ta-r">Total</th><th class="ta-r">Actions</th></tr></thead>
            <tbody>${rows.map((d) => { const t = Money.totals(d.items, d.vatRate); return `
              <tr>
                <td><strong>${esc(d.number)}</strong></td>
                <td>${esc(partyName(d.partyId))}</td>
                <td class="num">${Fmt.date(d.date)}</td>
                <td><span class="badge badge--${badge[d.status] || "muted"}">${esc(d.status)}</span></td>
                <td class="ta-r num">${Fmt.gbp(t.total)}</td>
                <td class="ta-r nowrap">
                  <button class="btn btn--sm" data-view="${d.id}">View</button>
                  <button class="btn btn--sm" data-pdf="${d.id}">⬇ PDF</button>
                  ${canEdit() ? `<button class="btn btn--sm" data-edit="${d.id}">Edit</button>` : ""}
                  ${canEdit() && cfg.quickStatus && cfg.quickStatus.when(d) ? `<button class="btn btn--sm" data-quick="${d.id}">${esc(cfg.quickStatus.label)}</button>` : ""}
                  ${canEdit() ? `<button class="btn btn--sm btn--danger" data-del="${d.id}">Del</button>` : ""}
                </td>
              </tr>`; }).join("")}</tbody>
          </table></div>`
        : `<div class="panel"><div class="panel__body"><div class="empty">
            <div class="empty__title">No ${esc(cfg.noun)}s ${st.statusFilter === "all" ? "yet" : "with this status"}</div>
            <div class="empty__text">${canEdit() ? `Create your first ${esc(cfg.noun)}.` : `Ask a manager to create ${esc(cfg.noun)}s.`}</div>
          </div></div></div>`}
      `;

      root.querySelector("#d-fstatus").addEventListener("change", (e) => { st.statusFilter = e.target.value; renderList(root); });
      const nb = root.querySelector("#d-new"); if (nb) nb.addEventListener("click", () => startDraft(root, null));
      const nf = root.querySelector("#d-newfrom"); if (nf) nf.addEventListener("click", () => pickSource(root));
      root.querySelectorAll("[data-view]").forEach((b) => b.addEventListener("click", () => { st.mode = "preview"; st.editing = Store.find(COL, b.dataset.view); paint(root); }));
      root.querySelectorAll("[data-pdf]").forEach((b) => b.addEventListener("click", () => { const d = Store.find(COL, b.dataset.pdf); Util.savePdfDoc(`${d.number || cfg.prefix}.pdf`, d, cfg); }));
      root.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => startDraft(root, Store.find(COL, b.dataset.edit))));
      root.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => { const d = Store.find(COL, b.dataset.del); UI.confirm(`Delete ${d.number}? This cannot be undone.`, () => { Store.destroy(COL, d.id); UI.toast("Deleted", "info"); renderList(root); }); }));
      root.querySelectorAll("[data-quick]").forEach((b) => b.addEventListener("click", () => { Store.update(COL, b.dataset.quick, { status: cfg.quickStatus.to }); UI.toast(`Marked ${cfg.quickStatus.to}`, "ok"); renderList(root); }));
    }

    function pickSource(root) {
      const list = Store.all(cfg.newFrom.coll).filter(cfg.newFrom.filter).sort((a, b) => (b.seq || 0) - (a.seq || 0));
      if (!list.length) { UI.toast(`No ${cfg.newFrom.label}s available`, "danger"); return; }
      UI.modal({
        title: `New ${cfg.noun} from ${cfg.newFrom.label}`,
        bodyHTML: `<div class="picklist">${list.map((s) => `<button class="picklist__item" data-pick="${s.id}"><span>${esc(s.number)} · ${esc((Store.find(cfg.newFrom.partyColl, s.partyId) || {}).name || "")}</span><span class="num">${Fmt.gbp(Money.totals(s.items, s.vatRate).total)}</span></button>`).join("")}</div>`,
      });
      document.querySelectorAll("[data-pick]").forEach((b) => b.addEventListener("click", () => { const src = Store.find(cfg.newFrom.coll, b.dataset.pick); UI.closeModal(); startDraft(root, null, cfg.newFrom.map(src)); }));
    }

    /* ----- EDITOR ----- */
    function startDraft(root, existing, prefill) {
      st.editing = existing || null;
      if (existing) {
        st.draft = JSON.parse(JSON.stringify(existing));
      } else {
        st.draft = Object.assign({
          partyId: (Store.all(cfg.party.coll)[0] || {}).id || "",
          siteId: "", date: Fmt.todayISO(), date2: "", status: cfg.defaultStatus,
          items: [blankItem()], vatRate: cfg.vatDefault, notes: "",
        }, prefill || {});
      }
      // null-safe: guarantee a usable draft + at least one line item for BOTH
      // new and edit paths (edit may load a record with empty/missing items).
      if (!st.draft || typeof st.draft !== "object") st.draft = {};
      if (!Array.isArray(st.draft.items) || !st.draft.items.length) st.draft.items = [blankItem()];
      st.mode = "editor"; paint(root);
    }

    function renderEditor(root) {
      if (!Store.all(cfg.party.coll).length) {
        root.innerHTML = `<div class="panel"><div class="panel__body"><div class="empty">
          <div class="empty__title">Add a ${esc(cfg.party.label.toLowerCase())} first</div>
          <div class="empty__text">A ${esc(cfg.noun)} needs a ${esc(cfg.party.label.toLowerCase())} to be addressed to.</div>
          <div class="empty__actions"><button class="btn btn--sm" id="goparty">Go to ${esc(cfg.party.label)}s</button></div>
        </div></div></div>`;
        root.querySelector("#goparty").addEventListener("click", () => Router.navigate(cfg.party.route));
        return;
      }
      const d = st.draft; const t = Money.totals(d.items, d.vatRate);
      root.innerHTML = `
        <div class="toolbar no-print"><div class="toolbar__left">
          <button class="btn btn--sm" id="e-back">← Back</button>
          <strong>${st.editing ? "Edit " + esc(st.editing.number) : "New " + esc(cfg.noun)}</strong>
        </div></div>
        <div class="editor">
          <div class="form-grid">
            <div class="field"><label class="field__label">${esc(cfg.party.label)} *</label><select class="input" id="e-party">${partyOptions(d.partyId)}</select></div>
            <div class="field"><label class="field__label">Site</label><select class="input" id="e-site">${siteOptions(d.siteId)}</select></div>
            <div class="field"><label class="field__label">${esc(cfg.dateLabel || "Date")}</label><input class="input" id="e-date" type="date" value="${esc(d.date)}"></div>
            ${cfg.date2 ? `<div class="field"><label class="field__label">${esc(cfg.date2.label)}</label><input class="input" id="e-date2" type="date" value="${esc(d.date2 || "")}"></div>` : ""}
            <div class="field"><label class="field__label">Status</label><select class="input" id="e-status">${statusOptions(d.status)}</select></div>
            <div class="field"><label class="field__label">VAT rate %</label><input class="input" id="e-vat" type="number" min="0" step="0.5" value="${d.vatRate}"></div>
          </div>

          <div class="lines">
            <div class="lines__head"><span>Description</span><span class="r">Qty</span><span>Unit</span><span class="r">Unit £</span><span class="r">Amount</span><span></span></div>
            <div id="e-lines"></div>
            <button class="btn btn--sm" id="e-addline">＋ Add line</button>
          </div>

          <div class="editor__bottom">
            <div class="field editor__notes"><label class="field__label">Notes</label><textarea class="input" id="e-notes" rows="3" placeholder="Terms, scope, payment notes…">${esc(d.notes || "")}</textarea></div>
            <table class="doc__totals editor__totals">
              <tr><td>Subtotal</td><td class="r num" id="tot-sub">${Fmt.gbp(t.sub)}</td></tr>
              <tr><td>VAT</td><td class="r num" id="tot-vat">${Fmt.gbp(t.vat)}</td></tr>
              <tr class="doc__grand"><td>Total</td><td class="r num" id="tot-total">${Fmt.gbp(t.total)}</td></tr>
            </table>
          </div>

          <div class="editor__actions">
            <button class="btn" id="e-cancel">Cancel</button>
            <button class="btn btn--primary" id="e-save">${st.editing ? "Save changes" : "Create " + esc(cfg.noun)}</button>
          </div>
        </div>`;

      renderLines(root);
      root.querySelector("#e-party").addEventListener("change", (e) => (d.partyId = e.target.value));
      root.querySelector("#e-site").addEventListener("change", (e) => (d.siteId = e.target.value));
      root.querySelector("#e-date").addEventListener("change", (e) => (d.date = e.target.value));
      if (cfg.date2) root.querySelector("#e-date2").addEventListener("change", (e) => (d.date2 = e.target.value));
      root.querySelector("#e-status").addEventListener("change", (e) => (d.status = e.target.value));
      root.querySelector("#e-vat").addEventListener("input", (e) => { d.vatRate = parseFloat(e.target.value) || 0; refreshTotals(root); });
      root.querySelector("#e-notes").addEventListener("input", (e) => (d.notes = e.target.value));
      root.querySelector("#e-addline").addEventListener("click", () => { d.items.push(blankItem()); renderLines(root); refreshTotals(root); });
      root.querySelector("#e-back").addEventListener("click", () => { st.mode = "list"; paint(root); });
      root.querySelector("#e-cancel").addEventListener("click", () => { st.mode = "list"; paint(root); });
      root.querySelector("#e-save").addEventListener("click", () => save(root));
    }

    function renderLines(root) {
      const box = root.querySelector("#e-lines"); const d = st.draft;
      if (!box || !d) return;
      // null-safe: items must always be a non-empty array before we map it.
      if (!Array.isArray(d.items) || !d.items.length) d.items = [blankItem()];
      box.innerHTML = d.items.map((raw, i) => { const it = raw || {}; return `
        <div class="lines__row">
          <input class="input" data-i="${i}" data-f="description" value="${esc(it.description || "")}" placeholder="Work or material">
          <input class="input r" data-i="${i}" data-f="qty" type="number" step="0.01" value="${it.qty ?? ""}">
          <input class="input" data-i="${i}" data-f="unit" value="${esc(it.unit || "")}" placeholder="ea">
          <input class="input r" data-i="${i}" data-f="unitPrice" type="number" step="0.01" value="${it.unitPrice ?? ""}">
          <span class="lines__amt num" data-amt="${i}">${Fmt.gbp(Money.line(it))}</span>
          <button class="btn btn--sm btn--danger" data-rm="${i}" aria-label="Remove line">✕</button>
        </div>`; }).join("");

      box.querySelectorAll("input[data-i]").forEach((inp) => inp.addEventListener("input", () => {
        const i = +inp.dataset.i, f = inp.dataset.f;
        // null-safe: never write a property onto an undefined line slot.
        if (!Array.isArray(d.items)) d.items = [];
        if (!d.items[i]) d.items[i] = blankItem();
        d.items[i][f] = (f === "qty" || f === "unitPrice") ? (parseFloat(inp.value) || 0) : inp.value;
        const amt = box.querySelector(`[data-amt="${i}"]`);
        if (amt) amt.textContent = Fmt.gbp(Money.line(d.items[i]));
        refreshTotals(root);
      }));
      box.querySelectorAll("[data-rm]").forEach((b) => b.addEventListener("click", () => {
        if (!Array.isArray(d.items)) d.items = [];
        d.items.splice(+b.dataset.rm, 1);
        if (!d.items.length) d.items.push(blankItem());
        renderLines(root); refreshTotals(root);
      }));
    }

    function refreshTotals(root) {
      if (!st.draft) return;
      const t = Money.totals(st.draft.items, st.draft.vatRate);
      const sub = root.querySelector("#tot-sub"), vat = root.querySelector("#tot-vat"), tot = root.querySelector("#tot-total");
      if (sub) sub.textContent = Fmt.gbp(t.sub);
      if (vat) vat.textContent = Fmt.gbp(t.vat);
      if (tot) tot.textContent = Fmt.gbp(t.total);
    }

    function save(root) {
      const d = st.draft;
      if (!d) { st.mode = "list"; paint(root); return; }
      if (!d.partyId) { UI.toast(`Pick a ${cfg.party.label.toLowerCase()}`, "danger"); return; }
      d.items = (Array.isArray(d.items) ? d.items : []).filter((it) => it && ((it.description || "").trim() || Money.line(it) > 0));
      if (!d.items.length) { UI.toast("Add at least one line item", "danger"); return; }
      if (st.editing) { Store.update(COL, st.editing.id, d); UI.toast(`${st.editing.number} updated`, "ok"); }
      else { const n = nextNumber(COL, cfg.prefix); Store.insert(COL, { ...d, seq: n.seq, number: n.number }); UI.toast(`${n.number} created`, "ok"); }
      st.mode = "list"; st.editing = null; st.draft = null; paint(root);
    }

    /* ----- PREVIEW / PRINT ----- */
    function renderPreview(root) {
      const d = st.editing;
      root.innerHTML = `
        <div class="toolbar no-print">
          <div class="toolbar__left"><button class="btn btn--sm" id="p-back">← Back</button><strong>${esc(d.number)}</strong></div>
          <div style="margin-left:auto;display:flex;gap:10px">
            <button class="btn btn--sm" id="p-company">Company details</button>
            <button class="btn btn--sm" id="p-print">🖨 Print</button>
            <button class="btn btn--primary btn--sm" id="p-pdf">⬇ Save PDF</button>
          </div>
        </div>
        <div class="printable">${buildDocHTML(d, cfg)}</div>`;
      root.querySelector("#p-back").addEventListener("click", () => { st.mode = "list"; st.editing = null; paint(root); });
      root.querySelector("#p-print").addEventListener("click", () => window.print());
      root.querySelector("#p-pdf").addEventListener("click", () => Util.savePdfDoc(`${d.number || cfg.prefix}.pdf`, d, cfg));
      root.querySelector("#p-company").addEventListener("click", () => Company.editModal(() => renderPreview(root)));
    }

    /* ----- paint / entry ----- */
    function paint(root) {
      if (st.mode === "editor") return renderEditor(root);
      if (st.mode === "preview") return renderPreview(root);
      renderList(root);
    }

    Modules.register({
      id: cfg.id, label: cfg.label, title: cfg.title || cfg.label, minRole: cfg.minRole || "Viewer",
      icon: cfg.icon,
      render: (root) => { st.mode = "list"; st.editing = null; st.draft = null;
        if (takeNewIntent(cfg.id)) startDraft(root, null); else paint(root); },
    });
    if (cfg.stat) Dashboard.addStat(cfg.stat, cfg.statRole || "Viewer");
  }

  return { Money, nextNumber, Company, buildDocHTML, docModule, requestNew, DEFAULT_VAT };
})();

/* ==========================================================================
   9. FINANCE — cross-module aggregation layer (architecture extension)
   Single source of truth for project costing & profitability so the
   dashboard and the (future) reports module compute identically.

   Cost of a project (site) = labour (timesheets × rate, OT @1.5)
                            + supplier invoices (register; Unpaid/Paid, gross)
                            + employee expenses booked to the project.
   Purchase orders are commitments only — tracked, but NOT counted in cost.
   Revenue = invoiced (non-draft invoices) ; Collected = client payments.
   ========================================================================== */
const Finance = (() => {
  const OT = 1.5;
  const r2 = (n) => Commercial.Money.r2(n);
  const docTotal = (d) => Commercial.Money.totals(d.items, d.vatRate).total;
  const match = (rowSiteId, siteId) => !siteId || rowSiteId === siteId;

  function labourCost(siteId) {
    return r2(Store.all("timesheets").filter((t) => match(t.siteId, siteId)).reduce((s, t) => {
      const rate = Number((Store.find("workers", t.workerId) || {}).rate) || 0;
      return s + (Number(t.hours) || 0) * rate + (Number(t.overtime) || 0) * rate * OT;
    }, 0));
  }
  function materialsCost(siteId) {
    return r2(Store.all("purchaseOrders")
      .filter((p) => match(p.siteId, siteId) && (p.status === "Ordered" || p.status === "Received"))
      .reduce((s, p) => s + docTotal(p), 0));
  }
  function expensesCost(siteId) {
    return r2(Store.all("expenses").filter((e) => match(e.siteId, siteId)).reduce((s, e) => s + (Number(e.amount) || 0), 0));
  }
  // Supplier invoices register (collection "supplierInvoices"): committed bills
  // = status Unpaid/Paid, gross (incl VAT). Drafts excluded. This is the
  // accountant's actual supplier cost (separate flow from PO commitments).
  function supplierInvoiceCost(siteId) {
    return r2(Store.all("supplierInvoices")
      .filter((s) => match(s.siteId, siteId) && (s.status === "Unpaid" || s.status === "Paid"))
      .reduce((sum, s) => sum + (Number(s.gross) || 0), 0));
  }
  // Project cost counts ACTUAL supplier bills (the supplier invoice register),
  // NOT PO commitments. POs stay tracked as commitments (see the "Open POs"
  // dashboard stat) but are excluded from cost/profitability to avoid double
  // counting. `materials` is kept in the return for reference only — it is NOT
  // part of `total`.
  function projectCost(siteId) {
    const labour = labourCost(siteId), supplierInvoices = supplierInvoiceCost(siteId),
          expenses = expensesCost(siteId);
    const materials = materialsCost(siteId); // PO commitments — reference only, not costed
    return { labour, materials, supplierInvoices, expenses, total: r2(labour + supplierInvoices + expenses) };
  }
  function invoiced(siteId) {
    return r2(Store.all("invoices").filter((i) => match(i.siteId, siteId) && i.status !== "Draft").reduce((s, i) => s + docTotal(i), 0));
  }
  function collected(siteId) {
    return r2(Store.all("payments").filter((p) => match(p.siteId, siteId)).reduce((s, p) => s + (Number(p.amount) || 0), 0));
  }
  function projectPnL(siteId) {
    const revenue = invoiced(siteId), cost = projectCost(siteId).total, profit = r2(revenue - cost);
    return { revenue, cost, profit, margin: revenue ? r2((profit / revenue) * 100) : 0 };
  }
  /** Cash basis: in = client payments, out = reimbursed employee expenses. */
  function cashFlow() {
    const cin = collected(null);
    const cout = r2(Store.all("expenses").filter((e) => e.reimbursed).reduce((s, e) => s + (Number(e.amount) || 0), 0));
    return { in: cin, out: cout, net: r2(cin - cout) };
  }

  return { OT, labourCost, materialsCost, expensesCost, supplierInvoiceCost, projectCost, invoiced, collected, projectPnL, cashFlow };
})();
