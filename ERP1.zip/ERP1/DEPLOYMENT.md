# Deployment Guide

The app is 100% static files, so it deploys to any static host or web server.
There is no backend to provision and nothing to build.

## What to deploy
The entire `construction-erp/` folder: `index.html`, `app.js`, `styles.css`,
`styles.enhance.css`, and the `modules/` directory. The Markdown docs are
optional.

## Netlify
- **Drag-and-drop:** log in → *Add new site* → *Deploy manually* → drag the
  `construction-erp` folder onto the drop zone. Done.
- **CLI:**
  ```bash
  npm i -g netlify-cli
  cd construction-erp
  netlify deploy --prod --dir .
  ```
No build command, no publish subdirectory needed (publish directory = the folder
you upload).

## GitHub Pages
1. Push the folder contents to a repo (files at the repo root, or in `/docs`).
2. Repo → *Settings* → *Pages* → Source = your branch, folder = `/ (root)` (or
   `/docs`).
3. Wait for the Pages build; your site is at
   `https://<user>.github.io/<repo>/`.

## Vercel
```bash
npm i -g vercel
cd construction-erp
vercel --prod
```
Framework preset: *Other*. Build command: *none*. Output directory: `.`.

## Cloudflare Pages / Surge / S3 + CloudFront / Firebase Hosting
Same idea — upload the folder as static assets, no build step. Examples:
```bash
npx surge .                       # Surge
aws s3 sync . s3://your-bucket     # S3 (enable static website hosting)
firebase deploy                    # after `firebase init hosting` (public = .)
```

## Self-hosted (nginx)
Copy the folder to the web root and serve it statically:
```nginx
server {
  listen 80;
  server_name erp.example.com;
  root /var/www/construction-erp;
  index index.html;
  location / { try_files $uri $uri/ /index.html; }
}
```
(Hash-based routing means deep links resolve client-side; the `try_files`
fallback is optional.)

## Production checklist
- [ ] **Serve over HTTPS** (required for fonts/CDN and good practice).
- [ ] **Vendor Chart.js locally** if you don't want a CDN dependency (see
      INSTALLATION.md → *Offline use*).
- [ ] **Understand the data model:** storage is per-browser `localStorage`. This
      app is single-user-per-browser with no server sync. For shared,
      multi-user, durable data you must add a backend and migrate `Store`.
- [ ] **Replace the demo auth** before any real use — it is client-side only and
      not secure (see README → *Security*).
- [ ] Set caching headers so `index.html` revalidates while hashed assets cache
      (optional; there's no fingerprinting, so prefer short cache on `.js`).

## Notes on data & privacy
Because all data stays in the user's browser, there is no server-side data to
secure or back up — but also no central copy. Tell users to export JSON backups
regularly (Settings → Export backup). Migrating to a backend is the recommended
next step for any team deployment.
